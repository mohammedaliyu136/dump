<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="content-body">
            <div class="container-fluid">
                <!-- Header -->
                <div class="intro-y flex flex-col sm:flex-row items-center mt-8">
                    <div class="w-full sm:w-auto flex mt-4 sm:mt-0">
                        <button class="btn btn-primary shadow-md mr-2" data-bs-toggle="modal" data-bs-target="#createnew">
                            <i class="fa fa-plus mr-2"></i> Add New Category
                        </button>
                    </div>
                </div>

                <!-- Main Content -->
                <div class="grid grid-cols-12 gap-6 mt-5">
                    <div class="col-span-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="overflow-x-auto">
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th class="whitespace-nowrap">#</th>
                                                <th class="whitespace-nowrap">Name</th>
                                                <th class="whitespace-nowrap">Created At</th>
                                                <th class="whitespace-nowrap">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr>
                                                    <td><?php echo e($category->id); ?></td>
                                                    <td><?php echo e($category->name); ?></td>
                                                    <td><?php echo e($category->created_at); ?></td>
                                                    <td>
                                                        <div class="flex">
                                                            <button class="btn btn-sm btn-primary mr-2"
                                                                onclick="editCategory(<?php echo e($category->id); ?>, '<?php echo e($category->name); ?>')"
                                                                data-bs-toggle="modal" data-bs-target="#editModal">
                                                                <i class="fas fa-edit"></i>
                                                            </button>
                                                            <button class="btn btn-sm btn-danger"
                                                                onclick="deleteCategory(<?php echo e($category->id); ?>)"
                                                                data-bs-toggle="modal" data-bs-target="#deleteModal">
                                                                <i class="fas fa-trash"></i>
                                                            </button>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <tr>
                                                    <td colspan="4" class="text-center">No categories found</td>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                                <!-- Pagination -->
                                <div class="mt-5">
                                    <?php echo e($data->links()); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Create Modal -->
        <div class="modal fade" id="createnew" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog">
                <form id="createForm">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Create New Category</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="form-group">
                                <label for="name" class="form-label">Category Name</label>
                                <input type="text" class="form-control" id="name" name="name" required>
                                <div class="invalid-feedback" id="nameError"></div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Create Category</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Edit Modal -->
        <div class="modal fade" id="editModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog">
                <form id="editForm">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Edit Category</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <input type="hidden" id="edit_id">
                            <div class="form-group">
                                <label for="edit_name" class="form-label">Category Name</label>
                                <input type="text" class="form-control" id="edit_name" name="name" required>
                                <div class="invalid-feedback" id="editNameError"></div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Update Category</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Delete Modal -->
        <div class="modal fade" id="deleteModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Confirm Delete</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <p>Are you sure you want to delete this category? This action cannot be undone.</p>
                        <input type="hidden" id="delete_id">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-danger" onclick="confirmDelete()">Delete</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script>
            // Create Category
            $('#createForm').submit(function(e) {
                e.preventDefault();
                const formData = new FormData(this);

                $.ajax({
                    url: "<?php echo e(route('admin.lab.category.store')); ?>",
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    beforeSend: function() {
                        $('#createForm .btn-primary').prop('disabled', true);
                        $('#nameError').html('');
                    },
                    success: function(response) {
                        if (response.success) {
                            toastr.success(response.message);
                            $('#createnew').modal('hide');
                            window.location.reload();
                        } else {
                            toastr.error(response.message);
                        }
                    },
                    error: function(xhr) {
                        $('#createForm .btn-primary').prop('disabled', false);
                        if (xhr.status === 422) {
                            const errors = xhr.responseJSON.errors;
                            if (errors && errors.name) {
                                $('#nameError').html(errors.name[0]);
                            }
                        } else {
                            toastr.error('An error occurred. Please try again.');
                        }
                    },
                    complete: function() {
                        $('#createForm .btn-primary').prop('disabled', false);
                    }
                });
            });

            // Edit Category
            $('#editForm').submit(function(e) {
                e.preventDefault();
                const id = $('#edit_id').val();
                const formData = new FormData(this);
                formData.append('id', id);

                $.ajax({
                    url: "<?php echo e(route('admin.lab.category.update')); ?>",
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    beforeSend: function() {
                        $('#editForm .btn-primary').prop('disabled', true);
                        $('#editNameError').html('');
                    },
                    success: function(response) {
                        if (response.success) {
                            toastr.success(response.message);
                            $('#editModal').modal('hide');
                            window.location.reload();
                        } else {
                            toastr.error(response.message);
                        }
                    },
                    error: function(xhr) {
                        $('#editForm .btn-primary').prop('disabled', false);
                        if (xhr.status === 422) {
                            const errors = xhr.responseJSON.errors;
                            if (errors && errors.name) {
                                $('#editNameError').html(errors.name[0]);
                            }
                        } else {
                            toastr.error('An error occurred. Please try again.');
                        }
                    },
                    complete: function() {
                        $('#editForm .btn-primary').prop('disabled', false);
                    }
                });
            });

            // Delete Category
            function confirmDelete() {
                const id = $('#delete_id').val();
                const formData = new FormData();
                formData.append('id', id);

                $.ajax({
                    url: "<?php echo e(route('admin.lab.category.destroy')); ?>",
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    beforeSend: function() {
                        $('.btn-danger').prop('disabled', true);
                    },
                    success: function(response) {
                        if (response.success) {
                            toastr.success(response.message);
                            $('#deleteModal').modal('hide');
                            window.location.reload();
                        } else {
                            toastr.error(response.message);
                        }
                    },
                    error: function(xhr) {
                        $('.btn-danger').prop('disabled', false);
                        toastr.error('An error occurred. Please try again.');
                    },
                    complete: function() {
                        $('.btn-danger').prop('disabled', false);
                    }
                });
            }
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', ['title' => 'Lab Categories'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/sonocare.net.ng/httpdocs/resources/views/admin/lab/category.blade.php ENDPATH**/ ?>