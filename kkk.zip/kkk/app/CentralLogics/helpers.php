<?php
namespace App\CentralLogics;

use Illuminate\Support\Facades\Http;

class Helpers
{
    public static function send_push_notif_to_device($fcm_token, $data, $web_push_link = null)
    {
        $url = "https://fcm.googleapis.com/fcm/send";
        $header = array(
            "authorization: key=AAAA4unw2EQ:APA91bGM5R6U7HTz096YExo_ktdW3zTFePeXtpvh88GWTT4rbFQvj49KQHmZpiq8-qmslwk_ZFysdeBnXRmdb3mSpo66wct6U2OA4zssEb8EUn6KCgYMUKJ0xn-rByFNy66FnaADu7Q5",
            "content-type: application/json"
        );

        $click_action = "";
        if($web_push_link){
            $click_action = ',
            "click_action": "'.$web_push_link.'"';
        }

        $postdata = '{
            "to" : "' . $fcm_token . '",
            "mutable_content": true,
            "data" : {
                "title":"' . $data['title'] . '",
                "body" : "' . $data['description'] . '"
            },
            "notification" : {
                "title" :"' . $data['title'] . '",
                "body" : "' . $data['description'] . '",
                "is_read": 0,
                "icon" : "new",
                "sound": "notification.wav",
                "android_channel_id": "stackfood"
                '.$click_action.'
            }
        }';

        $ch = curl_init();
        $timeout = 120;
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);

        // Get URL content
        $result = curl_exec($ch);
        // close handle to release resources
        curl_close($ch);

        return $result;
    }

    
    public static function send_push_notif_to_topic($topic,$data, $web_push_link = null)
    {
        $url = "https://fcm.googleapis.com/fcm/send";
        $header = array(
            "authorization: key=AAAA4unw2EQ:APA91bGM5R6U7HTz096YExo_ktdW3zTFePeXtpvh88GWTT4rbFQvj49KQHmZpiq8-qmslwk_ZFysdeBnXRmdb3mSpo66wct6U2OA4zssEb8EUn6KCgYMUKJ0xn-rByFNy66FnaADu7Q5",
            "content-type: application/json"
        );
        $click_action = "";
        if($web_push_link){
            $click_action = ',
            "click_action": "'.$web_push_link.'"';
        }

        if (isset($data['order_id'])) {
            $postdata = '{
                "to" : "/topics/' . $topic . '",
                "mutable_content": true,
                "data" : {
                    "title":"' . $data['title'] . '",
                    "body" : "' . $data['description'] . '",
                    "is_read": 0,
                    "type":"' . $type . '"
                },
                "notification" : {
                    "title":"' . $data['title'] . '",
                    "body" : "' . $data['description'] . '",
                    "is_read": 0,
                    "icon" : "new",
                    "sound": "notification.wav",
                    "android_channel_id": "stackfood"
                    '.$click_action.'
                  }
            }';
        } else {
            $postdata = '{
                "to" : "/topics/' . $topic . '",
                "mutable_content": true,
                "data" : {
                    "title":"' . $data['title'] . '",
                    "body" : "' . $data['description'] . '",
                    "token" : "' . $data['token'] . '",
                    "channel" : "' . $data['channel'] . '",
                    "type" :"'.$data['type'].'",
                    "user" :"'.$data['user'].'",
                    "vitalsign_id" :"'.$data['vitalsign_id'].'",
                    "patient_id" :"'.$data['patient_id'].'",
                    "is_read": 0,
                },
                "notification" : {
                    "title":"' . $data['title'] . '",
                    "body" : "' . $data['description'] . '",
                    "is_read": 0,
                    "icon" : "new",
                    "sound": "notification.wav",
                    "android_channel_id": "stackfood"
                    '.$click_action.'
                  }
            }';
        }

        $ch = curl_init();
        $timeout = 120;
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);

        // Get URL content
        $result = curl_exec($ch);
        // close handle to release resources
        curl_close($ch);

        return $result;
    }

}
?>