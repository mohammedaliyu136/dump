<?php

namespace App\Http\Controllers;

use Auth;
use DB;
use Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class Hospital extends Controller
{
    //

    public function register(Request $request)
    {

        $email = $request->email;
        $token = rand(1111, 9999);
        $password = Hash::make($request->password);
        $phone = $request->phone;

        $check = DB::table("hospital")->where(["email" => $email])->exists();
        if ($check) {
            return response()->json(["message" => "User Mail Already Exists!"], 409);
        }

        $check = DB::table("hospital")->where(["phone" => $phone])->exists();
        if ($check) {
            return response()->json(["message" => "User Phone Number Already Exists!"], 409);
        }

        DB::table("hospital")->insert([
            //"first_name"=>$request->first_name,
            //"last_name"=>$request->last_name,
            //'other_names'=>$request->other_names,
            "name" => $request->name,
            "address" => $request->address,
            "email" => $email,
            "otp" => $token,
            "password" => $password,
            "phone" => $phone,
        ]);

        $user = DB::table("hospital")->where(["email" => $email])->first();

        // Your Account SID and Auth Token from twilio.com/console
        $account_sid = 'ACa07d9dfe8d7018ff2d519f75dcb7df84';
        $auth_token = '98ad77cf03cbffdcd030173e84c8beb9';
        // In production, these should be environment variables. E.g.:
        // $auth_token = $_ENV["TWILIO_AUTH_TOKEN"]

        /*
        working code, comment twilio is out of token
        // A Twilio number you own with SMS capabilities
        $twilio_number = "+14043345663";

        $client = new Client($account_sid, $auth_token);
        $client->messages->create(
        // Where to send a text message (your cell phone?)
        "+234$phone",
        array(
        'from' => $twilio_number,
        'body' => "OTP verification code from sonocare: $user->otp"
        )
        );
         */

        \Mail::send('mail4', ["user" => $user], function ($message) use ($user, $request) {
            $message->to($user->email)->subject("Email Verification | SonoCare");
        });

        $user = DB::table("hospital")->where(["email" => $email])->first();

        return response()->json(["message" => "Registration SuccessFul!", "user" => $user]);
    }

    public function updateprofile(Request $request)
    {
        $check = DB::table("hospital")->where(["id" => $request->id])->exists();
        if (!$check) {
            return response()->json(["message" => "Profile Not found!"], 404);
        }

        DB::table("hospital")->where(["id" => $request->id])->update([
            "first_name" => $request->first_name,
            "last_name" => $request->last_name,
            "name" => $request->name,
            "email" => $request->email,
            "phone" => $request->phone,
            "address" => $request->address,
        ]);
        return response()->json(["message" => "Updated SuccessFully!", "data" => $request->except("token")]);
    }

    public function verify(Request $request)
    {
        $email = $request->email;
        $token = $request->token;
        $check = DB::table("hospital")->where(["email" => $email, "otp" => $token])->exists();
        if ($check) {
            DB::table("hospital")->where(["email" => $email, "otp" => $token])->update(["active" => 1]);
            return response()->json(["message" => "Registration Success!"]);
        } else {
            return response()->json(["message" => "Invalid OTP provided!"], 400);
        }
    }

    public function login(Request $request)
    {
        try {
            $credentials = request(['email', 'password']);

            if ($token = auth("hospital")->attempt($credentials)) {
                $email = auth("hospital")->user()->email;
                if (auth("hospital")->user()->active != 1) {
                    $user = DB::table("hospital")->where(["email" => $email])->first();

                    \Mail::send('mail4', ["user" => $user], function ($message) use ($user, $request) {

                        $message->to($user->email)->subject("Email Verification | SonoCare");
                    });
                    $user = DB::table("hospital")->where(["email" => $email])->select("email", "name")->first();
                    return response()->json(["message" => "Account Not Verified", "user" => $user], 401);
                }

                if (auth("hospital")->user()->status == null) {
                    return response()->json(["message" => "Account Verification Needed", "token" => $token], 400);
                }
                if (auth("hospital")->user()->status != 1) { //"pending"
                    return response()->json(["message" => "Account Pending For Verification", "token" => $token], 400);
                }
                return $this->respondWithToken($token);
            } else {
                return response()->json(["message" => "Invalid Login Details!"], 401);
            }
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
        }
    }

    protected function respondWithToken($token)
    {
        try {
            return response()->json([
                'access_token' => $token,
                'token_type' => 'bearer',
                'expires_in' => auth("hospital")->factory()->getTTL() * 60,
                'user' => auth("hospital")->user(),
            ]);
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
        }
    }

    public function resend_otp(Request $request)
    {
        try {
            $email = $request->email;
            $user = DB::table("hospital")->where(["email" => $email])->first();
            if (!$user) {
                return response()->json(["message" => "Invalid User Email!"], 404);
            }

            \Mail::send('mail4', ["user" => $user], function ($message) use ($user, $request) {

                $message->to($user->email)->subject("Email Verification | SonoCare");
            });

            return response()->json(["message" => "OTP resent successfully!"]);
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
        }
    }

    public function step1verification(Request $request)
    {
        $userid = auth("hospital")->user()->id;
        $check = DB::table("h_step1")->where(["hid" => $userid])->exists();
        if ($check) {
            return response()->json(["message" => "Already Registered!"], 400);
        } else {

            DB::table("h_step1")->insert([
                "name" => $request->name,
                "category" => $request->category,
                "hid" => $userid,
                "reg_number" => $request->reg_number,
                "open_hours" => $request->open_hours,
            ]);
            return response()->json(["message" => "Success!", "data" => $request->all()]);
        }
    }

    public function step2verification(Request $request)
    {
        $userid = auth("hospital")->user()->id;
        $check = DB::table("h_step2")->where(["hid" => $userid])->exists();
        if ($check) {
            return response()->json(["message" => "Already Registered!"], 400);
        } else {

            $id_card = time() . $request->id_card->getClientOriginalName();
            $request->id_card->move(public_path('hospital'), $id_card);

            DB::table("h_step2")->insert([
                "country" => $request->country,
                "state" => $request->state,
                "hid" => $userid,
                "ref_by" => $request->refer,
                "identity_id" => "/hospital/$id_card",
                "account_number" => $request->account_number,
                "account_bank" => $request->account_bank,
                "account_name" => $request->account_name,
                "bank_code" => $request->bank_code,
            ]);
            return response()->json(["message" => "Success!", "data" => $request->all()]);
        }
    }

    public function step3verification(Request $request)
    {
        $userid = auth("hospital")->user()->id;
        $check = DB::table("h_step3")->where(["hid" => $userid])->exists();
        if ($check) {
            return response()->json(["message" => "Already Registered!"], 400);
        } else {

            $reg_cert = time() . $request->reg_cert->getClientOriginalName();
            $request->reg_cert->move(public_path('hospital'), $reg_cert);

            $valid_license = time() . $request->valid_license->getClientOriginalName();
            $request->valid_license->move(public_path('hospital'), $valid_license);

            $cac = time() . $request->cac->getClientOriginalName();
            $request->cac->move(public_path('hospital'), $cac);

            DB::table("h_step3")->insert([
                "hid" => $userid,
                "reg_cert" => "/hospital/$reg_cert",
                "valid_license" => "/hospital/$valid_license",
                "cac" => "/hospital/$cac",
                "about" => $request->about,
            ]);
            return response()->json(["message" => "Success!", "data" => $request->all()]);
        }
    }

    public function step4verification(Request $request)
    {
        $userid = auth("hospital")->user()->id;

        DB::table("h_step4")->insert([
            "company_org" => $request->company,
            "from" => $request->from,
            "hid" => $userid,
            "to" => $request->to,
            "active" => $request->current,

        ]);
        DB::table("hospital")->where(["id" => auth("hospital")->user()->id])->update(["status" => "pending"]);
        return response()->json(["message" => "Success!", "data" => $request->all()]);

    }

    public function update_fcm(Request $request)
    {
        $fcm = $request->fcm;
        DB::table("hospital")->where(["id" => auth("hospital")->user()->id])->update(["fcm" => $fcm]);
        return response()->json(["message" => "Updated!"]);
    }

    public function update_account(Request $request)
    {
        $data = [
            "account_number" => $request->account_number,
            "account_name" => $request->account_name,
            "account_bank" => $request->account_bank,
            "bank_code" => $request->bank_code,
        ];

        $update = DB::table('hospital')
            ->where('id', auth('hospital')->user()->id)
            ->update($data);

        if ($update) {
            return response()->json(["message" => "Updated Successfully"]);
        } else {
            return response()->json(["message" => "Account Already Updated "]);
        }

    }

    public function user()
    {
        return response()->json(["user" => auth("hospital")->user()]);
    }

    public function services()
    {
        $userid = auth("hospital")->user()->id;

        $data = DB::table("hospital_service")->where(["hid" => $userid])->get();
        return response()->json(["data" => $data]);

    }

    public function add_service(Request $request)
    {
        $userid = auth("hospital")->user()->id;
        DB::table("hospital_service")->insert([
            "service_name" => $request->service_name,
            "amount" => $request->amount,
            "hid" => $userid,
        ]);

        return response()->json(["message" => "Added", "data" => $request->all()]);
    }

    public function edit_service(Request $request)
    {
        $userid = auth("hospital")->user()->id;
        DB::table("hospital_service")->where(["id" => $request->id, "hid" => $userid])->update([
            "service_name" => $request->service_name,
            "amount" => $request->amount,
            "hid" => $userid,
        ]);

        return response()->json(["message" => "Updated", "data" => $request->all()]);

    }

    public function delete_service(Request $request)
    {
        $userid = auth("hospital")->user()->id;
        DB::table("hospital_service")->where(["id" => $request->id, "hid" => $userid])->delete();

        return response()->json(["message" => "Deleted", "data" => $request->all()]);

    }

    public function dates()
    {
        $data = DB::table("h_dates")->get();
        return response()->json(["data" => $data]);
    }

    public function setSchedule(Request $request)
    {
        $check = DB::table("dates")->where(["id" => $request->dates_id])->exists();
        if (!$check) {
            return response()->json(["message" => "dates_id not found!"], 400);
        }
        $doctor_id = auth("hospital")->user()->id;
        if (DB::table("hospital_schedule")->where([

            "date" => $request->dates_id,
            "time" => $request->time,
            "day" => $request->day,
            "hid" => $doctor_id,
        ])->exists()) {
            return response()->json(["message" => "Schedule Already Exists!"], 409);
        }
        DB::table("hospital_schedule")->insert([

            "date" => $request->dates_id,
            "time" => $request->time,
            "day" => $request->day,
            "hid" => $doctor_id,
        ]);
        return response()->json(["message" => "Created SuccessFully!"]);
    }

    public function updateschedule(Request $request)
    {
        $check = DB::table("dates")->where(["id" => $request->dates_id])->exists();
        if (!$check) {
            return response()->json(["message" => "dates_id not found!"], 400);
        }
        $doctor_id = auth("hospital")->user()->id;
        if (!DB::table("hospital_schedule")->where([
            "id" => $request->schedule_id,
            "hid" => auth("hospital")->user()->id,
        ])->exists()) {
            return response()->json(["message" => "Schedule Does Not Exists!"], 404);
        }
        DB::table("hospital_schedule")->where([
            "id" => $request->schedule_id,
            "hid" => auth("hospital")->user()->id,
        ])->update([

            "date" => $request->dates_id,
            "time" => $request->time,
            "day" => $request->day,

        ]);
        return response()->json(["message" => "Updated SuccessFully!"]);
    }

    public function getSchedule(Request $request)
    {
        $doctor_id = auth("hospital")->user()->id;
        $data = DB::table("hospital_schedule")->where([
            "date" => $request->dates_id,
            "hid" => $doctor_id,
        ])->get();
        return response()->json(["data" => $data]);
    }

    public function schedules(Request $request)
    {
        $doctor_id = auth("hospital")->user()->id;
        $data = DB::table("hospital_schedule")->where([
            // "date"=>$request->dates_id,
            "hid" => $doctor_id,
        ])->get();
        return response()->json(["data" => $data]);
    }

    public function deleteSchedule(Request $request)
    {
        $doctor_id = auth("hospital")->user()->id;
        $check = DB::table("hospital_schedule")->where(["id" => $request->id, "hid" => $doctor_id])->exists();
        if (!$check) {
            return response()->json(["message" => "Not Found!"], 404);
        }
        DB::table("hospital_schedule")->where(["id" => $request->id, "hid" => $doctor_id])->delete();
        return response()->json(["message" => "Deleted SuccessFully!"]);
    }

    public function lab_reports()
    {
        $data = DB::table("lab_report")->where(["lab_report.labid" => auth("lab")->user()->id])->join("lab_services", "lab_services.id", "=", "lab_report.lab_service_id")->join("patient", "patient.id", "=", "lab_services.patient_id")->select("patient.first_name", "patient.last_name", "lab_report.*")->get();
        $data23 = DB::table("lab_services")->where(["lab_services.patient_id" => $request->id])->join("lab_services", "lab_services.id", "=", "lab_report.lab_service_id")->join("patient", "patient.id", "=", "lab_services.patient_id")->select("patient.first_name", "patient.last_name", "lab_report.*")->get();
        return response()->json(["data" => $data]);
    }

    public function bookings(Request $request)
    {
        $data = DB::table("hospital_bookings")
            ->join("patient", "patient.id", "=", "hospital_bookings.userid")
            ->join("hospital_service as hospital_services", "hospital_services.id", "=", "hospital_bookings.service_id")
            ->join("hospital_schedule", "hospital_schedule.id", "=", "hospital_bookings.schedule_id")
            ->where(["hospital_bookings.hid" => auth("hospital")->user()->id])
            ->select("patient.id", "patient.first_name", "patient.last_name", "patient.image", "hospital_services.service_name", "hospital_services.amount", "hospital_schedule.date", "hospital_schedule.ampm", "hospital_schedule.time", "hospital_bookings.id as booking_id", "hospital_bookings.*")->get();

        //$data23 = DB::table("lab_services")->where(["lab_services.patient_id"=>14])->join("lab_services","lab_services.id","=","lab_report.lab_service_id")->join("patient","patient.id","=","lab_services.patient_id")->get();
        $lab_services = DB::table("lab_services")
            ->where(["lab_services.patient_id" => 14])->get();

        $lab_report = DB::table("lab_report")
            ->where(["lab_report.patient_id" => 14])->get();

        $patient = DB::table("patient")
            ->where(["patient.id" => 14])->get();

        return response()->json(["data" => $data, "lab_services" => $lab_services, "lab_report" => $lab_report, "patient" => $patient]);
    }

    public function bookingDetail(Request $request)
    {
        $lab_services = DB::table("lab_services")
            ->where(["lab_services.patient_id" => $request->patient_id])->get();

        $lab_report = DB::table("lab_report")
            ->where(["lab_report.patient_id" => $request->patient_id])->get();

        $patient = DB::table("patient")
            ->where(["patient.id" => $request->patient_id])->get();

        return response()->json(["lab_services" => $lab_services, "lab_report" => $lab_report, "patient" => $patient]);
    }

    public function view_booking(Request $request)
    {
        $data = DB::table("hospital_bookings")
            ->join("patient", "patient.id", "=", "hospital_bookings.userid")
            ->join("hospital_service as hospital_services", "hospital_services.id", "=", "hospital_bookings.service_id")
            ->join("hospital_schedule", "hospital_schedule.id", "=", "hospital_bookings.schedule_id")
            ->where(["hospital_bookings.hid" => auth("hospital")->user()->id, "hospital_bookings.id" => $request->booking_id])
            ->select("patient.first_name", "patient.last_name", "hospital_services.service_name", "hospital_services.amount", "hospital_schedule.day", "hospital_schedule.time", "hospital_bookings.id as booking_id", "patient.phone_number", "hospital_bookings.*")->first();
        return response()->json(["data" => $data]);
    }

    public function close_booking(Request $request)
    {
        $check = DB::table("hospital_bookings")->where(["hospital_bookings.hid" => auth("hospital")->user()->id, "id" => $request->booking_id])->exists();
        if (!$check) {
            return response()->json(["message" => "Not Found!"], 404);
        }

        $check = DB::table("hospital_bookings")->where(["hospital_bookings.hid" => auth("hospital")->user()->id, "id" => $request->booking_id, "status" => "declined"])->first();
        if ($check) {
            return response()->json(["message" => "Already Declined!"], 400);
        }
        $check = DB::table("hospital_bookings")->where(["hospital_bookings.hid" => auth("hospital")->user()->id, "id" => $request->booking_id, "status" => "comepleted"])->first();
        if ($check) {
            return response()->json(["message" => "Already Completed!"], 400);
        }

        DB::table("hospital_bookings")->where(["hospital_bookings.hid" => auth("hospital")->user()->id, "id" => $request->booking_id])->update(["status" => "completed"]);
        return response()->json(["message" => "Accepted!"], 200);
    }
    public function accept(Request $request)
    {
        $check = DB::table("hospital_bookings")->where(["hospital_bookings.hid" => auth("hospital")->user()->id, "id" => $request->booking_id])->exists();
        if (!$check) {
            return response()->json(["message" => "Not Found!"], 404);
        }

        $check = DB::table("hospital_bookings")->where(["hospital_bookings.hid" => auth("hospital")->user()->id, "id" => $request->booking_id, "status" => "declined"])->first();
        if ($check) {
            return response()->json(["message" => "Already Declined!"], 400);
        }
        $check = DB::table("hospital_bookings")->where(["hospital_bookings.hid" => auth("hospital")->user()->id, "id" => $request->booking_id, "status" => "comepleted"])->first();
        if ($check) {
            return response()->json(["message" => "Already Completed!"], 400);
        }

        $check = DB::table("hospital_bookings")->where(["hospital_bookings.hid" => auth("hospital")->user()->id, "id" => $request->booking_id, "status" => "accepted"])->first();
        if ($check) {
            return response()->json(["message" => "Already Accepted!"], 400);
        }

        DB::table("hospital_bookings")->where(["hospital_bookings.hid" => auth("hospital")->user()->id, "id" => $request->booking_id])->update(["status" => "accepted"]);
        return response()->json(["message" => "Accepted!"], 200);
    }

    public function get_percent2($amount)
    {
        $s = DB::table("settings")->where(["type" => "hospital_percentage"])->first();
        $percentage = $s->text;
        $totalWidth = $amount;

        $new_width = ($percentage / 100) * $totalWidth;

        return $new_width;
    }

    public function decline(Request $request)
    {
        $check1 = DB::table("hospital_bookings")->where(["hospital_bookings.hid" => auth("hospital")->user()->id, "id" => $request->booking_id])->first();
        if (!$check1) {
            return response()->json(["message" => "Not Found!"], 404);
        }

        $check = DB::table("hospital_bookings")->where(["hospital_bookings.hid" => auth("hospital")->user()->id, "id" => $request->booking_id, "status" => "declined"])->first();
        if ($check) {
            return response()->json(["message" => "Already Declined!"], 400);
        }

        DB::table("patient")->where(["id" => $check1->userid])->increment("wallet", $check1->price);

        DB::table("hospital_bookings")->where(["hospital_bookings.hid" => auth("hospital")->user()->id, "id" => $request->booking_id])->update(["status" => "declined"]);
        return response()->json(["message" => "Declined!"]);
    }

    public function complete(Request $request)
    {
        $check1 = DB::table("hospital_bookings")->where(["hospital_bookings.hid" => auth("hospital")->user()->id, "id" => $request->booking_id])->first();
        if (!$check1) {
            return response()->json(["message" => "Not Found!"], 404);
        }
        $check = DB::table("hospital_bookings")->where(["hospital_bookings.hid" => auth("hospital")->user()->id, "id" => $request->booking_id, "status" => "declined"])->first();
        if ($check) {
            return response()->json(["message" => "Already Declined!"], 400);
        }
        $check = DB::table("hospital_bookings")->where(["hospital_bookings.hid" => auth("hospital")->user()->id, "id" => $request->booking_id, "status" => "comepleted"])->first();
        if ($check) {
            return response()->json(["message" => "Already Completed!"], 400);
        }

        $amount = $this->get_percent2($check1->price);

        DB::table("hospital")->where(["id" => auth("hospital")->user()->id])->increment("wallet", $amount);
        DB::table("hospital_bookings")->where(["hospital_bookings.hid" => auth("hospital")->user()->id, "id" => $request->booking_id])->update(["status" => "completed"]);
        return response()->json(["message" => "Completed!"]);
    }

    public function hospital_review()
    {
        //important fields, and please the spelling should be thesame as the example below.
        //example: {"id":"1","patient_first_name":"Mohammed","patient_last_name":"Aliyu","rating":"2","comment":"This is a nice app","created_at":"2021-12-23 01:37:25"}

        $data = [];
        $data[] = ['id' => '1', "patient_first_name" => "Mohammed", "patient_last_name" => "Aliyu", "logistic_id" => "48", "userid" => "14", "rating" => "2", "comment" => "This is a nice app", "created_at" => "2021-12-23 01:37:25"];
        $data[] = ['id' => '2', "patient_first_name" => "Musa", "patient_last_name" => "Ibrahim", "logistic_id" => "48", "userid" => "14", "rating" => "5", "comment" => "This is a nice logistic", "created_at" => "2021-12-23 01:37:25"];
        $data[] = ['id' => '3', "patient_first_name" => "Nelson", "patient_last_name" => "Nil", "logistic_id" => "48", "userid" => "14", "rating" => "1", "comment" => "Great service", "created_at" => "2021-12-23 01:37:25"];
        $data[] = ['id' => '4', "patient_first_name" => "Godspower", "patient_last_name" => "power", "logistic_id" => "48", "userid" => "14", "rating" => "5", "comment" => "I like it", "created_at" => "2021-12-23 01:37:25"];

        $review = DB::table('hospital_review')
            ->join('patient', 'patient.id', 'hospital_review.userid')
            ->where('hospital_review.hospital_id', auth("hospital")->user()->id)
            ->select('patient.first_name as patient_first_name', 'patient.last_name as patient_last_name', 'rating', 'comment', 'hospital_review.created_at')
            ->get();
        return response()->json(["data" => $review]);
    }

    public function get_preferences()
    {
        $selected_preference = DB::table('hospital_preference')->where('hospital_id', auth('hospital')->user()->id)->get();

        return response()->json(['selected_service_preference' => $selected_preference]);
    }

    public function set_service_preferences(Request $req)
    {
        $data = "empty"; ///DB::table('pharmacy_preference')->get();

        $hospital_preference = DB::table('hospital_preference')->where('hospital_id', auth('hospital')->user()->id)->get();

        $req->amount;
        $req->preference_type;
        $req->type;
        if (count($hospital_preference) != 0) {
            $data = "not empty";
            /*

            pharmacy_id
            preference_type
            amount
            type
            created_at
             */
            DB::table("hospital_preference")->where(["hospital_id" => auth("hospital")->user()->id])->update([
                "hospital_id" => auth("hospital")->user()->id,
                "preference_type" => $req->preference_type,
                "amount" => $req->amount,
                "type" => $req->type,
            ]);
        } else {
            DB::table("hospital_preference")->insert([
                "hospital_id" => auth("hospital")->user()->id,
                "preference_type" => $req->preference_type,
                "amount" => $req->amount,
                "type" => $req->type,
            ]);
        }

        return response()->json(['data' => $data, 'pref' => $hospital_preference, 'amount' => $req->amount, 'pref_type' => $req->preference_type, 'type' => $req->type]);
    }

    public function transaction_history()
    {
        //important fields, and please the spelling should be thesame as the example below.
        //example: {"id":"1","patient_first_name":"Mohammed","patient_last_name":"Aliyu","rating":"2","comment":"This is a nice app","created_at":"2021-12-23 01:37:25"}

        $account = ["balance" => "200100", "account-type" => "Independent"];
        $transactions = [];
        $transactions[] = ['id' => '1', "status" => "Pending", "type" => "withdrawal", "amount" => "2500", "date" => "2021-12-23 01:37:25"];
        $transactions[] = ['id' => '2', "status" => "Approved", "type" => "withdrawal", "amount" => "5000", "date" => "2021-12-23 01:37:25"];
        $transactions[] = ['id' => '3', "status" => "Approved", "type" => "withdrawal", "amount" => "11000", "date" => "2021-12-23 01:37:25"];
        $transactions[] = ['id' => '4', "status" => "Approved", "type" => "withdrawal", "amount" => "760", "date" => "2021-12-23 01:37:25"];

        $data = DB::table('hospital_transactions')
            ->join('hospital', 'hospital.id', 'hospital_transactions.hospital_id')
            ->where('hospital_transactions.hospital_id', auth('hospital')->user()->id)
            ->select('hospital_transactions.*', 'hospital.wallet as balance')
            ->get();

        //$data = DB::table('hospital_transactions')->where('pharmacy_id', auth('pharmacy')->user()->id)->get();

        return response()->json(["data" => $data, "balance" => auth("hospital")->user()->wallet]);
    }

    public function withdrawal(Request $request)
    {
        $amount = $request->amount;
        if ($amount > auth("hospital")->user()->wallet) {
            return response()->json(["message" => "Insufficent Balance!"], 400);
        }

        if (auth("hospital")->user()->account_name == null) {
            return response()->json(["message" => "Account Number Required, please update account!"], 400);
        }

        if ($amount < 1000) {
            return response()->json(["message" => "You can not widthdraw amount less than 1000"], 400);
        } else {
            DB::table("hospital_transactions")->insert(["amount" => $amount, "type" => "Withdrawal", "hospital_id" => auth("hospital")->user()->id]);
            DB::table("hospital")->where(["id" => auth("hospital")->user()->id])->decrement("wallet", $amount);

            return response()->json(["message" => "Widthrawal Successful Submited, the amount will be settled in to your Account shortly"], 200);
        }

    }
}
