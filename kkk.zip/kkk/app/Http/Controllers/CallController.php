<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Hash;
use App\CentralLogics\Helpers;
use App\Models\Doctors;
use App\Models\State;
use App\Models\LGA;
use App\Models\doctorAppointment;
use DB;
use Twilio\Rest\Client;
use Mail;
  
//include "agora/VideoTokenBuilder.php";
//use agora\VideoTokenBuilder as VideoTokenBuilder;
include("agora/VideoTokenBuilder.php");

class CallController extends Controller
{
    public function makeCall(Request $request){
        //$accountType = $request->patient_id;
        if(auth("doctor")->user()){
            $uid = auth("doctor")->user()->id;
        }else if(auth("api")->user()){
            $uid = auth("api")->user()->id;
        }else{
            return response()->json(["message"=>"user not logged in properly"], 404);
        }
        $appointment_id = $request->appointment_id;
        $appointment = DB::table("doctors_appointment")->where(["id"=>$appointment_id])
                //->join("doctor_schedule","doctor_schedule.id","=","doctors_appointment.schedule_id")
                //->select("doctor_schedule.*","doctors_appointment.status","doctors_appointment.r_date","doctors_appointment.r_time","doctors_appointment.r_day")
                ->get();
        if(count($appointment)<1){
            return response()->json(["message"=>"appointment not found"], 404);
        }
        $appointment = $appointment[0];

        $channel =  "docappointment".$appointment_id;//$request->channel;

        $token = get_Token("$uid", "$channel");

        $res = Helpers::send_push_notif_to_topic(
            //"fqAEpgCQQzm5v-2q89wIb-:APA91bG3yws8LZDDoSAvVLz844BpH-dSb0yiX9eXbmKKcIhVUQys-Ky-fMbzPMRATcGDnwdGlAA9GHx-MQw4hV_Zx2Cq_NjtLUDXU6dRcO0eJ92dZXjWlkQXwksWj_E5Drr6jXqRfcvp",
            'doctor_test',
            ["title"=>"Mohammed","description"=>"Called", 'type'=>'incoming_call', 'token'=>$token, 'channel'=>$channel]
        );

        $data =  ['token' => $token, "uid" => $uid, "channel" => $channel,"appointment_id"=>$appointment_id, "res"=>$res];
        return response()->json(["data"=>$data]);

    }
    public function acceptCall(Request $request){

    }
    public function rejectCall(Request $request){

    }
    public function endCall(Request $request){

    }
}

?>