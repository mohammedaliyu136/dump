<?php

namespace App\Http\Controllers;

use App\Models\Nurses;
use App\Models\VitalSign;
use DB;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Twilio\Rest\Client;

class NursesController extends Controller
{

    public function nurse_services()
    {
        $data = DB::table("nurse_services")->get();
        return response()->json(["data" => $data]);
    }

    public function getPatientvital(Request $request)
    {
        $id = $request->id;
        $vitalSign = DB::table("VitalSign")->where('id', $id)->first();
        $patient = DB::table("patient")->where('id', $vitalSign->patient_id)->first();
        return response()->json(["vitalSign" => $vitalSign, 'patient' => $patient]);
    }

    public function getnursevital(Request $request)
    {
        $status = $request->status;
        if ($status == "all") {
            $status = [];
        } elseif ($status == "pending") {
            $status = ["VitalSign.status" => "0"];
        } else {
            $status = ["VitalSign.status" => "1"];
        }
        $data = DB::table("VitalSign")->where(["nurse_id" => auth("nurse")->user()->id])->where($status)->join("patient", "patient.id", "=", "VitalSign.patient_id")
            ->select("VitalSign.*", "patient.first_name", "patient.last_name", "patient.image")->get();
        return response()->json(["data" => $data]);
    }

    public function acceptVitalsignRequest(request $request)
    {
        $vital_sign_id = $request->input('vital_sign_id');
        if (DB::table("VitalSign")->where(["id" => $vital_sign_id, "status" => "1"])->exists()) {
            return response()->json(["message" => "Already Accepted"], 400);
        } else {
            $data = DB::table("VitalSign")->where(["id" => $vital_sign_id])->first();
            /*
            $st = \Http::patch("https://sonocare-51b1c-default-rtdb.firebaseio.com/vital/$data->ref/.json",[
            "status"=>1
            ]);
            $d = $st->object();
            if($st->failed()){
            return  response()->json(["message"=>"Something Went Wrong","error"=>$d]);
            }
             */

            DB::table("VitalSign")->where(["id" => $vital_sign_id])->update(["nurse_id" => auth("nurse")->user()->id, "status" => "1"]);
            $tnx = DB::table("nurse_transactions")->where(["vid" => $vital_sign_id])->first();
            DB::table("nurse_transactions")->where(["vid" => $vital_sign_id])->update(["nurse_id" => auth("nurse")->user()->id, "status" => "approved"]);
            DB::table("nurses")->where(["id" => auth("nurse")->user()->id])->increment("wallet", $tnx->amount);
            return response()->json(["message" => "Accepted!"]);
        }
    }

    public function complete_VitalsignRequest(request $request)
    {
        $vital_sign_id = $request->input('vital_sign_id');
        if (DB::table("VitalSign")->where(["id" => $vital_sign_id, "status" => "2"])->exists()) {
            return response()->json(["message" => "Already Completed"], 400);
        }
        $data = DB::table("VitalSign")->where(["id" => $vital_sign_id])->first();
        $st = \Http::patch("https://sonocare-51b1c-default-rtdb.firebaseio.com/vital/$data->ref/.json", [
            "status" => 2,
        ]);
        $d = $st->object();
        if ($st->failed()) {
            return response()->json(["message" => "Something Went Wrong", "error" => $d]);
        }

        DB::table("VitalSign")->where(["id" => $vital_sign_id])->update(["nurse_id" => auth("nurse")->user()->id, "status" => 2]);
        $tnx = DB::table("nurse_transactions")->where(["vid" => $vital_sign_id])->first();
        DB::table("nurse_transactions")->where(["vid" => $vital_sign_id])->update(["nurse_id" => auth("nurse")->user()->id, "status" => "completed"]);

        return response()->json(["message" => "Completed!!!"]);

    }
    public function register(Request $request)
    {

/*
if(!DB::table("nurse_services")->where(["id"=>$request->nurse_service])->exists()){
return response()->json(["message"=>"Invalid nurse services #ID".$request->nurse_service],404);
}*/
        //validate
        if (!DB::table("preferences")->where(["id" => $request->service_preferences])->exists()) {
            return response()->json(["message" => "Invalid Prefences #ID"], 404);
        }
        $check1 = Nurses::where('email', $request->email)->first();
        $check2 = Nurses::where('phone_number', $request->phone_number)->first();

        if ($check1) {
            return response()->json([
                'status' => false,
                'message' => 'Email already exists..',
            ], 409);
        } elseif ($check2) {
            return response()->json([
                'status' => false,
                'message' => 'Phone number already exists..',
            ], 409);
        } else {
            //if(!DB::table("hospital")->where(["id"=>$request->hospital_id,"status"=>1])->exists()){
            //    return response()->json(["message"=>"Hospital Not Found!"],404);
            //}
            $email_verification_code = rand(1111, 9999);
            $user = DB::table("nurses")->insert([
                'first_name' => $request->first_name,
                'other_names' => $request->other_names,
                'last_names' => $request->last_names,
                'email' => $request->email,
                'phone_number' => $request->phone_number,
                'address' => $request->address,
                'hospital_id' => $request->hospital_id,
                'password' => \Hash::make($request->password),
                "email_verification_code" => $email_verification_code,
                "nurse_type" => $request->nurse_type,
                "service_preferences" => $request->service_preferences,
                "nurse_service" => $request->nurse_service,
            ]);
            $user = DB::table("nurses")->where(["email" => $request->email])->select("first_name", "last_names", "other_names", "email", "nurse_type")->first();

            $response = [
                'user' => $user,
            ];

            /*
            // A Twilio number you own with SMS capabilities
            $twilio_number = "+14043345663";
            $account_sid = 'ACa07d9dfe8d7018ff2d519f75dcb7df84';
            $auth_token = '98ad77cf03cbffdcd030173e84c8beb9';
            $client = new Client($account_sid, $auth_token);
            $client->messages->create(
            // Where to send a text message (your cell phone?)
            "$request->phone_number",
            array(
            'from' => $twilio_number,
            'body' => "OTP verification code from sonocare: $email_verification_code"
            )
            );

             */

            $user = $user = DB::table("nurses")->where(["email" => $request->email])->select("first_name", "last_names", "other_names", "email", "nurse_type", "email_verification_code")->first();

            \Mail::send('mail', ["user" => $user], function ($message) use ($user, $request) {

                $message->to($user->email)->subject("Email Verification | SonoCare");
            });

            \Mail::send('welcome', ["user" => $user], function ($message) use ($user, $request) {

                $message->to($user->email)->subject("Personal Welcome Message  from the CEO");
            });
        }

        return response($response, 201);
    }

    public function nurselogin(Request $request)
    {
        try {
            $fields = $request->validate([
                'email' => 'required|string',
                'password' => 'required|string',
            ]);

            $credentials = request(['email', 'password']);

            if (!$token = auth("nurse")->attempt($credentials)) {
                return response()->json(['error' => 'Invalid Login Details'], 401);
            }

            if (auth("nurse")->user()->email_verification_status == 0) {
                return response()->json(["message" => "User Not Verfied!", "email" => $request->email], 401);
            }
            if (auth("nurse")->user()->status == 0) {
                return response()->json(["message" => "Account Pending For Approval!", "token" => $token], 400);
            }
            if (auth("nurse")->user()->status == 2) {
                return response()->json(["message" => "Account Have Been Disapproved!", "reason" => auth("nurse")->user()->reason_for_disapprove], 400);
            }
            return $this->respondWithToken($token);
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred"], 500);
        }

    }

    protected function respondWithToken($token)
    {
        try{
        return response()->json([
            'access_token' => $token,
            'token_type' => 'bearer',
            'expires_in' => auth("nurse")->factory()->getTTL() * 60,
            'user' => auth("nurse")->user(),
        ]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occured"], 500);
    }
    }

    public function getNurseProfile(request $request)
    {
        try{
        $nurse_id = auth("nurse")->user()->id;

        $user = Nurses::where('nurses.id', $nurse_id)->join("state", "state.id", "nurses.state_id")->join("lga", "lga.id", "=", "nurses.lga_id")->select("nurses.*", "lga.title as lga_title", "state.title as state_title")->first();
        return response()->json(['NurseProfile' => $user]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occured"], 500);
    }
    }

    public function updateNurseProfile(request $request)
    {
        try{
        $nurse_id = auth("nurse")->user()->id;

        $updateProfile = Nurses::find($nurse_id);

        $updateProfile->first_name = $request->input('first_name');
        $updateProfile->other_names = $request->input('other_name');
        $updateProfile->last_names = $request->input('last_name');
        $updateProfile->fee = $request->input('fee');
        $updateProfile->address = $request->input('address');
        $updateProfile->state_id = $request->input('state_id');
        $updateProfile->lga_id = $request->input('lga_id');

        $updateProfile->save();
        return response()->json(['status' => 'true', 'message' => 'Profile Updated Successfully']);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occured"], 500);
    }
    }

    public function getAllNurses(request $request)
    {
        try{


        $getAllNurses = Nurses::where('status', '1')->get();
        return response()->json(['getAllNurses' => $getAllNurses]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occured"], 500);
    }
    }

    public function getNurseNearby(request $request)
    {try{
        $getNurseNearby = Nurses::where('status', '1')->get();
        return response()->json(['getNurseNearby' => $getNurseNearby]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occured"], 500);
    }
    }

    public function updateVitalSign(request $request)
    {
        try{
        $vitalsign_id = $request->input('vitalsign_id');
        $updateVitalsign = VitalSign::where('id', $vitalsign_id)->where(["nurse_id" => auth("nurse")->user()->id])->first();

        if ($updateVitalsign) {
            $updateVitalsign->blood_group = $request->input('blood_group');
            $updateVitalsign->temprature = $request->input('temprature');
            $updateVitalsign->pulse_rate = $request->input('pulse_rate');
            $updateVitalsign->respiration = $request->input('respiration');
            $updateVitalsign->sp02 = $request->input('sp02');
            $updateVitalsign->body_mass = $request->input('body_mass');
            $updateVitalsign->blood_sugar = $request->input('blood_sugar');
            $updateVitalsign->height = $request->input('height');
            $updateVitalsign->weight = $request->input('weight');
            $updateVitalsign->status = 2;
            //"status"=>2

            $updateVitalsign->save();
            return response()->json(['status' => 'true', 'message' => 'vitalsign Uploaded Successfully']);

        } else {
            return response()->json(['status' => 'true', 'message' => 'Invalid vitalsign_id']);
        }
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occured"], 500);
    }
    }

    public function createVitalSign(Request $request)
    {
        try{
        $v_check = DB::table("VitalSign")->where(["patient_id" => $request->patient_id, "nurse_id" => auth("nurse")->user()->id])->first();
        if ($v_check) {
            return response()->json(["message" => "Vital Sign With This Patient Already Exists, Update Vital Sign!", "id" => $v_check->id], 409);
        }
        $check1 = DB::table("patient")->where(["id" => $request->patient_id])->exists();
        if (!$check1) {
            return response()->json(["message" => "Patient Not Found!"], 404);
        }

        $updateVitalsign = new VitalSign();
        $updateVitalsign->blood_group = $request->input('blood_group');
        $updateVitalsign->temprature = $request->input('temprature');
        $updateVitalsign->pulse_rate = $request->input('pulse_rate');
        $updateVitalsign->respiration = $request->input('respiration');
        $updateVitalsign->sp02 = $request->input('sp02');
        $updateVitalsign->patient_id = $request->patient_id;
        $updateVitalsign->nurse_id = auth("nurse")->user()->id;
        $updateVitalsign->body_mass = $request->input('body_mass');

        $updateVitalsign->save();
        return response()->json(['status' => 'true', 'message' => 'vitalsign Uploaded Successfully']);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occured"], 500);
    }
    }

    public function verification(Request $request)
    {
        try{
        $email = $request->email;
        $token = $request->token;
        $user = DB::table("nurses")->where(["email" => $email, "email_verification_code" => $token])->first();
        if ($user) {
            DB::table("nurses")->where(["email" => $email, "email_verification_code" => $token])->update(["email_verification_status" => 1, "phone_number_verification_status" => 1]);
            return response()->json(["message" => "User Verified!"]);

        } else {
            return response()->json(["message" => "Invalid OTP provided!"], 404);
        }
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occured"], 500);
    }
    }

    public function step1verification(Request $request)
    {
        try{
        $userid = auth("nurse")->user()->id;
        $check = DB::table("n_step1")->where(["nurse_id" => $userid])->exists();
        if ($check) {
            return response()->json(["message" => "Already Registered!"], 400);
        } else {

            $passport_name = time() . $request->passport->getClientOriginalName();
            $request->passport->move(public_path('uploads'), $passport_name);

            DB::table("n_step1")->insert([
                "gender" => $request->gender,
                "speciality" => $request->speciality,
                "nurse_id" => $userid,
                "language" => $request->language,
                "mcdn" => $request->mcdn,
                "speciality_code" => $request->speciality_code,
                "passport" => "/uploads/$passport_name",
            ]);
            return response()->json(["message" => "Success!"]);
        }
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occured"], 500);
    }
    }

    public function step2verification(Request $request)
    {
        try{
        $userid = auth("nurse")->user()->id;
        $check = DB::table("n_step2")->where(["nurse_id" => $userid])->exists();
        if ($check) {
            return response()->json(["message" => "Already Registered!"], 400);
        } else {

            $id_card = time() . $request->id_card->getClientOriginalName();
            $request->id_card->move(public_path('uploads'), $id_card);

            DB::table("n_step2")->insert([
                "country" => $request->country,
                "state" => $request->state,
                "nurse_id" => $userid,
                "refer" => $request->refer,
                "account_number" => $request->account_number,
                "account_name" => $request->account_name,
                "bank_code" => $request->bank_code,
                "id_card" => "/uploads/$id_card",
            ]);
            return response()->json(["message" => "Success!"]);
        }
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occured"], 500);
    }
    }

    public function step3verification(Request $request)
    {
        try{
        $userid = auth("nurse")->user()->id;
        $check = DB::table("n_step3")->where(["nurse_id" => $userid])->exists();
        if ($check) {
            return response()->json(["message" => "Already Registered!"], 400);
        } else {

            $deg_cert = time() . $request->deg_cert->getClientOriginalName();
            $request->deg_cert->move(public_path('uploads'), $deg_cert);

            $med_license = time() . $request->med_license->getClientOriginalName();
            $request->med_license->move(public_path('uploads'), $med_license);

// $backing_info = time().$request->backing_info->getClientOriginalName();
// $request->backing_info->move(public_path('uploads'), $backing_info);

            DB::table("n_step3")->insert([
                "nurse_id" => $userid,
                "deg_cert" => "/uploads/$deg_cert",
                "med_license" => "/uploads/$med_license",
                //   "backing_info"=>"/uploads/$backing_info",
                "about" => $request->about,
            ]);
            return response()->json(["message" => "Success!"]);
        }
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occured"], 500);
    }
    }

    public function step4verification(Request $request)
    {
        try{
        $userid = auth("nurse")->user()->id;

        DB::table("n_step4")->insert([
            "company" => $request->company,
            "from" => $request->from,
            "nurse_id" => $userid,
            "to" => $request->to,
            "current" => $request->current,

        ]);
        return response()->json(["message" => "Success!"]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occured"], 500);
    }
    }

    public function setfee(Request $request)
    {
        try{
        DB::table("nurses")->where(["id" => auth("nurse")->user()->id])->update(["fee" => $request->fee]);
        return response()->json(["message" => "Updated Successfully!", "data" => auth("nurse")->user()]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occured"], 500);
    }
    }

    public function get_nurse_service_fee(Request $request)
    {
        try{
            //->where(["nurse_id"=>auth("nurse")->user()->id]) auth("nurse")->user()->id
        if (auth("nurse")->user()) {
            $nurse_services = DB::table('nurse_services')
                ->leftJoin('nurse_service_fee', function ($join) {
                    $join->on('nurse_services.id', '=', 'nurse_service_fee.service_id')
                        ->where("nurse_service_fee.nurse_id", "=", auth("nurse")->user()->id);
                })
                ->select('nurse_services.*', 'nurse_service_fee.charge')->get();
            return response()->json(["nurse_services" => $nurse_services]);
        } else {
            $data = DB::table("nurse_services")->get();
            return response()->json(["nurse_services" => $data]);
        }
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occured"], 500);
    }
    }

    public function set_nurse_service_fee(Request $request)
    {
       try{ $check = DB::table("nurse_service_fee")->where(["nurse_id" => auth("nurse")->user()->id])->where(["service_id" => $request->service_id])->exists();

        if (!$check) {
            DB::table("nurse_service_fee")->insert([
                "service_id" => $request->service_id,
                "nurse_id" => auth("nurse")->user()->id,
                "charge" => $request->charge,
            ]);
        } else {
            DB::table("nurse_service_fee")->where(["nurse_id" => auth("nurse")->user()->id, "service_id" => $request->service_id])->update([
                "service_id" => $request->service_id,
                "nurse_id" => auth("nurse")->user()->id,
                "charge" => $request->charge,
            ]);
        }
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occured"], 500);
    }
    }

    public function nurse_type()
    {
        return response()->json(["data" => DB::table("nurse_type")->get()]);
    }

    public function preferences()
    {
        return response()->json(["data" => DB::table("preferences")->get()]);
    }

    public function resetpass(Request $request)
    {
        try {
            $email = $request->email;
            $check = DB::table("nurses")->where(["email" => $email])->first();
            if (!$check) {
                return response()->json(["message" => "Email Not Found!"], 404);
            }
            $token = rand(1111, 9999);

            // Your Account SID and Auth Token from twilio.com/console
            $account_sid = 'ACa07d9dfe8d7018ff2d519f75dcb7df84';
            $auth_token = '98ad77cf03cbffdcd030173e84c8beb9';
// In production, these should be environment variables. E.g.:
// $auth_token = $_ENV["TWILIO_AUTH_TOKEN"]

// A Twilio number you own with SMS capabilities
            $twilio_number = "+14043345663";

            $client = new Client($account_sid, $auth_token);
            $client->messages->create(
                // Where to send a text message (your cell phone?)
                "$check->phone_number",
                array(
                    'from' => $twilio_number,
                    'body' => "OTP verification code from sonocare: $token",
                )
            );

            DB::table("nurses")->where(["email" => $email])->update(["resettoken" => $token]);

            \Mail::send('reset', ["user" => $check, "resettoken" => $token], function ($message) use ($check, $request) {

                $message->to($check->email)->subject("Reset Password | SonoCare");
            });

            return response()->json(["message" => "Reset password OTP sent!"]);
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occured"], 500);
        }
    }

    public function setpass(Request $request)
    {try {
        $otp = $request->otp;
        $email = $request->email;
        $password = $request->password;
        $data = DB::table("nurses")->where(["email" => $email, "resettoken" => $otp])->first();
        if (!$data) {
            return response()->json(["message" => "Invalid OTP provided"], 404);
        }
        DB::table("nurses")->where(["email" => $email])->update(["password" => \Hash::make($password)]);
        return response()->json(["message" => "Passowrd Reset Was SuccessFul"]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occured"], 500);
    }}

    public function nuseupdateimage(Request $request)
    {
        try {
            $image = $request->image;

            $image_name = time() . $request->image->getClientOriginalName();
            $request->image->move(public_path('uploads'), $image_name);
            DB::table("nurses")->where(["id" => auth("nurse")->user()->id])->update(["image" => "/uploads/$image_name"]);
            return response()->json(["message" => "Updated SuccessFully!", "image" => "/uploads/$image_name"]);
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occured"], 500);
        }
    }

    public function transactions()
    {
        try {
            $data = DB::table("nurse_transactions")->where(["nurse_id" => auth("nurse")->user()->id])->get();
            return response()->json(["data" => $data, 'balance' => auth("nurse")->user()->wallet, 'account_type' => auth("nurse")->user()->nurse_type]);
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occured"], 500);
        }
    }

    public function withdrawal(Request $request)
    {try {
        $amount = $request->amount;
        if ($amount > auth("nurse")->user()->wallet) {
            return response()->json(["message" => "Insufficent Balance!"], 400);
        }

        if (auth("nurse")->user()->account_name == null) {
            return response()->json(["message" => "Account Number Required, please update account!"], 400);
        }

        if ($amount < 1000) {
            return response()->json(["message" => "You can not widthdraw amount less than 1000"], 400);
        } else {
            DB::table("nurse_transactions")->insert(["amount" => $amount, "type" => "Withdrawal", "nurse_id" => auth("nurse")->user()->id]);
            DB::table("nurses")->where(["id" => auth("nurse")->user()->id])->decrement("wallet", $amount);
            $data = DB::table("nurse_transactions")->where(["nurse_id" => auth("nurse")->user()->id, "type" => "Withdrawal"])->get();
            return response()->json(["message" => "Widthrawal Successful Submited, the amount will be settled in to your Account shortly"], 200);
        }

    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occured"], 500);
    }}

    public function update_account(Request $request)
    {
        try {
            $account_number = $request->account_number;
            $account_name = $request->account_name;
            $account_bank = $request->account_bank;
            $bank_code = $request->bank_code;
            $update = DB::table("nurses")->where(["id" => auth("nurse")->user()->id])->update(compact("account_number", "account_name", "account_bank", "bank_code"));
            if ($update) {
                return response()->json(["message" => "Updated!"]);
            }
            return response()->json(["message" => "Record Alredy Updated!"]);
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occured"], 500);
        }
    }

    public function update_fcm(Request $request)
    {
        try {
            $token = $request->token;
            DB::table("nurses")->where(["id" => auth("nurse")->user()->id])->update(["fcm_token" => $token]);
            return response()->json(["message" => "Updated!", "token" => $token]);
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occured"], 500);
        }
    }

    public function reviews()
    {
        try {

            $data = DB::table("nurse_review")
                ->join("patient", "patient.id", "=", "nurse_review.userid")
                ->where(["nurse_review.nurse_id" => auth("nurse")->user()->id])
            //   ->select("nurse_review.*","patient.first_name as patient_first_name","patient.last_name as patient_last_name")
                ->get();

            return response()->json(["data" => $data]);
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occured"], 500);
        }
    }

    ///============================================================================

    public function accept_pickup(Request $request)
    {
        /*
        $data = \Http::get("https://sonocare-51b1c-default-rtdb.firebaseio.com/pickup/$request->firebase_id.json");

        $data = $data->object();

        if($data == null){
        return response()->json(["message"=>"Something went wrong, check firebase id"],400);
        }
        if($data->status == "ongoing"){
        return response()->json(["message"=>"Request Already Accepted!"],400);
        }

        \Http::patch("https://sonocare-51b1c-default-rtdb.firebaseio.com/pickup/$request->firebase_id.json",[

        "logistic"=>auth("logistic")->user()->id,
        "status"=>"ongoing"

        ]);*/

        DB::table("pickup")->where(["id" => $request->requestID])->update([

            "nurse_id" => auth("nurse")->user()->id,
            "status" => "ongoing",

        ]);

        return response()->json(["message" => "Accepted"]);

    }

    public function complete_pickup(Request $request)
    {
        /*
        $data = \Http::get("https://sonocare-51b1c-default-rtdb.firebaseio.com/pickup/$request->firebase_id.json");

        $data = $data->object();

        if($data == null){
        return response()->json(["message"=>"Something went wrong, check firebase id"],400);
        }
        if($data->status == "completed"){
        return response()->json(["message"=>"Request Already Completed!"],400);
        }

        $p = DB::table("settings")->where(["type"=>"logistic_percentage"])->first();
        $percentInDecimal = $p->text / 100;

        $percent = $percentInDecimal * $p->text;

        \Http::patch("https://sonocare-51b1c-default-rtdb.firebaseio.com/pickup/$request->firebase_id.json",[

        "status"=>"completed"

        ]);
         */
        $p = DB::table("settings")->where(["type" => "logistic_percentage"])->first();
        $percentInDecimal = $p->text / 100;

        $percent = $percentInDecimal * $p->text;

        DB::table("pickup")->where(["id" => $request->requestID])->update([

            "status" => "completed",

        ]);
        DB::table("nurses")->where(["id" => auth("nurse")->user()->id])->increment("wallet", $percent);
        return response()->json(["message" => "Completed"]);

    }

    public function cancel_pickup(Request $request)
    {

        DB::table("pickup")->where(["id" => $request->requestID])->update([

            "status" => "canceled",

        ]);
        return response()->json(["message" => "Pickup canceled"]);
    }

    public function my_pickup()
    {
        // "pickup.id","pickup.labid","pickup.pharmacy_id","pickup.pid","pickup.from_address","pickup.to_address","pickup.distance","pickup.phone_number","pickup.logistic","pickup.is_nurse","pickup.is_lab_scientist","pickup.status","pickup.price","pickup.user_lat","pickup.user_lng","pickup.firebase_id","pickup.created_at","pickup.patient_name","pickup.image","pharmacy.name AS pharmacy_name","pharmacy.phone AS pharmacy_phone",DB::raw("CONCAT(pickup.first_name, ' ', pickup.last_name) AS patient_name"
        //$data =  DB::table("pickup")->where(["logistic"=>auth("nurse")->user()->id])->join("pharmacy","pharmacy.id","=","pickup.pharmacy_id")->join("patient","patient.id","=","pickup.pid")->select("pickup.*",DB::raw("CONCAT(pickup.first_name, ' ', pickup.last_name) AS patient_name"), "patient.image")->get();
        $data = DB::table("pickup")->where(["nurse_id" => auth("nurse")->user()->id])->join("pharmacy", "pharmacy.id", "=", "pickup.pharmacy_id")->join("patient", "patient.id", "=", "pickup.pid")->select("pickup.id", "pickup.labid", "pickup.pharmacy_id", "pickup.pid", "pickup.from_address", "pickup.to_address", "pickup.distance", "pickup.phone_number", "pickup.logistic", "pickup.is_nurse", "pickup.is_lab_scientist", "pickup.status", "pickup.price", "pickup.user_lat", "pickup.user_lng", "pickup.firebase_id", "pickup.created_at", "patient.image", "pharmacy.name AS pharmacy_name", "pharmacy.phone AS pharmacy_phone", DB::raw("CONCAT(patient.first_name, ' ', patient.last_name) AS patient_name"))->get();

        return response()->json(["data" => $data, "id" => auth("nurse")->user()->id]);
    }
}
