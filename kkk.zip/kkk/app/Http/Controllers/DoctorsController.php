<?php

namespace App\Http\Controllers;

use App\Models\doctorAppointment;
use App\Models\Doctors;
use App\Models\LGA;
use App\Models\State;
use DB;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Twilio\Rest\Client;

//include "agora/VideoTokenBuilder.php";
//use agora\VideoTokenBuilder as VideoTokenBuilder;
include "agora/VideoTokenBuilder.php";

class DoctorsController extends Controller
{

    public function dgetPatientProfile(Request $request)
    {
        $id = $request->patient_id;
        $patient = DB::table("patient")->where(["id" => $id])->first();
        $vital = DB::table("VitalSign")->where(["patient_id" => $id])->get();
        $pres = DB::table("prescription")->where(["patient_id" => $id])->get();
        $lab = DB::table("lab_services")
            ->join("lab_report", "lab_report.lab_service_id", "=", "lab_services.id")
            ->join("laboratories", "laboratories.id", "=", "lab_report.labid")
            ->select("lab_report.*", "lab_services.amount", "laboratories.name as labname", "laboratories.image as labimage")->get();
        return response()->json(["data" => $patient, "vitalsign" => $vital, "prescription" => $pres, "lab" => $lab]);
    }
    public function DoctorRegistration(Request $request)
    {
        try {
            $fields = $request->validate([
                'first_name' => 'required|string',
                'other_name' => 'required|string',
                'last_name' => 'required|string',
                'email' => 'required',
                'phone_number' => 'required',
                'password' => 'required',
                'doctor_type' => 'required',
            ]);

            if (!DB::table("preferences")->where(["id" => $request->service_preferences])->exists()) {
                return response()->json(["message" => "Invalid Prefences #ID"], 404);
            }
            // Available alpha caracters
            $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

// generate a pin based on 2 * 7 digits + a random character
            $pin = mt_rand(1, 9)
            . mt_rand(10, 99)
                . $characters[rand(0, strlen($characters) - 1)];

// shuffle the result
            $email_verification_code = rand(1111, 9999);

            //validate
            $check1 = Doctors::where('email', $fields['email'])->first();
            $check2 = Doctors::where('phone_number', $fields['phone_number'])->first();

            if ($check1) {
                return response()->json([
                    'status' => false,
                    'message' => 'Email already exists..',
                ], 409);
            } elseif ($check2) {
                return response()->json([
                    'status' => false,
                    'message' => 'Phone number already exists..',
                ], 409);
            } else {
                $user = Doctors::create([
                    'first_name' => $fields['first_name'],
                    'other_name' => $fields['other_name'],
                    'last_name' => $fields['last_name'],
                    'email' => $fields['email'],
                    'doctor_type' => $fields['doctor_type'],
                    'phone_number' => $fields['phone_number'],
                    'password' => bcrypt($fields['password']),
                    'email_verification_code' => $email_verification_code,
                    "service_preferences" => $request->service_preferences,

                ]);
                $user = DB::table("doctors")->where(["email" => $request->email])->first();

                $response = [
                    'message' => "Registration Was Success!",
                    'email' => $user->email,
                ];
                // A Twilio number you own with SMS capabilities
                /*
                $twilio_number = "+14043345663";
                $account_sid = 'ACa07d9dfe8d7018ff2d519f75dcb7df84';
                $auth_token = '98ad77cf03cbffdcd030173e84c8beb9';
                $client = new Client($account_sid, $auth_token);
                $client->messages->create(
                // Where to send a text message (your cell phone?)
                "$request->phone_number",
                array(
                'from' => $twilio_number,
                'body' => "OTP verification code from sonocare: $email_verification_code"
                )
                );*/

                /*
                $twilio_number = "sonocare";
                $account_sid = 'ACa07d9dfe8d7018ff2d519f75dcb7df84';
                $auth_token = '98ad77cf03cbffdcd030173e84c8beb9';
                $client = new Client($account_sid, $auth_token);
                $client->messages->create(
                // Where to send a text message (your cell phone?)
                "+234$request->phone_number",
                array(
                'from' => $twilio_number,
                'body' => "OTP verification code from sonocare: $email_verification_code"
                )
                );*/

                // \Mail::send('mail', ["user" => $user], function ($message) use ($user, $request) {

                //     $message->to($user->email)->subject("Email Verification | SonoCare");
                // });

                // \Mail::send('welcome', ["user" => $user], function ($message) use ($user, $request) {

                //     $message->to($user->email)->subject("Personal Welcome Message  from the CEO");
                // });

            }
            return response($response, 201);
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred" . $e->getMessage()], 500);
        }
    }

    public function doctorlogin(Request $request)
    {
        try {

            $fields = $request->validate([
                'email' => 'required|string',
                'password' => 'required|string',
            ]);

            $credentials = request(['email', 'password']);

            if (!$token = auth("doctor")->attempt($credentials)) {
                return response()->json(['error' => 'Invalid Login Details'], 401);
            }

            if (auth("doctor")->user()->email_verification_status == 0) {
                return response()->json(["message" => "User Not Verfied!", "email" => $request->email], 401);
            }

            if (auth("doctor")->user()->status == 0) {
                return response()->json(["message" => "Doctor Not Verified!", "token" => $token], 400);
            }

            if (auth("doctor")->user()->status == 2) {
                return response()->json(["message" => "Account Have Been Disapproved!", "reason" => auth("doctor")->user()->reason_for_disapprove], 400);
            }
            return $this->respondWithToken($token);
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
        }

    }

    protected function respondWithToken($token)
    {
        try {
            return response()->json([
                'access_token' => $token,
                'token_type' => 'bearer',
                'expires_in' => auth("doctor")->factory()->getTTL() * 60,
                'user' => auth("doctor")->user(),
            ]);
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred"], 500);
        }
    }

    public function getDoctorProfile(request $request)
    {
        try {
            $doctor_id = auth("doctor")->user()->id;

            $user = Doctors::where('doctors.id', $doctor_id)
                ->join("state", "state.id", "doctors.state_id")
                ->join("lga", "lga.id", "=", "doctors.lga_id")
                ->select("doctors.*", "lga.title as lga_title", "state.title as state_title")->first();
            $hospital = DB::table("hospital")->where(["id" => $user->hospital_id])->first();
            return response()->json(['DoctorProfile' => $user, "hospital" => $hospital]);
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred"], 500);
        }
    }

    public function updateDoctorProfile(request $request)
    {
        try {
            $doctor_id = auth("doctor")->user()->id;

            $updateProfile = Doctors::find($doctor_id);

            $updateProfile->first_name = $request->input('first_name');
            $updateProfile->other_name = $request->input('other_name');
            $updateProfile->last_name = $request->input('last_name');

            $updateProfile->address = $request->input('address');
            $updateProfile->state_id = $request->input('state_id');
            $updateProfile->lga_id = $request->input('lga_id');
            $updateProfile->language = $request->input('language');
            $updateProfile->gender = $request->input('gender');

            $updateProfile->save();
            return response()->json(['status' => 'true', 'message' => 'Profile Updated Successfully', "data" => $request->all()]);
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred"], 500);
        }
    }

    public function getPatientProfile(Request $request)
    {try {
        $data = DB::table("patient")->where(["id" => $request->id])->first();
        $pres = DB::table("prescription")->where(["patient_id" => $request->id])->get();

        return response()->json(["data" => $data, "prescription" => $pres]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred"], 500);
    }}

    public function verifyAccount(request $request)
    {
        try {
            $doctor_id = auth("doctor")->user()->id;

            $updateProfile = Doctors::find($doctor_id);

            $updateProfile->gender = $request->input('gender');
            $updateProfile->language = $request->input('language');
            $updateProfile->mcdn_number = $request->input('mcdn_number');
            $updateProfile->speciality_code = $request->input('speciality_code');
            $updateProfile->other_language = $request->input('other_language');
            $updateProfile->picture = $request->input('picture');
            $updateProfile->campany_organisation = $request->input('campany_organisation');
            $updateProfile->working_from = $request->input('working_from');
            $updateProfile->working_to = $request->input('working_to');
            $updateProfile->service_fee = $request->input('service_fee');
            $updateProfile->country = $request->input('country');
            $updateProfile->refered_by = $request->input('refered_by');
            $updateProfile->degree_cert = $request->input('degree_cert');
            $updateProfile->medical_licence = $request->input('medical_licence');
            $updateProfile->backing_inform = $request->input('backing_inform');
            $updateProfile->about_me = $request->input('about_me');

            $updateProfile->save();
            return response()->json(['status' => 'true', 'message' => 'Profile Updated Successfully', "data" => $request->all()]);
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred"], 500);
        }
    }

    public function setConsultationFee(Request $request)
    {
        try {
             $doctor_id = auth("doctor")->user()->id;
            $check = DB::table("doctors_services")->where(["doctor_id" => $doctor_id])->exists();
            if (!$check) {
                //return response()->json(["message"=>"Not Found!"],404);
                DB::table("doctors_services")->where(["doctor_id" => $doctor_id])->insert([
                    "services_type" => $request->type,
                    "price" => $request->consultation_fee,
                    "doctor_id" => $doctor_id,
                ]);
            } else {
                DB::table("doctors_services")->where(["doctor_id" => $doctor_id])->update([
                    "services_type" => $request->type,
                    "price" => $request->consultation_fee,
                    "doctor_id" => $doctor_id,
                ]);
            }
            /*
            DB::table("doctors_services")->insert([
            "services_type"=>$request->type,
            "price"=>$request->consultation_fee,
            "doctor_id"=>$doctor_id
            ]);
             */
            return response()->json(["message" => "Created SuccessFully!"]);
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred"], 500);
        }
    }

    public function getConsultationFee(Request $request)
    {
        try {
            $doctor_id = auth("doctor")->user()->id;
            $data = DB::table("doctors_services")->where([

                "doctor_id" => $doctor_id,
            ])->get();
            return response()->json(["data" => $data]);
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred"], 500);
        }
    }

    public function updateConsultationFee(Request $request)
    {
        try {
            $doctor_id = auth("doctor")->user()->id;
            $check = DB::table("doctors_services")->where(["id" => $request->id, "doctor_id" => $doctor_id])->exists();
            if (!$check) {
                return response()->json(["message" => "Not Found!"], 404);
            }
            DB::table("doctors_services")->where(["id" => $request->id, "doctor_id" => $doctor_id])->update([
                "services_type" => $request->type,
                "price" => $request->consultation_fee,

            ]);
            return response()->json(["message" => "Updated SuccessFully!"]);
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred"], 500);
        }
    }

    public function deleteConsultationFee(Request $request)
    {
        try {
            $doctor_id = auth("doctor")->user()->id;
            $check = DB::table("doctors_services")->where(["id" => $request->id, "doctor_id" => $doctor_id])->exists();
            if (!$check) {
                return response()->json(["message" => "Not Found!"], 404);
            }
            DB::table("doctors_services")->where(["id" => $request->id, "doctor_id" => $doctor_id])->delete();
            return response()->json(["message" => "Deleted SuccessFully!"]);
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred"], 500);
        }
    }

    public function getAllDoctors()
    {
        try {

            $allDoctors = Doctors::where('status', '1')->get();
            return response()->json(['allDoctors' => $allDoctors]);
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred"], 500);
        }
    }

    public function getAllGeneralDoctors()
    {
        try {
            $allDoctors = Doctors::where('status', '1')
                ->where('doctor_type', 'General Practitioners')
                ->get();
            return response()->json(['generalDoctors' => $allDoctors]);
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred"], 500);
        }
    }

    public function getAllSpecialistDoctors(Request $request)
    {
        try {
            $allDoctors = Doctors::where('status', '1')
                ->where('doctor_type', $request->type)
                ->get();
            return response()->json(['generalDoctors' => $allDoctors]);
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred"], 500);
        }
    }

    public function getDoctorbyRating()
    {

        $allDoctors = Doctors::where('status', '1')
            ->orderBy('rating', 'desc')
            ->take(5)
            ->get();
        return response()->json(['getDoctorbyRating' => $allDoctors]);
    }

    public function doctorverifyemail(request $request)
    {

        $doctor_id = $request->input('email');
        $email_verification_code = $request->input('email_verification_code');
        $Profile = Doctors::where(["email" => $doctor_id])->first();
        if ($Profile != null) {
            $emailverificationcode = $Profile->email_verification_code;

            if ($emailverificationcode == $email_verification_code) {

                Doctors::where(["email" => $doctor_id])->update(['email_verification_status' => 1]);
                return response()->json(['status' => 'true', 'message' => 'Email verified Successfully']);

            } else {
                return response()->json(['status' => 'true', 'message' => 'Invalid Email Verification code']);
            }
        } else {
            return response()->json(["message" => "Invalid Email!"], 404);
        }

    }

    public function getAlAppointments(request $request)
    {
        $doctor_id = auth("doctor")->user()->id;
        $Chk = DB::table("doctors_appointment")->where(["doctor_schedule.doctor_id" => auth("doctor")->user()->id])
            ->join("doctor_schedule", "doctor_schedule.id", "=", "doctors_appointment.schedule_id")
            ->select("doctor_schedule.*", "doctors_appointment.status", "doctors_appointment.r_date", "doctors_appointment.r_time", "doctors_appointment.r_day")
            ->join("patient", "patient.id", "=", "doctors_appointment.patient_id")

            ->select("patient.first_name", "patient.image", "doctors_appointment.*", "doctor_schedule.time as schedule_time", "doctor_schedule.day as schedule_day")
            ->get();

        if (isset($_GET['status'])) {
            $Chk = DB::table("doctors_appointment")->where(["doctor_schedule.doctor_id" => auth("doctor")->user()->id, "status" => $_GET['status']])->join("doctor_schedule", "doctor_schedule.id", "=", "doctors_appointment.schedule_id")->select("doctor_schedule.*", "doctors_appointment.status", "doctors_appointment.r_date", "doctors_appointment.r_time", "doctors_appointment.r_day")
                ->join("patient", "patient.id", "=", "doctors_appointment.patient_id")
                ->select("patient.first_name", "patient.image", "doctors_appointment.*")
                ->get();

        }

        return response()->json(['message' => 'ok', 'data' => $Chk]);
    }

    public function AcceptAppointmentment(request $request)
    {
        $appointment_id = $request->input('id');
        if (!DB::table("doctors_appointment")->where(["id" => $request->id])->exists()) {
            return response()->json(["message" => "Appointment Not Found!"], 404);
        }
        $update = DB::table("doctors_appointment")->where(["id" => $appointment_id])->update(["status" => "1"]);

        $data = DB::table("doctors_appointment")->where(["doctor_schedule.doctor_id" => auth("doctor")->user()->id])->join("doctor_schedule", "doctor_schedule.id", "=", "doctors_appointment.schedule_id")->select("doctor_schedule.*", "doctors_appointment.status", "doctors_appointment.r_date", "doctors_appointment.r_time", "doctors_appointment.r_day")->get();

        return response()->json(['message' => 'Appointment Accepted Successfuly', 'data' => $data]);

    }

    public function DeclineAppointmentment(request $request)
    {
        $appointment_id = $request->input('id');
        if (!DB::table("doctors_appointment")->where(["id" => $request->id])->exists()) {
            return response()->json(["message" => "Appointment Not Found!"], 404);
        }
        $update = DB::table("doctors_appointment")->where(["id" => $appointment_id])->update(["status" => "2", "r_date" => $request->r_date, "r_time" => $request->r_time, "r_day" => $request->r_day]);

        $data = DB::table("doctors_appointment")->where(["doctor_schedule.doctor_id" => auth("doctor")->user()->id])->join("doctor_schedule", "doctor_schedule.id", "=", "doctors_appointment.schedule_id")->select("doctor_schedule.*", "doctors_appointment.status", "doctors_appointment.r_date", "doctors_appointment.r_time", "doctors_appointment.r_day")->get();

        return response()->json(['message' => 'Appointment Declined Successfuly', 'data' => $data]);
    }

    public function closeAppointmentment(request $request)
    {
        $appointment_id = $request->input('id');
        if (!DB::table("doctors_appointment")->where(["id" => $request->id])->exists()) {
            return response()->json(["message" => "Appointment Not Found!"], 404);
        }
        $update = DB::table("doctors_appointment")->where(["id" => $appointment_id])->update(["status" => "3"]);

        return response()->json(['message' => 'Appointment Declined Successfuly'], 200);
    }

    public function AppointmentDetails(Request $request)
    {
        $doctor_id = auth("doctor")->user()->id;
        $Chk = DB::table("doctors_appointment")->where(["doctor_schedule.doctor_id" => $doctor_id, "doctor_schedule.id" => $request->id])->join("doctor_schedule", "doctor_schedule.id", "=", "doctors_appointment.schedule_id")->select("doctor_schedule.*", "doctors_appointment.status", "doctors_appointment.r_date", "doctors_appointment.r_time", "doctors_appointment.r_day")->first();

        if (!$Chk) {
            return response()->json(["message" => "Appointment Not Found!"], 404);
        }

        return response()->json(['message' => 'ok', 'data' => $Chk]);
    }

    public function getAllState()
    {
        $state = State::where('published', '1')->get();
        return response()->json(['getAllState' => $state]);
    }

    public function getLGAByStateID(request $request)
    {
        $state_id = $request->input('state_id');
        $LGA = LGA::where('state_id', $state_id)->get();
        return response()->json(['LGA' => $LGA]);
    }

    public function setSchedule(Request $request)
    {
        $check = DB::table("dates")->where(["id" => $request->dates_id])->exists();
        if (!$check) {
            return response()->json(["message" => "dates_id not found!"], 400);
        }
        $doctor_id = auth("doctor")->user()->id;
        /*
        if( DB::table("doctor_schedule")->where([

        "date"=>$request->dates_id,
        "time"=>$request->time,
        "day"=>$request->day,
        "doctor_id"=>$doctor_id
        ])->exists()){
        return response()->json(["message"=>"Schedule Already Exists!"],409);
        }
        DB::table("doctor_schedule")->insert([

        "date"=>$request->dates_id,
        "time"=>$request->time,
        "day"=>$request->day,
        "doctor_id"=>$doctor_id
        ]);
         */

        if (DB::table("doctor_schedule")->where([

            "date" => $request->date,
            "time" => $request->time,
            "day" => $request->dates_id,
            "doctor_id" => $doctor_id,
        ])->exists()) {
            return response()->json(["message" => "Schedule Already Exists!"], 409);
        }
        DB::table("doctor_schedule")->insert([

            "date" => $request->date,
            "time" => $request->time,
            "day" => $request->dates_id,
            "doctor_id" => $doctor_id,
        ]);

        return response()->json(["message" => "Created SuccessFully!"]);
    }

    public function updateschedule(Request $request)
    {
        $check = DB::table("dates")->where(["id" => $request->dates_id])->exists();
        if (!$check) {
            return response()->json(["message" => "dates_id not found!"], 400);
        }
        $doctor_id = auth("doctor")->user()->id;
        if (!DB::table("doctor_schedule")->where([
            "id" => $request->schedule_id,
            "doctor_id" => auth("doctor")->user()->id,
        ])->exists()) {
            return response()->json(["message" => "Schedule Does Not Exists!"], 404);
        }
        DB::table("doctor_schedule")->where([
            "id" => $request->schedule_id,
            "doctor_id" => auth("doctor")->user()->id,
        ])->update([

            "date" => $request->dates_id,
            "time" => $request->time,
            "day" => $request->day,

        ]);
        return response()->json(["message" => "Updated SuccessFully!"]);
    }

    public function getSchedule(Request $request)
    {
        $data = DB::table("doctor_schedule")->where([
            "date" => $request->date,
            "doctor_id" => auth('doctor')->user()->id,
        ])->get();
        return response()->json(["data" => $data]);
    }

    public function dates()
    {
        $data = DB::table("dates")->get();
        return response()->json(["data" => $data]);
    }

    //   public function updateSchedule(Request $request){
    //       $appointment_id=$request->input('appointment_id');
    //      if(!DoctorAppointment::where(["consultation_id"=>$appointment_id,"doctor_id"=>auth("doctor")->user()->id])->exists()){
    //          return response()->json(["message"=>"Appointment Not Found!"],404);
    //      }
    //     $update = DoctorAppointment::where(["consultation_id"=>$appointment_id,"doctor_id"=>auth("doctor")->user()->id])->update(["time"=>$request->time,"appintment_date"=>$request->date]);

    //     $data =  DoctorAppointment::where(["consultation_id"=>$appointment_id,"doctor_id"=>auth("doctor")->user()->id])->get();
    //          return response()->json(['message'=>'Appointment Rescheduled Successfuly','data'=>$data]);
    // }

    public function deleteSchedule(Request $request)
    {
        $doctor_id = auth("doctor")->user()->id;
        $check = DB::table("doctor_schedule")->where(["id" => $request->id, "doctor_id" => $doctor_id])->exists();
        if (!$check) {
            return response()->json(["message" => "Not Found!"], 404);
        }
        DB::table("doctor_schedule")->where(["id" => $request->id, "doctor_id" => $doctor_id])->delete();
        return response()->json(["message" => "Deleted SuccessFully!"]);
    }

    public function prescription(Request $request)
    {
        $appointment_id = $request->input('appointment_id');
        if (!DoctorAppointment::where(["id" => $appointment_id])->exists()) {
            return response()->json(["message" => "Appointment Not Found!"], 404);
        }
        $data = DoctorAppointment::where(["id" => $appointment_id])->first();
        $age = $request->age;
        $sex = $request->sex;
        $date_consultation = $request->date_consultation;
        $diagnosis = $request->diagnosis;
        $report = $request->report;
        DB::table("prescription")->insert([
            "Age" => $age,
            "Sex" => $sex,
            "date_consultation" => $date_consultation,
            "appointment_id" => $appointment_id,
            "report" => $report,
            "diagnosis" => $diagnosis,
            "patient_id" => $data->patient_id,
        ]);

        return response()->json(["message" => "Created SuccessFully!"]);
    }

    public function getAppointmentID(Request $request)
    {
        $id = $request->appointment_id;
        $data = DB::table("doctors_appointment")
            ->where(["doctors_appointment.id" => $id, "doctor_schedule.doctor_id" => auth("doctor")->user()->id])
            ->join("patient", "patient.id", "doctors_appointment.patient_id")
            ->join("doctor_schedule", "doctor_schedule.id", "=", "doctors_appointment.schedule_id")
            ->select("doctor_schedule.*", "patient.first_name", "patient.last_name", "patient.other_name", "patient.image", "doctors_appointment.status", "doctors_appointment.r_date", "doctors_appointment.r_time", "doctors_appointment.r_day")
            ->get();

        $pres = DB::table("prescription")->where(["appointment_id" => $id])->get();
        return response()->json(["data" => $data, "prescription" => $pres]);
    }

    public function step1verification(Request $request)
    {
        $userid = auth("doctor")->user()->id;
        $check = DB::table("d_step1")->where(["doctor_id" => $userid])->exists();
        if ($check) {
            return response()->json(["message" => "Already Registered!"], 400);
        } else {

            $passport_name = time() . $request->passport->getClientOriginalName();
            $request->passport->move(public_path('doctor'), $passport_name);

            DB::table("d_step1")->insert([
                "gender" => $request->gender,
                "speciality" => $request->speciality,
                "doctor_id" => $userid,
                "language" => $request->language,
                "mcdn" => $request->mcdn,
                "speciality_code" => $request->speciality_code,
                "passport" => "/doctor/$passport_name",
                "otherlanguage" => '-', //$request->otherlanguage
            ]);
            return response()->json(["message" => "Success!", "data" => $request->all()]);
        }
    }

    public function step2verification(Request $request)
    {
        $userid = auth("doctor")->user()->id;
        $check = DB::table("d_step2")->where(["doctor_id" => $userid])->exists();
        if ($check) {
            return response()->json(["message" => "Already Registered!"], 400);
        } else {

            $id_card = time() . $request->id_card->getClientOriginalName();
            $request->id_card->move(public_path('doctor'), $id_card);

            DB::table("d_step2")->insert([
                "country" => $request->country,
                "state" => $request->state,
                "doctor_id" => $userid,
                "refer" => $request->refer,
                "id_card" => "/doctor/$id_card",
            ]);
            return response()->json(["message" => "Success!", "data" => $request->all()]);
        }
    }

    public function step3verification(Request $request)
    {
        $userid = auth("doctor")->user()->id;
        $check = DB::table("d_step3")->where(["doctor_id" => $userid])->exists();
        if ($check) {
            return response()->json(["message" => "Already Registered!"], 400);
        } else {

            $deg_cert = time() . $request->deg_cert->getClientOriginalName();
            $request->deg_cert->move(public_path('doctor'), $deg_cert);

            $med_license = time() . $request->med_license->getClientOriginalName();
            $request->med_license->move(public_path('doctor'), $med_license);

            $backing_info = time() . $request->backing_info->getClientOriginalName();
            $request->backing_info->move(public_path('doctor'), $backing_info);

            DB::table("d_step3")->insert([
                "doctor_id" => $userid,
                "deg_cert" => "/doctor/$deg_cert",
                "med_license" => "/doctor/$med_license",
                "backing_info" => "/doctor/$backing_info",
                "about" => $request->about,
            ]);
            return response()->json(["message" => "Success!", "data" => $request->all()]);
        }
    }

    public function step4verification(Request $request)
    {
        $userid = auth("doctor")->user()->id;

        DB::table("d_step4")->insert([
            "company" => $request->company,
            "from" => $request->from,
            "doctor_id" => $userid,
            "to" => $request->to,
            "current" => $request->current,

        ]);
        return response()->json(["message" => "Success!", "data" => $request->all()]);

    }

    public function doctorsearch(Request $request)
    {
        $text = $request->search;
        $data = DB::table("doctors")->where(function ($query) use ($text) {
            $query->orWhere('first_name', "like", "%" . $text . "%")
                ->orWhere('last_name', "like", "%" . $text . "%")
                ->orWhere('other_name', "like", "%" . $text . "%")
                ->orWhere('email', "like", "%" . $text . "%")
                ->orWhere('phone_number', "like", "%" . $text . "%")
                ->orWhere('doctor_type', "like", "%" . $text . "%")
            ;
        })->get();

        return response()->json(["data" => $data]);
    }

    public function resetpass(Request $request)
    {
        try {
            $email = $request->email;
            $check = DB::table("doctors")->where(["email" => $email])->first();
            if (!$check) {
                return response()->json(["message" => "Email Not Found!"], 404);
            }
            $token = rand(1111, 9999);

            // Your Account SID and Auth Token from twilio.com/console
            $account_sid = 'ACa07d9dfe8d7018ff2d519f75dcb7df84';
            $auth_token = '98ad77cf03cbffdcd030173e84c8beb9';
// In production, these should be environment variables. E.g.:
// $auth_token = $_ENV["TWILIO_AUTH_TOKEN"]

// A Twilio number you own with SMS capabilities
            $twilio_number = "+14043345663";

            $client = new Client($account_sid, $auth_token);
            $client->messages->create(
                // Where to send a text message (your cell phone?)
                "$check->phone_number",
                array(
                    'from' => $twilio_number,
                    'body' => "OTP verification code from sonocare: $token",
                )
            );

            DB::table("doctors")->where(["email" => $email])->update(["resettoken" => $token]);

            \Mail::send('reset', ["user" => $check, "resettoken" => $token], function ($message) use ($check, $request) {

                $message->to($check->email)->subject("Reset Password | SonoCare");
            });

            return response()->json(["message" => "Reset password OTP sent!"]);

        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
        }
    }

    public function setpass(Request $request)
    {
        try {
            $otp = $request->otp;
            $email = $request->email;
            $password = $request->password;
            $data = DB::table("doctors")->where(["email" => $email, "resettoken" => $otp])->first();
            if (!$data) {
                return response()->json(["message" => "Invalid OTP provided"], 404);
            }
            DB::table("doctors")->where(["email" => $email])->update(["password" => \Hash::make($password)]);
            return response()->json(["message" => "Passowrd Reset Was SuccessFul"]);
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
        }

    }

    public function doctorupdateimage(Request $request)
    {
        try{
        $image = $request->image;

        $image_name = time() . $request->image->getClientOriginalName();
        $request->image->move(public_path('uploads'), $image_name);
        DB::table("doctors")->where(["id" => auth("doctor")->user()->id])->update(["image" => "/uploads/$image_name"]);
        return response()->json(["message" => "Updated SuccessFully!", "image" => "/uploads/$image_name"]);
    }catch (\Exception $e){
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, ".$e->getMessage()], 500);
        }
    }

    public function transaction()
    {
        try{
        $data = DB::table("d_transactions")->where(["doctor_id" => auth("doctor")->user()->id])->get();
        return response()->json(["data" => $data, 'balance' => auth("doctor")->user()->wallet, 'account_type' => auth("doctor")->user()->doctor_type], 200);
    }catch (\Exception $e){
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, ".$e->getMessage()], 500);
        }
    }

    public function doctor_type()
    {
        try{
        $data = DB::table("doctor_type")->get();
        return response()->json(["data" => $data]);
    }catch (\Exception $e){
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, ".$e->getMessage()], 500);
        }
    }

    public function update_fcm(Request $request)
    {
        $token = $request->token;
        DB::table("nurses")->where(["id" => auth("doctor")->user()->id])->update(["fcm_token" => $token]);
        return response()->json(["message" => "Updated!", "token" => $token]);
    }

    public function docreviews()
    {
        $data = DB::table("doctor_review")
            ->join("patient", "patient.id", "=", "doctor_review.userid")
            ->where(["doctor_review.doctor_id" => auth("doctor")->user()->id])
        //   ->select("doctor_review.*","patient.first_name as patient_first_name",
        //   "patient.last_name as patient_last_name")
            ->get();
        return response()->json(["data" => $data]);
    }

    public function update_account(Request $request)
    {
        $data = [
            "account_number" => $request->account_number,
            "account_name" => $request->account_name,
            "account_bank" => $request->account_bank,
            "bank_code" => $request->bank_code,
        ];

        $update = DB::table("doctors")->where(["id" => auth("doctor")->user()->id])->update($data);
        if ($update) {
            return response()->json(["message" => "Success!"]);
        } else {
            return response()->json(["message" => "Record Already Updated!"]);
        }
    }

    public function withdrawal(Request $request)
    {
        $amount = $request->amount;
        if ($amount > auth("doctor")->user()->wallet) {
            return response()->json(["message" => "Insufficent Balance!"], 400);
        }

        if (auth("doctor")->user()->account_name == null) {
            return response()->json(["message" => "Account Number Required, please update account!"], 400);
        }

        if ($amount < 1000) {
            return response()->json(["message" => "You can not widthdraw amount less than 1000"], 400);
        } else {
            DB::table("d_transactions")->insert(["amount" => $amount, "type" => "Withdrawal", "doctor_id" => auth("doctor")->user()->id]);
            DB::table("doctors")->where(["id" => auth("doctor")->user()->id])->decrement("wallet", $amount);
            $data = DB::table("d_transactions")->where(["doctor_id" => auth("doctor")->user()->id, "type" => "Withdrawal"])->get();
            return response()->json(["message" => "Widthrawal Successful Submited, the amount will be settled in to your Account shortly"], 200);
        }

    }

    public function answer(Request $request)
    {
        $answer = $request->answer;
        $check = DB::table("doc_answers")->where(["userid" => auth("doctor")->user()->id, "qid" => $request->qid])->first();
        $check2 = DB::table("questions")->where(["id" => $request->qid])->exists();
        if (!$check2) {
            return response()->json(["message" => "Invalid Question ID"], 404);
        }
        if ($check) {
            DB::table("doc_answers")->where(["id" => $check->id])->update(["answer" => $answer]);
        } else {
            DB::table("doc_answers")->insert(["userid" => auth("doctor")->user()->id, "qid" => $request->qid, "answer" => $answer]);
        }
        return response()->json(["message" => "Updated!"]);
    }
    public function answers()
    {
        $data = DB::table("doc_answers")->where(["userid" => auth("doctor")->user()->id])->join("questions", "questions.id", "=", "doc_answers.qid")->select("doc_answers.answer", "questions.title")->get();
        return response()->json(["data" => $data]);
    }

    public function get_agora_token(Request $request)
    {
        $uid = $request->uid;
        $channel = $request->channel;

        //$tokenGenerator = new VideoTokenBuilder();
        $token = get_Token("$uid", "$channel");

        $data = ['token' => $token, "uid" => $uid, "channel" => $channel];
        return response()->json(["data" => $data]);
    }

    public function get_agora_tokennn(Request $request)
    {
        $user_id = $request->user_id;
        $caller_id = $request->caller_id;
        $channel = $request->channel;

        //$tokenGenerator = new VideoTokenBuilder();
        $user_token = get_Token("$user_id", "$channel");
        $caller_token = get_Token("$caller_id", "$channel");

        $data = [
            'user_token' => $user_token,
            'caller_token' => $caller_token,
            "user_id" => $user_id,
            "caller_id" => $caller_id,
            "channel" => $channel,
        ];
        return response()->json(["data" => $data]);
    }

    public function get_doctors_list(Request $request)
    {
        $doctors = DB::table("doctors")->where(["status" => "1"])->get();
        $data = ['doctors' => $doctors];
        return response()->json(["data" => $data]);
    }

}
