<?php

namespace App\Http\Controllers;

use Auth;
use DB;
use Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Twilio\Rest\Client;

class LabController extends Controller
{
    public function register(Request $request)
    {
        $name = $request->name;
        $email = $request->email;
        $token = rand(1111, 9999);
        $phone = $request->phone;
        $password = Hash::make($request->password);

        if (!DB::table("preferences")->where(["id" => $request->service_id])->exists()) {
            return response()->json(["message" => "Invalid Prefences #ID"], 404);
        }
        $check = DB::table("laboratories")->where(["email" => $email])->exists();
        if ($check) {
            return response()->json(["message" => "Mail Already Exists!"], 409);
        }

        $check = DB::table("laboratories")->where(["phone" => $phone])->exists();
        if ($check) {
            return response()->json(["message" => "Phone Number Already Exists!"], 409);
        }
        DB::table("laboratories")->insert([
            "name" => $name,
            "email" => $email,
            "token" => $token,
            "password" => $password,
            "service_preferences" => $request->service_id,
            "phone" => $phone,
        ]);

        $user = DB::table("laboratories")->where(["email" => $email])->first();
        /*
        $twilio_number = "+14043345663";
        $account_sid = 'ACa07d9dfe8d7018ff2d519f75dcb7df84';
        $auth_token = '98ad77cf03cbffdcd030173e84c8beb9';
        $client = new Client($account_sid, $auth_token);
        $client->messages->create(
        // Where to send a text message (your cell phone?)
        "$request->phone",
        array(
        'from' => $twilio_number,
        'body' => "OTP verification code from sonocare: $token"
        )
        );
         */

/*
working code, comment twilio is out of token
$twilio_number = "sonocare";
$account_sid = 'ACa07d9dfe8d7018ff2d519f75dcb7df84';
$auth_token = '98ad77cf03cbffdcd030173e84c8beb9';
$client = new Client($account_sid, $auth_token);
$client->messages->create(
// Where to send a text message (your cell phone?)
"+234$request->phone",
array(
'from' => $twilio_number,
'body' => "OTP verification code from sonocare: $token"
)
);
 */

        \Mail::send('mail3', ["user" => $user], function ($message) use ($user, $request) {

            $message->to($user->email)->subject("Email Verification | SonoCare");
        });
        $user = DB::table("laboratories")->where(["email" => $email])->select("email", "phone", "name")->first();
        return response()->json(["message" => "Registration SuccessFul!", "user" => $user]);

    }

    public function resend_otp(Request $request)
    {
        $email = $request->email;
        $user = DB::table("laboratories")->where(["email" => $email])->first();
        if (!$user) {
            return response()->json(["message" => "Invalid User Email!"], 404);
        }

        $token = $user->token;
        $twilio_number = "sonocare";
        $account_sid = 'ACa07d9dfe8d7018ff2d519f75dcb7df84';
        $auth_token = '98ad77cf03cbffdcd030173e84c8beb9';
        $client = new Client($account_sid, $auth_token);
        $client->messages->create(
            // Where to send a text message (your cell phone?)
            "$user->phone",
            array(
                'from' => $twilio_number,
                'body' => "OTP verification code from sonocare: $token",
            )
        );

        \Mail::send('mail3', ["user" => $user], function ($message) use ($user, $request) {

            $message->to($user->email)->subject("Email Verification | SonoCare");
        });

        return response()->json(["message" => "OTP resent successfully!"]);
    }

    public function verification(Request $request)
    {
        $email = $request->email;
        $token = $request->token;
        $check = DB::table("laboratories")->where(["email" => $email, "token" => $token])->exists();
        if ($check) {
            DB::table("laboratories")->where(["email" => $email, "token" => $token])->update(["active" => 1]);
            return response()->json(["message" => "Registration Success!"]);
        } else {
            return response()->json(["message" => "Invalid OTP provided!"], 400);
        }
    }

    public function login(Request $request)
    {
        try {
            $credentials = request(['email', 'password']);

            if ($token = auth("lab")->attempt($credentials)) {
                $email = auth("lab")->user()->email;
                if (auth("lab")->user()->active != 1) {
                    $user = DB::table("laboratories")->where(["email" => $email])->first();
                    $twilio_number = "sonocare";
                    $account_sid = 'ACa07d9dfe8d7018ff2d519f75dcb7df84';
                    $auth_token = '98ad77cf03cbffdcd030173e84c8beb9';
                    $client = new Client($account_sid, $auth_token);
                    $client->messages->create(
                        // Where to send a text message (your cell phone?)
                        "+234$user->phone",
                        array(
                            'from' => $twilio_number,
                            'body' => "OTP verification code from sonocare: $user->token",
                        )
                    );

                    \Mail::send('mail3', ["user" => $user], function ($message) use ($user, $request) {

                        $message->to($user->email)->subject("Email Verification | SonoCare");
                    });
                    $user = DB::table("laboratories")->where(["email" => $email])->select("email", "phone", "name")->first();
                    return response()->json(["message" => "Account Not Verified", "user" => $user], 401);
                }
                if (auth("lab")->user()->status == 680) {
                    return response()->json(["message" => "Account Pending For Verification", "token" => $token], 400);
                }
                return $this->respondWithToken($token);
            } else {
                return response()->json(["message" => "Invalid Login Details!"], 401);
            }

        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
        }
    }

    protected function respondWithToken($token)
    {
        try {
            return response()->json([
                'access_token' => $token,
                'token_type' => 'bearer',
                'expires_in' => auth("lab")->factory()->getTTL() * 60,
                'user' => auth("lab")->user(),
            ]);
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
        }
    }

    public function step1(Request $request)
    {
        try {
            if (DB::table("lab_step1")->where(["labid" => auth("lab")->user()->id])->exists()) {
                return response()->json(["message" => "Already Registered"], 400);
            }
            DB::table("lab_step1")->insert([
                "name" => $request->lab_name,
                "speciality" => $request->speciality,
                "lab_code" => $request->lab_code,
                "reg_num" => $request->reg_num,
                "labid" => auth("lab")->user()->id,

            ]);

            return response()->json(["message" => "SuccessFully Saved!"]);
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
        }
    }

    public function step2(Request $request)
    {
        try {
            $userid = auth("lab")->user()->id;
            $check = DB::table("lab_step2")->where(["labid" => $userid])->exists();
            if ($check) {
                return response()->json(["message" => "Already Registered!"], 400);
            } else {

                $id_card = time() . $request->id_card->getClientOriginalName();
                $request->id_card->move(public_path('uploads'), $id_card);

                DB::table("lab_step2")->insert([
                    "country" => $request->country,
                    "state" => $request->state,
                    "labid" => $userid,
                    "refer" => $request->refer,
                    "account_number" => $request->account_number,
                    "account_name" => $request->account_name,
                    "account_bank_code" => $request->bank_code,
                    "account_bank" => $request->bank_name,
                    "identity_card" => "/uploads/$id_card",
                ]);
                return response()->json(["message" => "Success!"]);
            }
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
        }
    }
    public function step3(Request $request)
    {
        $userid = auth("lab")->user()->id;
        $check = DB::table("lab_step3")->where(["labid" => $userid])->exists();
        if ($check) {
            return response()->json(["message" => "Already Registered!"], 400);
        } else {

            $labcert = time() . $request->labcert->getClientOriginalName();
            $request->labcert->move(public_path('uploads'), $labcert);

            $lablicense = time() . $request->lablicense->getClientOriginalName();
            $request->lablicense->move(public_path('uploads'), $lablicense);

            $backing = time() . $request->backing_info->getClientOriginalName();
            $request->backing_info->move(public_path('uploads'), $backing);

            DB::table("lab_step3")->insert([
                "lab_license" => "/uploads/$lablicense",
                "backing_info" => "/uploads/$backing",
                "lab_cert" => "/uploads/$labcert",
                "about" => $request->about,
                "labid" => $userid,
            ]);
            return response()->json(["message" => "Success!"]);
        }
    }

    public function step4(Request $request)
    {
        DB::table("laboratories")->where(["id" => auth("lab")->user()->id])->update(["cac_number" => $request->cac_number, "company" => $request->company]);
        return response()->json(["message" => "Updated SuccessFully"]);
    }

    public function labcategory(Request $request)
    {
        $data = DB::table("lab_category")->get();
        return response()->json(["data" => $data]);
    }

    public function labsub_cat(Request $request)
    {
        $data = DB::table("lab_subcat")->where(["category_id" => $request->category_id])->get();
        return response()->json(["data" => $data]);
    }

    public function labsub_cat_lab(Request $request)
    {
        $data = DB::table("lab_subcat")->where(["category_id" => $request->category_id])->get();
        $data2 = DB::table("lab_fees")->where(["labid" => auth("lab")->user()->id])->get();
        //lab_fees
        return response()->json(["lab_subcat" => $data, "lab_fees" => $data2]);
    }

    public function setlabfee(Request $request)
    {
        $fee = $request->fee;
        $labid = auth("lab")->user()->id; //$request->labid;
        $subcat = $request->subcat;

        $check = DB::table("lab_fees")->where(["subcat" => $subcat, "labid" => auth("lab")->user()->id])->exists();

        if ($check) {

            $update = DB::table("lab_fees")
                ->where(["labid" => $labid, "subcat" => $subcat])

                ->update(["fee" => $fee]);

            if ($update) {
                return response()->json(["message" => "Updated SuccessFully!"], 200);
            }

            return response()->json(["message" => "Updated Succesfully"], 200);
        } else {
            DB::table("lab_fees")->insert(["subcat" => $subcat, "labid" => auth("lab")->user()->id, "fee" => $fee, "name" => $request->name]);
            return response()->json(["message" => "Added SuccessFully!"]);
        }
    }

    public function search(Request $request)
    {
        $text = $request->search;
        $data = DB::table("laboratories")->where(function ($query) use ($text) {
            $query->orWhere('name', "like", "%" . $text . "%")
                ->orWhere('phone', "like", "%" . $text . "%")
                ->orWhere('email', "like", "%" . $text . "%")

            ;
        })->select("name", "id")->get();

        return response()->json(["data" => $data]);
    }

    public function labfee(Request $request)
    {
        try {
            $id = $request->subcatid;
            $data = DB::table("lab_fees")->where(["subcat" => $id])
                ->join("lab_subcat", "lab_subcat.id", "=", "lab_fees.subcat")
                ->join("laboratories", "laboratories.id", "=", "lab_fees.labid")
                ->select("lab_subcat.name", "lab_fees.*", "laboratories.name as labname", "laboratories.image as labimage", "laboratories.address", "laboratories.longitude", "laboratories.latitude")->get();
            return response()->json(["data" => $data]);
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
        }
    }

    public function booklab(Request $request)
    {
        try {
            $id = $request->fee_id;
            $check = DB::table("lab_fees")->where(["id" => $id])->first();

            $check2 = DB::table("lab_services")
                ->where(["fee_id" => $id, "patient_id" => auth("api")->user()->id, "status" => 0])
                ->exists();
            if ($check2) {
                return response()->json(["message" => "Booking Already Exists / And In Progress"], 409);
            }
            if ($check == null) {
                return response()->json(["message" => "Invalid Fee ID"], 404);
            } else {
                if ($check->fee > auth("api")->user()->wallet) {
                    return response()->json(["message" => "Amount Greater Than Wallet!"], 400);
                }
                DB::table("lab_services")->insert([
                    "fee_id" => $id,
                    "amount" => $check->fee,
                    "patient_id" => auth("api")->user()->id,
                ]);

                DB::table("patient")->where(["id" => auth("api")->user()->id])->decrement("wallet", $check->fee);
                $iid = rand();
                DB::table("patient_transaction")->insert([
                    "trans_id" => $iid,
                    "amount" => $check->fee,
                    "userid" => auth("api")->user()->id,
                    "type" => "lab request",
                ]);

                $p = DB::table("settings")->where(["type" => "lab_percentage"])->first();
                $percentInDecimal = $p->text / 100;

                $percent = $percentInDecimal * $check->fee;
                DB::table("lab_transactions")->insert(["labid" => $check->labid, "amount" => $percent, "type" => "lab request", "tnx_id" => $iid]);
                DB::table("laboratories")->where(["id" => $check->labid])->increment("wallet", $percent);
                return response()->json(["message" => "SuccessFully Booked!", "data" => $request->all()]);

            }
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
        }
    }

    public function mybookings()
    {
        try {
            $data = DB::table("lab_services")->where(["patient_id" => auth("api")->user()->id])->join("lab_fees", "lab_fees.id", "lab_services.fee_id")->join("lab_subcat", "lab_subcat.id", "=", "lab_fees.subcat")->select("lab_services.*", "lab_subcat.name")->get();
            return response()->json(["data" => $data]);
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
        }
    }

    public function mybookings2()
    {
        //$data2 = DB::table("lab_services")->where(["lab_services.lab_id"=>auth("lab")->user()])->join("lab_fees","lab_fees.id","lab_services.fee_id")->get();
        //$data = DB::table("lab_services")->where(["lab_services.lab_id"=>auth("lab")->user()->id])->join("lab_fees","lab_fees.id","lab_services.fee_id")->join("lab_subcat","lab_subcat.id","=","lab_fees.subcat")->select("lab_services.*","lab_subcat.name")->get();

        $data = DB::table("lab_services")->
            where(["lab_services.lab_id" => auth("lab")->user()->id])
            ->join("patient", "patient.id", "lab_services.patient_id")
            ->join("lab_fees", "lab_fees.id", "=", "lab_services.fee_id")
            ->join("lab_subcat", "lab_subcat.id", "lab_fees.subcat")
            ->select("lab_services.id as lab_services_id", "lab_services.lab_report_id", "lab_services.lab_id", "lab_services.patient_id", "lab_services.status",
                "lab_services.updated_at", "lab_services.created_at", DB::raw("CONCAT(patient.first_name,' ',patient.last_name) AS full_name"),
                "patient.dob", "patient.gender", "patient.image", "patient.id as patient_id", "lab_fees.fee", "lab_subcat.name as lab_subcat_name")
        //->join("lab_fees","lab_fees.id","=","lab_services.fee_id")
        //->join("lab_subcat","lab_subcat.id","=","lab_fees.subcat")
        //->select("lab_services.*","lab_subcat.name")
            ->get();
        return response()->json(["data" => $data, "id" => auth("lab")->user()->id]);
    }

    public function transactions()
    {
        $data = DB::table("lab_transactions")->where(["labid" => auth("lab")->user()->id])->get();
        return response()->json(["data" => $data, "balance" => auth("lab")->user()->wallet]);
    }

    public function addreport(Request $request)
    {
        $check = DB::table("lab_services")->where(["id" => $request->booking_id])->exists();
        if (!$check) {
            return response()->json(["message" => "Service/Booking Not Found!"], 404);
        }
        $reportID = DB::table("lab_report")->insertGetId([
            "labid" => auth("lab")->user()->id,
            "age" => $request->age,
            "sex" => $request->sex,
            "date" => $request->date,
            "report" => $request->report,
            "lab_service_id" => $request->booking_id,
            "patient_id" => $request->patient_id,
        ]);

        DB::table("lab_services")->where(["id" => $request->booking_id])->update(["status" => 3, "lab_report_id" => $reportID]);

        return response()->json(["message" => "Added SuccessFully!", "data" => $request->all()]);
    }

    public function completed_report(Request $request)
    {
        $data = DB::table("lab_report")->where(["lab_report.id" => $request->labRequestID])->get();
        if (count($data) > 0) {
            return response()->json(["data" => $data[0], "labRequestID" => $request->labRequestID]);
        }

        return response()->json(["data" => "Not found"], 404);
    }

    public function reports()
    {
        $data = DB::table("lab_report")->where(["lab_report.labid" => auth("lab")->user()->id])->join("lab_services", "lab_services.id", "=", "lab_report.lab_service_id")->join("patient", "patient.id", "=", "lab_services.patient_id")->select("patient.first_name", "patient.last_name", "lab_report.*")->get();
        return response()->json(["data" => $data]);
    }

    public function booking_details(Request $request)
    {
        $id = $request->booking_id;
        $data1 = DB::table("lab_services")->where(["lab_services.id" => $id])->first();
        $data2 = DB::table("lab_report")->where(["lab_service_id" => $data1->id])->get();
        $data3 = DB::table("patient")->where(["id" => $data1->patient_id])->select("first_name", "last_name", "other_name", "phone_number")->first();
        return response()->json(["booking_data" => $data1, "booking_report" => $data2, "patient_details" => $data3]);

    }

    public function accept(Request $request)
    {
        $check = DB::table("lab_services")->where(["id" => $request->service_id])->first();
        if (!$check) {
            return response()->json(["message" => "Service/Booking Not Found!"], 404);
        }
        DB::table("lab_services")->where(["id" => $request->service_id])->update(["status" => "1"]);
        return response()->json(["message" => "Accepted!"]);
    }

    public function decline(Request $request)
    {
        $check = DB::table("lab_services")->where(["id" => $request->service_id])->first();
        if (!$check) {
            return response()->json(["message" => "Service/Booking Not Found!"], 404);
        }
        DB::table("lab_services")->where(["id" => $request->service_id])->update(["status" => "2"]);
        return response()->json(["message" => "Declined!"]);
    }

    public function me()
    {
        return response()->json(["user" => auth("lab")->user()]);
    }

    public function update_profile2(Request $request)
    {
        $name = $request->name;
        $address = $request->address;
        $pre = $request->service_preferences;

        DB::table("laboratories")->where(["id" => auth("lab")->user()->id])->update([

            "name" => $name,
            "address" => $address,
            "service_preferences" => $pre,
        ]);

        return response()->json(["message" => "Updated!"]);
    }

    public function updateprofile(Request $request)
    {
        $check = DB::table("laboratories")->where(["id" => $request->id])->exists();
        if (!$check) {
            return response()->json(["message" => "Profile Not found!"], 404);
        }

        DB::table("laboratories")->where(["id" => $request->id])->update([
            "first_name" => $request->first_name,
            "last_name" => $request->last_name,
            "name" => $request->name,
            "email" => $request->email,
            "phone" => $request->phone,
            "address" => $request->address,
        ]);
        return response()->json(["message" => "Updated SuccessFully!", "data" => $request->except("token")]);
    }

    public function update_account(Request $request)
    {

        $data = [
            "account_number" => $request->account_number,
            "account_name" => $request->account_name,
            "account_bank" => $request->account_bank,
            "bank_code" => $request->bank_code,
        ];

        $update = DB::table('laboratories')
            ->where('id', auth('lab')->user()->id)
            ->update($data);

        if ($update) {
            return response()->json(["message" => "Updated Successfully"]);
        } else {
            return response()->json(["message" => "Account Already Updated "]);
        }

    }

    public function update_address(Request $request)
    {
        $address = $request->address;

        DB::table("laboratories")->where(["id" => auth("lab")->user()->id])->update([

            "latitude" => $request->latitude,
            "address" => $address,
            "longitude" => $request->longitude,
        ]);
        return response()->json(["message" => "Updated!"]);
    }

    // public function labfee(){
    //     $data = DB::table("labfee")->where(["subcat"=>$request->subcatid])->get();
    //     return response()->json(["data"=>$data]);
    // }

    public function lab_reviews()
    {
        $data = DB::table("lab_review")->join("patient", "patient.id", "=", "lab_review.userid")->where(["lab_review.lab_id" => auth("lab")->user()->id])->select("lab_review.*", "patient.first_name as patient_first_name", "patient.last_name as patient_last_name")->get();
        return response()->json(["data" => $data]);
    }
    public function get_preferences()
    {
        $selected_preference = DB::table('lab_preference')->where('lab_id', auth('lab')->user()->id)->get();

        return response()->json(['selected_service_preference' => $selected_preference]);
    }
    public function set_service_preferences(Request $req)
    {
        $data = "empty"; ///DB::table('pharmacy_preference')->get();

        $lab_preference = DB::table('lab_preference')->where('lab_id', auth('lab')->user()->id)->get();

        $req->amount;
        $req->preference_type;
        $req->type;
        if (count($lab_preference) != 0) {
            $data = "not empty";
            /*

            pharmacy_id
            preference_type
            amount
            type
            created_at
             */
            DB::table("lab_preference")->where(["lab_id" => auth("lab")->user()->id])->update([
                "lab_id" => auth("lab")->user()->id,
                "preference_type" => $req->preference_type,
                "amount" => $req->amount,
                "type" => $req->type,
            ]);
        } else {
            DB::table("lab_preference")->insert([
                "lab_id" => auth("lab")->user()->id,
                "preference_type" => $req->preference_type,
                "amount" => $req->amount,
                "type" => $req->type,
            ]);
        }

        return response()->json(['data' => $data, 'pref' => $lab_preference, 'amount' => $req->amount, 'pref_type' => $req->preference_type, 'type' => $req->type]);
    }

    public function transaction_history()
    {
        //important fields, and please the spelling should be thesame as the example below.
        //example: {"id":"1","patient_first_name":"Mohammed","patient_last_name":"Aliyu","rating":"2","comment":"This is a nice app","created_at":"2021-12-23 01:37:25"}

        $account = ["balance" => "200100", "account-type" => "Independent"];
        $transactions = [];
        $transactions[] = ['id' => '1', "status" => "Pending", "type" => "withdrawal", "amount" => "2500", "date" => "2021-12-23 01:37:25"];
        $transactions[] = ['id' => '2', "status" => "Approved", "type" => "withdrawal", "amount" => "5000", "date" => "2021-12-23 01:37:25"];
        $transactions[] = ['id' => '3', "status" => "Approved", "type" => "withdrawal", "amount" => "11000", "date" => "2021-12-23 01:37:25"];
        $transactions[] = ['id' => '4', "status" => "Approved", "type" => "withdrawal", "amount" => "760", "date" => "2021-12-23 01:37:25"];

        $data = DB::table('lab_transactions')
            ->join('laboratories', 'lab.id', 'lab_transactions.labid')
            ->where('lab_transactions.labid', auth('laboratories')->user()->id)
            ->select('lab_transactions.*', 'laboratories.wallet as balance')
            ->get();

        //$data = DB::table('hospital_transactions')->where('pharmacy_id', auth('pharmacy')->user()->id)->get();

        return response()->json(["data" => $data, "balance123" => auth("laboratories")->user()->wallet]);
    }

    public function withdrawal(Request $request)
    {
        $amount = $request->amount;
        if ($amount > auth("lab")->user()->wallet) {
            return response()->json(["message" => "Insufficent Balance!"], 400);
        }

        if (auth("lab")->user()->account_name == null) {
            return response()->json(["message" => "Account Number Required, please update account!"], 400);
        }

        if ($amount < 1000) {
            return response()->json(["message" => "You can not widthdraw amount less than 1000"], 400);
        } else {
            DB::table("lab_transactions")->insert(["amount" => $amount, "type" => "Withdrawal", "labid" => auth("lab")->user()->id]);
            DB::table("laboratories")->where(["id" => auth("lab")->user()->id])->decrement("wallet", $amount);

            return response()->json(["message" => "Widthrawal Successful Submited, the amount will be settled in to your Account shortly"], 200);
        }

    }
}
