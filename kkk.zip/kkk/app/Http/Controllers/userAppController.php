<?php

namespace App\Http\Controllers;

use App\Models\Chksubscriptionplan;
use App\Models\Encounter;
use App\Models\Patient;
use App\Models\Subscription;
use App\Models\SubscriptionDetails;
use App\Models\VitalSign;
use DB;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class userAppController extends Controller
{
    public function getPatientProfile(request $request)
    {
        return response()->json([ "user"=>auth("api")->user()]);
    }

    public function getDistance($addressFrom, $addressTo, $unit = '')
    {
        // Google API key
        $apiKey = 'AIzaSyCjO6PP-HAE_ylkxdRTu7L6dvRhgv4wegU';

        // Change address format
        $formattedAddrFrom = urlencode(str_replace(' ', '%20', $addressFrom));
        $formattedAddrTo = urlencode(str_replace(' ', '%20', $addressTo));

        // Geocoding API request with start address
        $geocodeFrom = file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?address=' . $formattedAddrFrom . '&sensor=false&key=' . $apiKey);
        $outputFrom = json_decode($geocodeFrom);
        if (!empty($outputFrom->error_message)) {
            return $outputFrom->error_message;
        }

        // Geocoding API request with end address
        $geocodeTo = file_get_contents('https://maps.googleapis.com/maps/api/geocode/json?address=' . $formattedAddrTo . '&sensor=false&key=' . $apiKey);
        $outputTo = json_decode($geocodeTo);
        if (!empty($outputTo->error_message)) {
            return $outputTo->error_message;
        }

        // Get latitude and longitude from the geodata
        $latitudeFrom = $outputFrom->results[0]->geometry->location->lat;
        $longitudeFrom = $outputFrom->results[0]->geometry->location->lng;
        $latitudeTo = $outputTo->results[0]->geometry->location->lat;
        $longitudeTo = $outputTo->results[0]->geometry->location->lng;

        // Calculate distance between latitude and longitude
        $theta = $longitudeFrom - $longitudeTo;
        $dist = sin(deg2rad($latitudeFrom)) * sin(deg2rad($latitudeTo)) + cos(deg2rad($latitudeFrom)) * cos(deg2rad($latitudeTo)) * cos(deg2rad($theta));
        $dist = acos($dist);
        $dist = rad2deg($dist);
        $miles = $dist * 60 * 1.1515;

        // Convert unit and return distance
        $unit = strtoupper($unit);
        if ($unit == "K") {
            return [round($miles * 1.609344, 2), $latitudeFrom, $longitudeFrom, $latitudeTo, $longitudeTo];
        } elseif ($unit == "M") {
            return round($miles * 1609.344, 2);
        } else {
            return round($miles, 2) . ' miles';
        }
    }

    public function ratedoctor(Request $request)
    {
        $id = $request->doctor_id;
        $check = DB::table("doctors")->where(["id" => $id])->first();
        if ($check == null) {
            return response()->json(["message" => "Doctor Not Found!"], 404);
        }

        DB::table("doctor_rating")->insert([
            "patient_id" => auth("api")->user()->id,
            "doctor_id" => $id,
            "comment" => $request->comment,
            "rating" => $request->rating,
        ]);

        return response()->json(["message" => "Rating Added!"]);
    }

    public function getdoctorrating(Request $request)
    {
        $id = $request->doctor_id;
        $data = DB::table("doctor_rating")->where(["doctor_id" => $id])->get();
        return response()->json(["totalrating" => count($data), "data" => $data]);
    }

    public function patientsearch(Request $request)
    {
        $text = $request->search;
        $data = DB::table("patient")->where(function ($query) use ($text) {
            $query->orWhere('first_name', "like", "%" . $text . "%")
                ->orWhere('last_name', "like", "%" . $text . "%")
                ->orWhere('other_name', "like", "%" . $text . "%")
                ->orWhere('email', "like", "%" . $text . "%")
                ->orWhere('phone_number', "like", "%" . $text . "%")
                ->orWhere('unique_id', "like", "%" . $text . "%")
            ;
        })->select("first_name", "other_name", "last_name", "phone_number", "image", "id as patient_id")->get();

        return response()->json(["data" => $data]);
    }

    public function updateProfile(request $request)
    {
        $patient_id = auth("api")->user()->id;

        $updateProfile = Patient::find($patient_id);

        $updateProfile->first_name = $request->input('first_name');
        $updateProfile->other_name = $request->input('other_name');
        $updateProfile->last_name = $request->input('last_name');

        $updateProfile->address = $request->input('address');
        $updateProfile->state_id = $request->input('state_id');
        $updateProfile->lga_id = $request->input('lga_id');
        $updateProfile->dob = $request->input('dob');
        $updateProfile->language = $request->input('language');
        $updateProfile->hieght = $request->input('hieght');
        $updateProfile->genotype = $request->input('genotype');
        $updateProfile->blood_group = $request->input('blood_group');
        $updateProfile->gender = $request->input('gender');

        $updateProfile->family_member_contact = $request->input('family_member_contact');

        $updateProfile->save();
        return response()->json(['status' => 'true', 'message' => 'Profile Updated Successfully']);
    }

    public function verifyemail(request $request)
    {

        $email = $request->email;
        $email_verification_code = $request->email_verification_code;
        $Profile = Patient::where(["email" => $email, "email_verification_code" => $email_verification_code])->first();

        if ($Profile) {
            Patient::where(["email" => $email])->update(["status" => 1]);

            $check = DB::table("ref")->where(["userid" => $Profile->id, "verified" => null])->first();
            if ($check) {
                $s = DB::table("settings")->where(["type" => "refer_earn_price"])->first();
                DB::table("ref")->where(["userid" => $Profile->id, "verified" => null])->update(["verified" => 1]);
                DB::table("patient")->where(["id" => $check->refid])->increment("wallet", (int) $s->text);
            }
            return response()->json(['status' => 'true', 'message' => 'Email verified Successfully']);

        } else {
            return response()->json(['status' => 'true', 'message' => 'Invalid Email Verification code']);
        }

    }

    public function getVitalSign(Request $request)
    {
        $id = $request->patient_id;
        $data = VitalSign::where(["patient_id" => $id])->get();
        return response()->json(["data" => $data]);
    }

    public function sendVitalSignRequest(Request $request)
    {
        $s = DB::table("settings")->where(["type" => "vital_sign_amount"])->first();
        $p = DB::table("settings")->where(["type" => "nurse_percentage"])->first();

        $id = auth("api")->user()->id;

        if ($request->payment_method == "card") {
            $curl = curl_init();

            curl_setopt_array($curl, array(
                CURLOPT_URL => "https://api.paystack.co/transaction/verify/$request->ref",
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "GET",
                CURLOPT_HTTPHEADER => array(
                    "Authorization: Bearer sk_test_52531adfdfd74ee21276c6f64b20e257cd6a631e",
                    "Cache-Control: no-cache",
                ),
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);
            curl_close($curl);
            $response = json_decode($response);

            if ($response->status == false) {
                return response()->json(["message" => $response->message], 400);
            } else {
                $count = VitalSign::where('status', '=', '0')->where(["patient_id" => $id])->count();

                if ($count != 0) {
                    $VitalSign = VitalSign::create([
                        'patient_id' => $id,
                        "latitude" => $request->latitude, "longitude" => $request->longitude,

                    ]);
                    $percentInDecimal = $p->text / 100;

                    $percent = $percentInDecimal * $s->text;
                    DB::table("patient")->where(["id" => auth("api")->user()->id])->decrement("wallet", $percent);
                    DB::table("nurse_transactions")->insert(["amount" => $percent, "type" => "vital sign", "vid" => $VitalSign->id]);
                    $data = DB::table("VitalSign")->where(["VitalSign.id" => $VitalSign->id])->join("patient", "patient.id", "=", "VitalSign.patient_id")
                        ->select("VitalSign.*", "patient.first_name", "patient.last_name", "patient.image")->first();

                    if ($VitalSign) {

                        $st = \Http::post('https://sonocare-51b1c-default-rtdb.firebaseio.com/vital.json', (array) $data);
                        $d = $st->object();
                        if ($st->failed()) {
                            return response()->json(["message" => "Something Went Wrong", "error" => $d]);
                        }
                        DB::table("VitalSign")->where(["id" => $VitalSign->id])->update(["ref" => $d->name]);
                        return response()->json(['status' => 'true', 'message' => 'Vital Signs Reading Requested', "datafirebase" => $d]);
                    }

                }

            }
        }
        if ($request->payment_method == "wallet") {
            if (auth("api")->user()->wallet == 0) {
                return response()->json(["message" => "Insufficient Fund!"], 400);
            }

            if ($s->text > auth("api")->user()->wallet) {
                return response()->json(["message" => "Insufficient Fund!"], 400);
            }

            $count = VitalSign::where('status', '=', '0')->where(["patient_id" => $id])->count();

            if ($count != 0) {
                $VitalSign = VitalSign::create([
                    'patient_id' => $id,
                    "latitude" => $request->latitude, "longitude" => $request->longitude,

                ]);
                $percentInDecimal = $p->text / 100;

                $percent = $percentInDecimal * $s->text;
                DB::table("patient")->where(["id" => auth("api")->user()->id])->decrement("wallet", $percent);
                DB::table("nurse_transactions")->insert(["amount" => $percent, "type" => "vital sign", "vid" => $VitalSign->id]);
                $data = DB::table("VitalSign")->where(["VitalSign.id" => $VitalSign->id])->join("patient", "patient.id", "=", "VitalSign.patient_id")
                    ->select("VitalSign.*", "patient.first_name", "patient.last_name", "patient.image")->first();

                if ($VitalSign) {

                    $st = \Http::post('https://sonocare-51b1c-default-rtdb.firebaseio.com/vital.json', (array) $data);
                    $d = $st->object();
                    if ($st->failed()) {
                        return response()->json(["message" => "Something Went Wrong", "error" => $d]);
                    }
                    DB::table("VitalSign")->where(["id" => $VitalSign->id])->update(["ref" => $d->name]);
                    return response()->json(['status' => 'true', 'message' => 'Vital Signs Reading Requested', "datafirebase" => $d]);
                }
            } else {

                return response()->json(['status' => 'true', 'message' => 'You have a pending Request']);
            }
        }

    }
    public function chkPatientWalletBalance(request $request)
    {

        $wallat_balance = auth("api")->user()->wallet;
        return response()->json(['WallatBalance' => $wallat_balance]);
    }

    public function fundwallet(request $request)
    {
        $check = DB::table("patient_transaction")->where(["userid" => auth("api")->user()->id, "trans_id" => $request->ref])->first();

        if (!$check) {
            $curl = curl_init();

            curl_setopt_array($curl, array(
                CURLOPT_URL => "https://api.paystack.co/transaction/verify/$request->ref",
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "GET",
                CURLOPT_HTTPHEADER => array(
                    "Authorization: Bearer sk_test_52531adfdfd74ee21276c6f64b20e257cd6a631e",
                    "Cache-Control: no-cache",
                ),
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);
            curl_close($curl);
            $response = json_decode($response);

            if ($response->status == false) {
                return response()->json(["message" => $response->message], 400);
            } else {
                Patient::where('id', auth("api")->user()->id)->increment("wallet", $request->amount);
                DB::table("patient_transaction")->insert([
                    "trans_id" => $request->ref,
                    "amount" => $request->amount,
                    "userid" => auth("api")->user()->id,
                    "type" => $request->type,
                ]);
            }

        } else {
            return response()->json(["message" => "Transaction Already Exists!"], 400);
        }

        return response()->json(['response' => "Wallet Funded Successfully"]);
    }

    public function createEncounter(request $request)
    {
        try {
            $patient_id = auth("api")->user()->id;
            $checkd = DB::table("doctors")->where(["id" => $request->doctor])->exists();
            if (!$checkd) {
                return response()->json(["message" => "Doctor Not Found!"], 404);
            }
            $count = Encounter::where('status', '=', '0')->where(["patient_id" => $patient_id, 'doctor_id' => $request->doctor])->exists();

            if (!$count) {
                $Encounter = Encounter::create([
                    'patient_id' => $patient_id,
                    'doctor_id' => $request->doctor,
                ]);

                if ($Encounter) {

                    return response()->json(['status' => true, 'message' => 'Encounter Created Successfully', 'Encounter' => $Encounter]);

                }
            } else {

                return response()->json(['status' => false, 'message' => 'You have a pending Encounter'], 400);
            }
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
        }
    }

    public function getAllConsultation(request $request)
    {
			// Check if the user is authenticated
        $user = auth("api")->user();
        if (!$user) {
            return response()->json(["message" => "Unauthorized access. Please log in."], 401);
        }
        try{
			// Check if the user is authenticated
        $user = auth("api")->user();
        if (!$user) {
            return response()->json(["message" => "Unauthorized access. Please log in."], 401);
        }
			
        $patient_id = auth("api")->user()->id;
        $allEncounters2 = Encounter::where('patient_id', $patient_id)->get();
			$allEncounters = DB::table('consultation')
    ->leftJoin('doctors', 'consultation.doctor_id', '=', 'doctors.id')
    ->where('consultation.patient_id', $patient_id)
    ->get([
        'consultation.*',
        //'doctors.id as doctor_id',
        'doctors.first_name as doctor_first_name',
        'doctors.last_name as doctor_last_name',
        'doctors.email as doctor_email',
        'doctors.doctor_type as doctor_type',
        'doctors.about_me as doctor_about',
        'doctors.image as doctor_img',
    ]);

        return response()->json(['allEncounters' => $allEncounters]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public function getConsultationById(request $request)
    {
        try {
            $encountrID = $request->input('encountrID');
            $allEncounters = Encounter::where('consultation_id', $encountrID)->where("patient_id", auth("api")->user()->id)->get();
            return response()->json(['EncountersByID' => $allEncounters]);
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
        }
    }

    public function getAllSubscriptionPlan(request $request)
    {
        try {
            $SubscriptionPlan = Subscription::where('status', '1')->get();

            return response()->json(['SubscriptionPlan' => $SubscriptionPlan]);
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
        }
    }

    public function getSubscriptionPlanDetails(request $request)
    {
        try {
            $subscription_id = $request->input('subscription_id');
            $SubscriptionPlan = SubscriptionDetails::where('status', '1')
                ->where('subscription_id', $subscription_id)
                ->get();

            return response()->json(['SubscriptionPlanDails' => $SubscriptionPlan]);
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
        }
    }

    public function viewWalletHistory(request $request)
    {
        try {
            $patient_id = auth("api")->user()->id;

            $wallat_history = DB::table("patient_transaction")->where('userid', $patient_id)
                ->orderBy('id', 'desc')
                ->get();
            return response()->json(['Wallat_history' => $wallat_history]);
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
        }
    }

    public function chkSubscriptionPlan(request $request)
    {
        try {
            $patient_id = auth("api")->user()->id;

            $Chksubscriptionplan = Chksubscriptionplan::where('patient_id', $patient_id)
            // ->where('status','1')
                ->get();
            return response()->json(['SubscriptionPlan' => $Chksubscriptionplan]);
        } catch (\Exception $e) {
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
        }

    }

    public function subcribe_medical(Request $request)
    {
        $check = DB::table("subscription")->where(["id" => $request->id])->first();
        if (DB::table("patient_subscription")->where(["status" => "1", "patient_id" => auth("api")->user()->id])->exists()) {
            return response()->json(["message" => "You already a subscription plan!"], 400);
        }

        if ($check) {

            if ($request->payment_method == "wallet") {
                if ($check->price > auth("api")->user()->wallet) {
                    return response()->json(["message" => "insufficient fund!"], 400);
                }
                $iid = rand();
                DB::table("patient_subscription")->insert([

                    "patient_id" => auth("api")->user()->id,
                    "subscription_id" => $request->id,
                    "status" => "1",
                    "trans_id" => $iid,

                ]);

                DB::table("patient")->where(["id" => auth("api")->user()->id])->decrement("wallet", $check->price);
                DB::table("patient_transaction")->insert([
                    "userid" => auth("api")->user()->id,
                    "type" => "subscription/wallet",
                    "amount" => $check->price,
                    "trans_id" => $iid,

                ]);

            }

            if ($request->payment_method == "card") {
                $curl = curl_init();

                curl_setopt_array($curl, array(
                    CURLOPT_URL => "https://api.paystack.co/transaction/verify/$request->ref",
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => "",
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 30,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => "GET",
                    CURLOPT_HTTPHEADER => array(
                        "Authorization: Bearer sk_test_52531adfdfd74ee21276c6f64b20e257cd6a631e",
                        "Cache-Control: no-cache",
                    ),
                ));

                $response = curl_exec($curl);
                $err = curl_error($curl);
                curl_close($curl);
                $response = json_decode($response);

                if ($response->status == false) {
                    return response()->json(["message" => $response->message], 400);
                } else {

                    DB::table("patient_subscription")->insert([

                        "patient_id" => auth("api")->user()->id,
                        "subscription_id" => $request->id,
                        "status" => "1",
                        "trans_id" => $request->ref,

                    ]);

                    DB::table("patient_transaction")->insert([
                        "userid" => auth("api")->user()->id,
                        "type" => "subscription/card",
                        "amount" => $check->price,
                        "trans_id" => $request->ref,

                    ]);
                }
            }
        } else {
            return response()->json(["message" => "Plan Not Found!"], 404);
        }
        return response()->json(["message" => "Subcribe SuccessFully!"]);
    }

    public function getConsultationFee(Request $request)
    {
        $doctor_id = $request->doctor_id;
        $data = DB::table("doctors_services")->where([

            "doctor_id" => $doctor_id,
        ])->get();
        return response()->json(["data" => $data]);
    }

    public function bookAppointmentWithDoctor(request $request)
    {
        try {
            $patient_id = auth("api")->user()->id;

            $check = DB::table("doctor_schedule")->where(["id" => $request->schedule_id])->first();
            if (!$check) {
                return response()->json(["message" => "Schedule Not Found!"], 404);
            }

            $check2 = DB::table("doctors_services")->where(["id" => $request->service_id])->first();
            if (!$check2) {
                return response()->json(["message" => "Service Not Found!"], 404);
            }

            $doctor = DB::table("doctors")->where(["id" => $check->doctor_id])->first();

            if (DB::table("doctors_appointment")->where([
                "schedule_id" => $request->schedule_id,
                "patient_id" => $patient_id,
            ])->exists() || DB::table("doctors_appointment")->where([
                "schedule_id" => $request->schedule_id,
            ])->exists()) {
                return response()->json(["message" => "Already Booked!"], 409);
            }

            if ($request->type == "wallet") {
                $iid = rand();
                $apid = DB::table("doctors_appointment")->insertGetId([
                    "schedule_id" => $request->schedule_id,
                    "patient_id" => $patient_id,
                    "service_id" => $request->service_id,
                    "trans_id" => $iid,
                    "type" => $request->booktype,

                ]);
                DB::table("patient_transaction")->insert([
                    "trans_id" => $iid,
                    "amount" => $check2->price,
                    "userid" => auth("api")->user()->id,
                    "type" => "appointment/wallet",
                ]);
                DB::table("patient")->where(["id" => auth("api")->user()->id])->decrement("wallet", $check2->price);
                DB::table("patient")->where(["id" => auth("api")->user()->id])->update(["subscription" => $apid]);
            }

            if ($request->type == "gateway") {
                $curl = curl_init();

                curl_setopt_array($curl, array(
                    CURLOPT_URL => "https://api.paystack.co/transaction/verify/$request->ref",
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => "",
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 30,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => "GET",
                    CURLOPT_HTTPHEADER => array(
                        "Authorization: Bearer sk_test_52531adfdfd74ee21276c6f64b20e257cd6a631e",
                        "Cache-Control: no-cache",
                    ),
                ));

                $response = curl_exec($curl);
                $err = curl_error($curl);
                curl_close($curl);
                $response = json_decode($response);

                if ($response->status == false) {
                    return response()->json(["message" => $response->message], 400);
                } else {

                    DB::table("patient_transaction")->insert([
                        "trans_id" => $request->ref,
                        "amount" => $check2->price,
                        "userid" => auth("api")->user()->id,
                        "type" => "appointment/gateway",
                    ]);

                    $apid = DB::table("doctors_appointment")->insertGetId([
                        "schedule_id" => $request->schedule_id,
                        "patient_id" => $patient_id,
                        "service_id" => $request->service_id,
                        "trans_id" => $request->ref,
                        "type" => $request->booktype,
                    ]);
                    DB::table("patient")->where(["id" => auth("api")->user()->id])->update(["subscription" => $apid]);
                    DB::table("patient")->where(["id" => auth("api")->user()->id])->decrement("wallet", $check2->price);
                }
            }

            return response()->json(["message" => "SuccessFully Booked!", "id" => $apid]);
        } catch (\Exception $e) {
            \Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
        }
    }

    public function GetAllAppointment(request $request)
    {
        $patient_id = auth("api")->user()->id;
        $Chk = DB::table("doctors_appointment")
            ->where(["patient_id" => $patient_id])
            ->join("doctor_schedule", "doctor_schedule.id", "=", "doctors_appointment.schedule_id")
            ->join("dates", "dates.id", "=", "doctor_schedule.date")
            ->join("doctors", "doctors.id", "=", "doctor_schedule.doctor_id")
            ->select("doctor_schedule.*", "doctors_appointment.status", "dates.text", "dates.shorttext", "doctors.first_name", "doctors.last_name", "doctors.image")->get();

        if (isset($_GET['status'])) {

            $Chk = DB::table("doctors_appointment")
                ->where(["patient_id" => $patient_id, "status" => $_GET['status']])
                ->join("doctor_schedule", "doctor_schedule.id", "=", "doctors_appointment.schedule_id")
                ->join("dates", "dates.id", "=", "doctor_schedule.date")
                ->join("doctors", "doctors.id", "=", "doctor_schedule.doctor_id")
                ->select("doctor_schedule.*", "doctors_appointment.status", "dates.text", "dates.shorttext", "doctors.first_name", "doctors.last_name", "doctors.image")->get();

        }
		
		$Chk = DB::table("doctors_appointment")
            ->where(["patient_id" => $patient_id])
	        ->join("doctor_schedule", "doctor_schedule.id", "=", "doctors_appointment.schedule_id")
            ->join("doctors", "doctors.id", "=", "doctor_schedule.doctor_id")
			->select("doctor_schedule.*", "doctors_appointment.status", "doctors.first_name", "doctors.last_name", "doctors.image", "doctors.doctor_type", "doctors.about_me")
			->get();

        return response()->json(['message' => 'ok', 'data' => $Chk, "000"=>"09090"]);
    }
	
	

    public function getDoctorSchedule(Request $request)
    {
        $doctor_id = $request->doctor_id;
        $check = DB::table("doctors")->where(["id" => $doctor_id])->exists();
        if (!$check) {
            return response()->json(["message" => "Doctor Not Found!"], 404);
        }
		$kl = DB::table("doctor_schedule")->where(["doctor_schedule.doctor_id" => $doctor_id])->get();
        return response()->json(["data" => $kl]);
    }

    public function getdoctorap(Request $request)
    {
        $check = DB::table("dates")->where(["id" => $request->dates_id])->exists();
        if (!$check) {
            return response()->json(["message" => "dates_id not found!"], 400);
        }
        $doctor_id = $request->doctor_id;
        $check = DB::table("doctors")->where(["id" => $doctor_id])->exists();
        if (!$check) {
            return response()->json(["message" => "Doctor Not Found!"], 404);
        }
        $data = [];
        $d = DB::table("doctor_schedule")->where(["doctor_schedule.doctor_id" => $doctor_id, "date" => $request->dates_id])->get();
        foreach ($d as $dd) {
            $d2 = DB::table("doctors_appointment")->where(["schedule_id" => $dd->id])->first();
            // if($d2 == null){

            array_push($data, $dd);

            // }
        }
        return response()->json(["data" => $data]);
    }

    public function patientupdateimage(Request $request)
    {
        $image = $request->image;

        $image_name = time() . $request->image->getClientOriginalName();
        $request->image->move(public_path('uploads'), $image_name);
        DB::table("patient")->where(["id" => auth("api")->user()->id])->update(["image" => "/uploads/$image_name"]);
        $url = url("/");
        return response()->json(["message" => "Updated SuccessFully!", "image" => "$url/uploads/$image_name"]);

    }

    public function refers()
    {
        try{
        $data = DB::table("ref")->where(["refid" => auth("api")->user()->id])->join("patient", "patient.id", "=", "ref.userid")->select("ref.*", "patient.first_name", "patient.last_name")->get();
        return response()->json(["data" => $data]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public function questions()
    {
        $data = DB::table("questions")->get();
        return response()->json(["data" => $data]);
    }

    public function answer(Request $request)
    {
        $answer = $request->answer;
        $check = DB::table("answers")->where(["userid" => auth("api")->user()->id, "qid" => $request->qid])->first();
        $check2 = DB::table("questions")->where(["id" => $request->qid])->exists();
        if (!$check2) {
            return response()->json(["message" => "Invalid Question ID"], 404);
        }
        if ($check) {
            DB::table("answers")->where(["id" => $check->id])->update(["answer" => $answer]);
        } else {
            DB::table("answers")->insert(["userid" => auth("api")->user()->id, "qid" => $request->qid, "answer" => $answer]);
        }
        return response()->json(["message" => "Updated!"]);
    }
    public function answers()
    {
        $data = DB::table("answers")->where(["userid" => auth("api")->user()->id])->join("questions", "questions.id", "=", "answers.qid")->select("answers.answer", "questions.title")->get();
        return response()->json(["data" => $data]);
    }

    public function validate_account(Request $request)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://api.paystack.co/bank/resolve?account_number=$request->account_number&bank_code=$request->bank_code",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => array(
                "Authorization: Bearer sk_live_3a385f102ace7cef82c12b216b31ae8fe4bb4155",
                "Cache-Control: no-cache",
            ),
        ));

        $response = curl_exec($curl);
        $response = json_decode($response);
        $err = curl_error($curl);

        curl_close($curl);
        if ($response->status == false) {
            return response()->json(["message" => "Invalid Account Number"], 404);
        }

        return $response;

    }

    public function addnursereview(Request $request)
    {
        $rating = $request->rating;
        $comment = $request->comment;
        $nurse_id = $request->nurse_id;
        $check = DB::table("nurses")->where(["id" => $nurse_id])->first();
        if (!$check) {
            return response()->json(["message" => "Invalid Nurse ID"], 404);
        }

        DB::table("nurse_review")->insert(["rating" => $rating, "comment" => $comment, "nurse_id" => $nurse_id, "userid" => auth("api")->user()->id]);
        $data = DB::table("nurse_review")->join("nurses", "nurses.id", "=", "nurse_review.nurse_id")->where(["nurse_review.userid" => auth("api")->user()->id])->select("nurse_review.*", "nurses.first_name as nurse_first_name", "nurses.last_names as nurse_last_name")->get();
        return response()->json(["message" => "Review Added!", "data" => $data]);
    }

    public function adddocreview(Request $request)
    {
        $rating = $request->rating;
        $comment = $request->comment;
        $doc_id = $request->doc_id;
        $check = DB::table("doctors")->where(["id" => $doc_id])->first();
        if (!$check) {
            return response()->json(["message" => "Invalid Doctor ID"], 404);
        }

        DB::table("doctor_review")->insert(["rating" => $rating, "comment" => $comment, "doctor_id" => $doc_id, "userid" => auth("api")->user()->id]);
        $data = DB::table("doctor_review")->join("doctors", "doctors.id", "=", "doctor_review.doctor_id")->where(["doctor_review.userid" => auth("api")->user()->id])->select("doctor_review.*", "doctors.first_name as doc_first_name", "doctors.last_name as doc_last_name")->get();
        return response()->json(["message" => "Review Added!", "data" => $data]);
    }

    public function addpharreview(Request $request)
    {
        $rating = $request->rating;
        $comment = $request->comment;
        $pharmacy_id = $request->pharmacy_id;
        $check = DB::table("pharmacy")->where(["id" => $pharmacy_id])->first();
        if (!$check) {
            return response()->json(["message" => "Invalid Pharmacy ID"], 404);
        }

        DB::table("phar_review")->insert(["rating" => $rating, "comment" => $comment, "phar_id" => $pharmacy_id, "userid" => auth("api")->user()->id]);
        $data = DB::table("phar_review")->join("pharmacy", "pharmacy.id", "=", "phar_review.phar_id")->where(["phar_review.userid" => auth("api")->user()->id])->select("phar_review.*", "pharmacy.name as pharmacy_name")->get();
        return response()->json(["message" => "Review Added!", "data" => $data]);
    }

    public function addlabreview(Request $request)
    {
        $rating = $request->rating;
        $comment = $request->comment;
        $lab_id = $request->lab_id;
        $check = DB::table("laboratories")->where(["id" => $lab_id])->first();
        if (!$check) {
            return response()->json(["message" => "Invalid Lab ID"], 404);
        }

        DB::table("lab_review")->insert(["rating" => $rating, "comment" => $comment, "lab_id" => $lab_id, "userid" => auth("api")->user()->id]);
        $data = DB::table("lab_review")->join("laboratories", "laboratories.id", "=", "lab_review.lab_id")->where(["lab_review.userid" => auth("api")->user()->id])->select("lab_review.*", "laboratories.name as pharmacy_name")->get();
        return response()->json(["message" => "Review Added!", "data" => $data]);
    }

    public function addamreview(Request $request)
    {
        $rating = $request->rating;
        $comment = $request->comment;
        $am_id = $request->ambulance_id;
        $check = DB::table("ambulance")->where(["id" => $am_id])->first();
        if (!$check) {
            return response()->json(["message" => "Invalid Ambulance ID"], 404);
        }

        DB::table("am_review")->insert(["rating" => $rating, "comment" => $comment, "am_id" => $am_id, "userid" => auth("api")->user()->id]);
        $data = DB::table("am_review")->join("ambulance", "ambulance.id", "=", "am_review.am_id")->where(["am_review.userid" => auth("api")->user()->id])->select("am_review.*", "ambulance.name as ambulance_name")->get();
        return response()->json(["message" => "Review Added!", "data" => $data]);
    }

    public function pharmacyList(Request $request)
    {
        $data = DB::table("pharmacy")->join("p_step1", "p_step1.pid", "=", "pharmacy.id")->select("p_step1.name", "pharmacy.id")->get();
        return response()->json(["data" => $data]);
    }

    public function pharmacyProducts(Request $request)
    {
        /*
        $data = DB::table("products")
        ->join("pharmacy","pharmacy.id","=","products.pid")
        ->select("pharmacy.name as pharmacy_name","products.*")
        ->get();
         */

        $data = DB::table("products")->where(["pid" => $request->pharmacy_id])->get();

        return response()->json(["data" => $data]);
        //return response()->json(["data"=>["pharmacy_id"=>$request->pharmacy_id]]);

    }

    public function products()
    {
        $data = DB::table("products")
            ->join("pharmacy", "pharmacy.id", "=", "products.pid")
            ->select("pharmacy.name as pharmacy_name", "products.*")
            ->get();

        return response()->json(["data" => $data]);

    }

    public function services()
    {
        $data = DB::table("hospital_service")
            ->join("hospital", "hospital.id", "=", "hospital_service.hid")
            ->select("hospital.name as hospital_name", "hospital_service.*")
            ->get();

        return response()->json(["data" => $data]);

    }

    public function products_search(Request $request)
    {
        $text = $request->search;
        $data = DB::table("products")->where(function ($query) use ($text) {
            $query->orWhere('products.name', "like", "%" . $text . "%")
                ->orWhere('products.amount', "like", "%" . $text . "%")
                ->orWhere('pharmacy.name', "like", "%" . $text . "%")

            ;
        })->join("pharmacy", "pharmacy.id", "=", "products.pid")
            ->select("pharmacy.name as pharmacy_name", "products.*")->get();

        return response()->json(["data" => $data]);
    }

    public function get_percent($amount)
    {
        $s = DB::table("settings")->where(["type" => "pharmacy_percentage"])->first();
        $percentage = $s->text;
        $totalWidth = $amount;

        $new_width = ($percentage / 100) * $totalWidth;

        return $new_width;
    }

    public function get_percent2($amount)
    {
        $s = DB::table("settings")->where(["type" => "hospital_percentage"])->first();
        $percentage = $s->text;
        $totalWidth = $amount;

        $new_width = ($percentage / 100) * $totalWidth;

        return $new_width;
    }
    public function new_order_product(Request $request)
    {
        $response = json_decode($request['body']);
        $product = $response->products[0];
        $pid = $product->id;

        $product = DB::table("products")->where(["id" => $pid])->first();
        if (!$product) {
            return response()->json(["message" => "Invalid Product ID or Product Not Found!"], 404);
        }

        $addressFrom = $response->from_location;
        $addressTo = $response->to_location;

        // Get distance in km
        $distance = $this->getDistance($addressFrom, $addressTo, "K")[0];
        $p = DB::table("pharmacy")->where(["id" => $product->pid])->first();
        $check = DB::table("price_km")->where(function ($query) use ($distance) {
            $query->where('from', '>', $distance)
                ->orWhere('to', '=', $distance);
        })->where(["p_id" => $p->id])->first();
        if (!$check) {
            return response()->json(["message" => "Does not deliver to this location!", "distance" => $distance], 404);
        }
        if ($product->amount > auth("api")->user()->wallet + $check->price) {
            return response()->json(["message" => "You dont have sufficient amount to buy this product on your wallet!"], 400);
        }

        DB::table("patient")->where(["id" => auth("api")->user()->id])->decrement("wallet", $product->amount * $response->qty + $check->price);
        DB::table("pharmacy")->where(["id" => $product->pid])->increment("wallet", $this->get_percent($product->amount * $response->qty + $check->price));
        $orderID = DB::table("orders")->insertGetID(["userid" => auth("api")->user()->id, "pid" => $pid, "qty" => $response->qty, "type" => $response->type, "from_location" => $response->from_location, "to_location" => $response->to_location, "delivery_fee" => $check->price]);
        for ($x = 0; $x < count($response->products); $x++) {
            DB::table("order_detail")->insert(["order_id" => $orderID, "pharmacy_id" => $response->pharmacy_id, "product_id" => $response->products[$x]->id, "qty" => $response->products[$x]->qty]);
        }

        //---------------------------------
        //---------------------------------
        $data2 = array('to' => "APA91bFnoClQ9Z8i7RuvSGJ77STxMnF_zlC_EUXfrQr254pwgWalRPeWRsCabB3Tpw0WISmSRexiXj6z6hmzjVmIrWYvnvB1mzFhodyR-oqydgU2cQbkMx4",
            "notification" => [ //"body"=>$request->to,
                "title" => "New Order!!!"],
        );
        $data_json = json_encode($data2);

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://fcm.googleapis.com/fcm/send",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => $data_json,
            CURLOPT_HTTPHEADER => array(
                "Authorization: key=AAAA4unw2EQ:APA91bGuLDNG-TdwpTte8Pz_L9yKl2I75hibqjTT5yVrIsL1CoBXLq-87ntkWHp4tj8qshi2TbOj5NWTtZcIavCaWW2RI4rj3s1p0CYmyjoh0da8JD8OFIN5HFaAFYX96NoRoRtI9_BQ",
                "Cache-Control: no-cache",
                "Content-Type: application/json",
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        //---------------------------------
        //---------------------------------

        return response()->json(["message" => "Order successfully sent!"]);

    }

    public function orders()
    {
        $data = DB::table("orders")
            ->join("products", "products.id", "=", "orders.pid")
            ->join("pharmacy", "pharmacy.id", "=", "products.pid")
            ->where(["orders.userid" => auth("api")->user()->id])
            ->select("pharmacy.name as pharmacy_name", "products.name as product_name", "orders.*")
            ->get();
        return response()->json(["data" => $data]);
    }

    public function create_am_request()
    {

    }

    public function new_pickup(Request $request)
    {

        $distanceData = $this->getDistance($request->from, $request->to, "K");
        //        return [round($miles * 1.609344, 2),$latitudeFrom,$longitudeFrom,$latitudeTo,$longitudeTo];
        $latitudeFrom = $distanceData[1];
        $longitudeFrom = $distanceData[2];
        $latitudeTo = $distanceData[3];
        $longitudeTo = $distanceData[4];

        $distance = $distanceData[0];
        $datax = DB::table("logistic_price")->where(function ($query) use ($distance) {
            $query->where('from', '>', $distance)
                ->orWhere('to', '=', $distance);
        })->first();

        if (!$datax) {

            return response()->json(["message" => "We Dont Deliver Here"], 404);
        }
        $check = DB::table("laboratories")->where(["id" => $request->labid])->exists();
        if (!$check) {
            return response()->json(["message" => "Lab Not Found!"], 404);
        }
        $data = ["logistic" => $request->delivery_id, "labid" => $request->labid, "pid" => auth("api")->user()->id,
            "from_address" => $request->from, "to_address" => $request->to, "phone_number" => $request->phone_number,
            "status" => "processing", "price" => $datax->price,
            "user_lat" => $latitudeFrom, "user_lng" => $longitudeFrom,
            "distance" => $distance,
        ];

        $id = DB::table("pickup")->insertGetID($data);
        $data = ["id" => $id, "labid" => $request->labid, "pid" => auth("api")->user()->id, "from_address" => $request->from, "to_address" => $request->to, "phone_number" => $request->phone_number, "status" => "processing", "logistic" => "", "price" => $datax->price, "user_lat" => $latitudeFrom, "user_lng" => $longitudeFrom];

        $st = \Http::post('https://sonocare-51b1c-default-rtdb.firebaseio.com/pickup.json', $data);
        $d = $st->object();
        if ($st->failed()) {
            return response()->json(["message" => "Something Went Wrong", "error" => $d]);
        }
        DB::table("pickup")->where(["id" => $id])->update(["firebase_id" => $d->name]);

        //---------------------------------
        //---------------------------------
        $data2 = array('to' => "APA91bFnoClQ9Z8i7RuvSGJ77STxMnF_zlC_EUXfrQr254pwgWalRPeWRsCabB3Tpw0WISmSRexiXj6z6hmzjVmIrWYvnvB1mzFhodyR-oqydgU2cQbkMx4",
            "notification" => ["body" => $request->to,
                "title" => "New Booking!!!"],
        );
        $data_json = json_encode($data2);

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://fcm.googleapis.com/fcm/send",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => $data_json,
            CURLOPT_HTTPHEADER => array(
                "Authorization: key=AAAA4unw2EQ:APA91bGuLDNG-TdwpTte8Pz_L9yKl2I75hibqjTT5yVrIsL1CoBXLq-87ntkWHp4tj8qshi2TbOj5NWTtZcIavCaWW2RI4rj3s1p0CYmyjoh0da8JD8OFIN5HFaAFYX96NoRoRtI9_BQ",
                "Cache-Control: no-cache",
                "Content-Type: application/json",
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        //---------------------------------
        //---------------------------------

        return response()->json(["message" => "Request Processing", "firebase" => $d]);

    }

    public function get_logistic_price(Request $request)
    {
        $distance = $this->getDistance($request->from, $request->to, "K");
        $data = DB::table("logistic_price")->where(function ($query) use ($distance) {
            $query->where('from', '>', $distance)
                ->orWhere('to', '=', $distance);
        })->first();

        if ($data) {

            return response()->json(["data" => [
                "from" => $request->from,
                "to" => $request->to,
                "distance" => $distance . "KM",
                "price" => $data->price,

            ]]);

        } else {
            return response()->json(["message" => "We Dont Deliver Here"], 404);
        }
    }

    public function get_am_price(Request $request)
    {
        try{
        $distance = $this->getDistance($request->from, $request->to, "K");
        $data = DB::table("am_price")->where(function ($query) use ($distance) {
            $query->where('from', '>', $distance)
                ->orWhere('to', '=', $distance);
        })->first();

        if ($data) {

            return response()->json(["data" => [
                "from" => $request->from,
                "to" => $request->to,
                "distance" => $distance . "KM",
                "price" => $data->price,

            ]]);

        } else {
            return response()->json(["message" => "We Dont Deliver Here"], 404);
        }
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public function my_am_requests()
    {
        try{
        $data = DB::table("am_requests")->where(["pid" => auth("api")->user()->id])->join("ambulance", "ambulance.id", "=", "am_requests.aid")->select("am_requests.*", "ambulance.name as ambulance_name")->get();
        return response()->json(["data" => $data]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public function new_ambulance(Request $request)
    {
        try{
        $distanceData = $this->getDistance($request->from, $request->to, "K");
        //        return [round($miles * 1.609344, 2),$latitudeFrom,$longitudeFrom,$latitudeTo,$longitudeTo];
        $latitudeFrom = $distanceData[1];
        $longitudeFrom = $distanceData[2];
        $latitudeTo = $distanceData[3];
        $longitudeTo = $distanceData[4];

        $distance = $distanceData[0];

        $datax = DB::table("am_price")->where(function ($query) use ($distance) {
            $query->where('from', '>', $distance)
                ->orWhere('to', '=', $distance);
        })->first();

        if (!$datax) {
            return response()->json(["message" => "We Dont Deliver Here"], 404);
        }

        $check = DB::table("ambulance")->where(["id" => $request->ambulance_id])->exists();
        if (!$check) {
            return response()->json(["message" => "Lab Not Found!"], 404);
        }
        $data = ["aid" => $request->ambulance_id, "pid" => auth("api")->user()->id, "from_address" => $request->from, "to_address" => $request->to, "phone_number" => $request->phone_number, "status" => "processing", "price" => $datax->price, "firebase_id" => "-N0XRZc_hIhrR4rzxcvz",
            "user_lat" => $latitudeFrom, "user_lng" => $longitudeFrom, "distance" => $distance,
        ];

        $id = DB::table("am_requests")->insertGetID($data);
        $data = ["id" => $id, "aid" => $request->ambulance_id, "pid" => auth("api")->user()->id, "from_address" => $request->from, "to_address" => $request->to, "phone_number" => $request->phone_number, "status" => "processing", "price" => $datax->price,
            "user_lat" => $latitudeFrom, "user_lng" => $longitudeFrom,
        ];

        $st = \Http::post('https://sonocare-51b1c-default-rtdb.firebaseio.com/ambulance.json', $data);
        $d = $st->object();
        if ($st->failed()) {
            return response()->json(["message" => "Something Went Wrong", "error" => $d]);
        }
        DB::table("am_requests")->where(["id" => $id])->update(["firebase_id" => $d->name]);

        //---------------------------------
        //---------------------------------
        $data2 = array('to' => "APA91bFnoClQ9Z8i7RuvSGJ77STxMnF_zlC_EUXfrQr254pwgWalRPeWRsCabB3Tpw0WISmSRexiXj6z6hmzjVmIrWYvnvB1mzFhodyR-oqydgU2cQbkMx4",
            "notification" => ["body" => $request->to,
                "title" => "New Booking!!!"],
        );
        $data_json = json_encode($data2);

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://fcm.googleapis.com/fcm/send",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => $data_json,
            CURLOPT_HTTPHEADER => array(
                "Authorization: key=AAAA4unw2EQ:APA91bGuLDNG-TdwpTte8Pz_L9yKl2I75hibqjTT5yVrIsL1CoBXLq-87ntkWHp4tj8qshi2TbOj5NWTtZcIavCaWW2RI4rj3s1p0CYmyjoh0da8JD8OFIN5HFaAFYX96NoRoRtI9_BQ",
                "Cache-Control: no-cache",
                "Content-Type: application/json",
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        //---------------------------------
        //---------------------------------

        return response()->json(["message" => "Request Processing", "firebase" => $d]);

    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public function hospital_services(Request $request)
    {
        try{
        $data = DB::table("hospital_service")->where(["hid" => $request->hospital_id])->get();
        return response()->json(["data" => $data]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public function hospitals(Request $request)
    {
        $data = DB::table("hospital")->join("h_step1", "h_step1.hid", "=", "hospital.id")->select("h_step1.name", "hospital.id", "hospital.*")->get();
        return response()->json(["data" => $data]);
    }

    public function hospital_dates(Request $request)
    {
        $data = DB::table("h_dates")->get();
        return response()->json(["data" => $data]);
    }

    public function h_getSchedule(Request $request)
    {

        $data = DB::table("hospital_schedule")->where([
            "date" => $request->dates_id,
            "hid" => $request->hospital_id,
        ])->get();
        return response()->json(["data" => $data]);
    }
    public function book_hospital(Request $request)
    {
        $check = DB::table("hospital_bookings")->where(["service_id" => $request->service_id, "schedule_id" => $request->schedule_id, "hid" => $request->hospital_id])->whereIn("status", ["accepted", "pending"])->exists();
        if ($check) {
            return response()->json(["message" => "Booking Already Placed"], 400);
        }

        $check = DB::table("hospital_service")->where(["id" => $request->service_id])->exists();
        if (!$check) {
            return response()->json(["message" => "Service Not Found!"], 404);
        }

        $check = DB::table("hospital_schedule")->where(["id" => $request->schedule_id])->exists();
        if (!$check) {
            return response()->json(["message" => "Schedule Not Found!"], 404);
        }

        $check = DB::table("hospital")->where(["id" => $request->hospital_id])->exists();
        if (!$check) {
            return response()->json(["message" => "Hospital Not Found!"], 404);
        }

        $data = DB::table("hospital_service")->where(["id" => $request->service_id])->first();

        if ($data->amount > auth("api")->user()->wallet) {
            return response()->json(["message" => "Insufficient Balance In Wallet!"], 400);
        }
        DB::table("patient")->where(["id" => auth("api")->user()->id])->decrement("wallet", $data->amount);
        DB::table("patient_transaction")->insert(["amount" => $data->amount, "trans_id" => rand(), "userid" => auth("api")->user()->id, "type" => "hospital/appointment"]);

        DB::table("hospital_bookings")->insert(["service_id" => $request->service_id, "schedule_id" => $request->schedule_id, "price" => $data->amount, "hid" => $request->hospital_id, "userid" => auth("api")->user()->id]);
        //---------------------------------
        //---------------------------------
        $data2 = array('to' => "APA91bFnoClQ9Z8i7RuvSGJ77STxMnF_zlC_EUXfrQr254pwgWalRPeWRsCabB3Tpw0WISmSRexiXj6z6hmzjVmIrWYvnvB1mzFhodyR-oqydgU2cQbkMx4",
            "notification" => ["body" => $data->service_name,
                "title" => "New Booking!!!"],
        );
        $data_json = json_encode($data2);

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://fcm.googleapis.com/fcm/send",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => $data_json,
            CURLOPT_HTTPHEADER => array(
                "Authorization: key=AAAA4unw2EQ:APA91bGuLDNG-TdwpTte8Pz_L9yKl2I75hibqjTT5yVrIsL1CoBXLq-87ntkWHp4tj8qshi2TbOj5NWTtZcIavCaWW2RI4rj3s1p0CYmyjoh0da8JD8OFIN5HFaAFYX96NoRoRtI9_BQ",
                "Cache-Control: no-cache",
                "Content-Type: application/json",
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        //---------------------------------
        //---------------------------------
        return response()->json(["message" => "SuccesFully Booked"]);

    }

    public function hospital_bookings()
    {
        $data = DB::table("hospital_bookings")
            ->join("h_step1", "h_step1.hid", "=", "hospital_bookings.hid")
            ->join("hospital_service as hospital_services", "hospital_services.id", "=", "hospital_bookings.service_id")
            ->join("hospital_schedule", "hospital_schedule.id", "=", "hospital_bookings.schedule_id")
            ->where(["hospital_bookings.userid" => auth("api")->user()->id])
            ->select("h_step1.name", "hospital_services.service_name", "hospital_services.amount", "hospital_schedule.day", "hospital_schedule.time", "hospital_bookings.id as booking_id")->get();
        return response()->json(["data" => $data]);

    }

    public function hospital_booking_data(Request $request)
    {
        $data = DB::table("hospital_bookings")
            ->join("h_step1", "h_step1.hid", "=", "hospital_bookings.hid")
            ->join("hospital_service as hospital_services", "hospital_services.id", "=", "hospital_bookings.service_id")
            ->join("hospital_schedule", "hospital_schedule.id", "=", "hospital_bookings.schedule_id")
            ->where(["hospital_bookings.id" => $request->booking_id])
            ->where(["hospital_bookings.userid" => auth("api")->user()->id])
            ->select("h_step1.name", "hospital_services.service_name", "hospital_services.amount", "hospital_schedule.day", "hospital_schedule.time", "hospital_bookings.*")->first();
        return response()->json(["data" => $data]);

    }

    public function getAnswers(Request $request)
    {

        $data = DB::table("answers")->where([
            "userid" => $request->userid,

        ])->get();
        return response()->json(["data" => $data]);
    }

}
