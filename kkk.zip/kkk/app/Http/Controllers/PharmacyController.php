<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Mail;
use Hash;
use DB;
use Auth;
use Illuminate\Support\Facades\Log;
use Twilio\Rest\Client;
class PharmacyController extends Controller
{
    //

     public function register(Request $request){
        $name = $request->name;
        $email = $request->email;
        $token = rand(1111,9999);
        $phone = $request->phone;
        $password = Hash::make($request->password);

         if(!DB::table("preferences")->where(["id"=>$request->service_id])->exists()){
            return response()->json(["message"=>"Invalid Prefences #ID"],404);
        }
        $check = DB::table("pharmacy")->where(["email"=>$email])->exists();
        if($check){
            return response()->json(["message"=>"Mail Already Exists!"],409);
        }


          $check = DB::table("pharmacy")->where(["phone"=>$phone])->exists();
            if($check){
            return response()->json(["message"=>"Phone Number Already Exists!"],409);
        }
        DB::table("pharmacy")->insert([
            "name"=>$name,
            "email"=>$email,
            "token"=>$token,
            "password"=>$password,
            "service_preferences"=>$request->service_id,
            "phone"=>$phone
            ]);


              $user = DB::table("pharmacy")->where(["email"=>$email])->first();

              /*
working code, comment twilio is out of token
              //+14043345663
$twilio_number = "sonocare";
$account_sid = 'ACa07d9dfe8d7018ff2d519f75dcb7df84';
$auth_token = '98ad77cf03cbffdcd030173e84c8beb9';
$client = new Client($account_sid, $auth_token);
$client->messages->create(
    // Where to send a text message (your cell phone?)
    "+234$request->phone",
    array(
        'from' => $twilio_number,
        'body' => "OTP verification code from sonocare: $token"
    )
);

*/


   \Mail::send('mail3', ["user"=>$user], function ($message) use($user,$request) {

        $message->to($user->email)->subject("Email Verification | SonoCare");
    });
     $user = DB::table("pharmacy")->where(["email"=>$email])->select("email","phone","name")->first();
            return response()->json(["message"=>"Registration SuccessFul!","user"=>$user]);

    }

    public function verification(Request $request){
        $email = $request->email;
        $token = $request->token;
        $check = DB::table("pharmacy")->where(["email"=>$email,"token"=>$token])->exists();
        if($check){
            DB::table("pharmacy")->where(["email"=>$email,"token"=>$token])->update(["active"=>1]);
            return response()->json(["message"=>"Registration Success!"]);
        }else{
            return response()->json(["message"=>"Invalid OTP provided!"],400);
        }
    }


    public function login(Request $request){
        try{
        $credentials = request(['email', 'password']);

        if($token = auth("pharmacy")->attempt($credentials)){
            $email = auth("pharmacy")->user()->email;
            if(auth("pharmacy")->user()->active != 1){
                 $user = DB::table("pharmacy")->where(["email"=>$email])->first();
$twilio_number = "sonocare";
$account_sid = 'ACa07d9dfe8d7018ff2d519f75dcb7df84';
$auth_token = '98ad77cf03cbffdcd030173e84c8beb9';
$client = new Client($account_sid, $auth_token);
$client->messages->create(
    // Where to send a text message (your cell phone?)
    "+234$user->phone",
    array(
        'from' => $twilio_number,
        'body' => "OTP verification code from sonocare: $user->token"
    )
);




   \Mail::send('mail3', ["user"=>$user], function ($message) use($user,$request) {

        $message->to($user->email)->subject("Email Verification | SonoCare");
    });
     $user = DB::table("pharmacy")->where(["email"=>$email])->select("email","phone","name")->first();
                return response()->json(["message"=>"Account Not Verified","user"=>$user],400);
            }
              if(auth("pharmacy")->user()->status != 1){
                return response()->json(["message"=>"Account Pending For Verification","token"=>$token],400);
            }
              return $this->respondWithToken($token);
        }else{
            return response()->json(["message"=>"Invalid Login Details!"],401);
        }
    }catch (\Exception $e){
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, ".$e->getMessage()], 500);
        }
    }




    public function step1(Request $request){
        try{
        if(DB::table("p_step1")->where(["pid"=>auth("pharmacy")->user()->id])->exists()){
            return response()->json(["message"=>"Already Registered"],400);
        }
        DB::table("p_step1")->insert([
            "name"=>$request->p_name,
            "speciality"=>$request->speciality,
            "p_code"=>$request->p_code,
            "reg_num"=>$request->reg_num,
            "pid"=>auth("pharmacy")->user()->id

            ]);

            return response()->json(["message"=>"SuccessFully Saved!"]);
        }catch (\Exception $e){
            Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred, ".$e->getMessage()], 500);
            }
    }


    public function step2(Request $request){
        try{
      $userid = auth("pharmacy")->user()->id;
        $check = DB::table("p_step2")->where(["pid"=>$userid])->exists();
        if($check){
            return response()->json(["message"=>"Already Registered!"],400);
        }else{

$id_card = time().$request->id_card->getClientOriginalName();
$request->id_card->move(public_path('uploads'), $id_card);

           DB::table("p_step2")->insert([
               "country"=>$request->country,
               "state"=>$request->state,
               "pid"=>$userid,
               "refer"=>$request->refer,
               "account_number"=>$request->account_number,
               "account_name"=>$request->account_name,
               "account_bank_code"=>$request->bank_code,
               "account_bank"=>$request->bank_name,
               "identity_card"=>"/uploads/$id_card"
               ]);
               return response()->json(["message"=>"Success!"]);
        }
    }catch (\Exception $e){
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, ".$e->getMessage()], 500);
        }
    }
    public function step3(Request $request){
        try{
        $userid = auth("pharmacy")->user()->id;
        $check = DB::table("p_step3")->where(["pid"=>$userid])->exists();
        if($check){
            return response()->json(["message"=>"Already Registered!"],400);
        }else{

$pha_cert = time().$request->pha_cert->getClientOriginalName();
$request->pha_cert->move(public_path('uploads'), $pha_cert);

$pha_license = time().$request->pha_license->getClientOriginalName();
$request->pha_license->move(public_path('uploads'), $pha_license);


$backing = time().$request->backing_info->getClientOriginalName();
$request->backing_info->move(public_path('uploads'), $backing);

           DB::table("p_step3")->insert([
               "p_license"=>"/uploads/$pha_license",
               "backing_info"=>"/uploads/$backing",
               "p_cert"=>"/uploads/$pha_cert",
               "about"=>$request->about,
               "pid"=>$userid
               ]);
               return response()->json(["message"=>"Success!"]);
        }
    }catch (\Exception $e){
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, ".$e->getMessage()], 500);
        }
    }

    public function step4(Request $request){
        DB::table("pharmacy")->where(["id"=>auth("pharmacy")->user()->id])->update(["cac_number"=>$request->cac_number,"company"=>$request->company]);
        return response()->json(["message"=>"Updated SuccessFully"]);
    }

    public function profile(){
        return response()->json(["user"=>auth("pharmacy")->user()]);
    }

    public function updateprofile(Request $request){
        $check = DB::table("pharmacy")->where(["id"=>$request->id])->exists();
        if(!$check){
            return response()->json(["message"=>"Profile Not found!"],404);
        }

        DB::table("pharmacy")->where(["id"=>$request->id])->update([
            "name"=>$request->name,
            "first_name"=>$request->first_name,
            "last_name"=>$request->last_name,
            "email"=>$request->email,
            "phone" => $request->phone,
            "address" => $request->address,
            "company" => $request->company
        ]);
        return response()->json(["message"=>"Updated SuccessFully!","data"=>$request->except("token")]);
    }
    public function create_product(Request $req){

        $data = [
            'name' => $req->name,
            'pid' => auth('pharmacy')->user()->id,
            'amount' => $req->amount,
            'dosage' => $req->dosage,
            "drug_type" => $req->drug_type,
            "drug_brand" => $req->drug_brand,
            "drug_category" => $req->drug_category,
            "description" => $req->description,
            "pack_package_price" => $req->pack_package_price
            ];

           $insert = DB::table('products')->insert($data);
           $id = DB::getPdo()->lastInsertId();
           if($insert){
               return response()->json(['message' => 'Product created Successfully', 'data' => $data, 'id'=>$id]);
           }
           return response()->json(['message' => 'Failed To Create Product']);

    }

    public function products(Request $request){
        $data = DB::table("products")->where(["pid"=>auth("pharmacy")->user()->id])->get();
        return response()->json(["data"=>$data]);
    }

public function get_products(Request $request){
     if($request->q){
           $data = DB::table("products")->where(["pid"=>$request->id])    ->where('name', 'like', '%' . $request->q . '%')->get();

     }else{
           $data = DB::table("products")->where(["pid"=>$request->id])->get();

     }
        return response()->json(["data"=>$data]);
}

    public function updateproduct(Request $request){
        $check = DB::table("products")->where(["id"=>$request->id])->exists();
        if(!$check){
            return response()->json(["message"=>"Product Not found!"],404);
        }

        DB::table("products")->where(["id"=>$request->id])->update(["name"=>$request->name,"amount"=>$request->amount,
        "drug_type" => $request->drug_type,
        "drug_brand" => $request->drug_brand,
        "drug_category" => $request->drug_category,
        "description" => $request->description,
        "pack_package_price" => $request->pack_package_price,
        "dosage"=>$request->dosage]);
        return response()->json(["message"=>"Updated SuccessFully!","data"=>$request->except("token")]);
    }

    public function deleteproduct(Request $request){
        $check = DB::table("products")->where(["id"=>$request->id])->exists();
        if(!$check){
            return response()->json(["message"=>"Product Not found!"],404);
        }

        DB::table("products")->where(["id"=>$request->id])->delete();
        return response()->json(["message"=>"Deleted SuccessFully!","data"=>$request->except("token")]);
    }

     public function search(Request $request){
        $text = $request->search;
        $data = DB::table("products")->where(function($query) use ($text){
                     $query->orWhere('name', "like", "%" . $text . "%")
                     ->orWhere('amount', "like", "%" . $text . "%")
                       ->orWhere('created_at', "like", "%" . $text . "%")

                     ;
              })->get();

              return response()->json(["data"=>$data]);
    }

      public function resend_otp(Request $request){
        $email = $request->email;
            $user = DB::table("pharmacy")->where(["email"=>$email])->first();
            if(!$user){
                return response()->json(["message"=>"Invalid User Email!"],404);
            }

            $token = $user->token;
$twilio_number = "sonocare";
$account_sid = 'ACa07d9dfe8d7018ff2d519f75dcb7df84';
$auth_token = '98ad77cf03cbffdcd030173e84c8beb9';
$client = new Client($account_sid, $auth_token);
$client->messages->create(
    // Where to send a text message (your cell phone?)
    "+234$user->phone",
    array(
        'from' => $twilio_number,
        'body' => "OTP verification code from sonocare: $token"
    )
);




   \Mail::send('mail3', ["user"=>$user], function ($message) use($user,$request) {

        $message->to($user->email)->subject("Email Verification | SonoCare");
    });

    return response()->json(["message"=>"OTP resent successfully!"]);
    }

    public function update_account(Request $request){

        $data = [
            "account_number" => $request->account_number,
            "account_name" => $request->account_name,
            "account_bank" => $request->account_bank,
            "bank_code" => $request->bank_code,
              ];

        $update = DB::table('pharmacy')
        ->where('id', auth('pharmacy')->user()->id)
        ->update($data);

        if($update){
            return response()->json(["message" => "Updated Successfully"]);
        }else{
            return response()->json(["message" => "Account Already Updated "]);
        }

    }

    public function update_fcm(Request $request){
        $fcm = $request->fcm;
        DB::table("pharmacy")->where(["id"=>auth("pharmacy")->user()->id])->update(["fcm"=>$fcm]);
        return response()->json(["message"=>"Updated!"]);
    }


          public function phar_reviews(){
          $data = DB::table("phar_review")
          ->join("patient","patient.id","=","phar_review.userid")
          ->where(["phar_review.phar_id"=>auth("pharmacy")->user()->id])
          ->select("phar_review.*","patient.first_name as patient_first_name",
          "patient.last_name as patient_last_name")
          ->get();

return response()->json(["data"=>$data]);
    }

    public function user(){
        return response()->json(["user"=>auth("pharmacy")->user()]);
    }

        protected function respondWithToken($token)
    {
        return response()->json([
            'access_token' => $token,
            'token_type' => 'bearer',
            'expires_in' => auth("pharmacy")->factory()->getTTL() * 60,
            'user'=>auth("pharmacy")->user()
        ]);
    }

      public function orders(){
          /*
         $data = DB::table("orders")
         ->join("products","products.id","=","orders.pid")
        ->join("patient","patient.id","=","products.pid")
        ->where(["products.pid"=>auth("pharmacy")->user()->id])
        ->select("patient.first_name as patient_name","patient.phone_number as patient_phone","products.name as product_name","orders.*")
        ->get();
        */
        $data = DB::table("orders")
        ->join("patient","patient.id","=","orders.userid")
        ->where(["orders.pid"=>auth("pharmacy")->user()->id])
        ->select("patient.image as image","patient.first_name as fname","patient.last_name as lname","patient.phone_number as patient_phone","orders.*")
        ->get();
        return response()->json(["data"=>$data]);
     }

     public function order_detail(Request $request){
         $data = DB::table("order_detail")
                 ->join("products","products.id","=","order_detail.product_id")
                 ->where(["order_detail.order_id"=>$request->order_id])
                 ->get();
        return response()->json(["data"=>$data]);
     }

     public function add_price_km(Request $request){
         $from = $request->from;
         $to = $request->to;
         $price = $request->price;
        $check =  DB::table("price_km")->where(["from"=>$from,"to"=>$to,"p_id"=>auth("pharmacy")->user()->id])->exists();
        if($check){
            return response()->json(["message"=>"KM already exists!"],400);
        }else{
            DB::table("price_km")->insert(["from"=>$from,"to"=>$to,"price"=>$price,"p_id"=>auth("pharmacy")->user()->id]);
            return response()->json(["message"=>"Added!"]);
        }
     }

     public function all_km(){
         $data =  DB::table("price_km")->where(["p_id"=>auth("pharmacy")->user()->id])->get();
         return response()->json(["data"=>$data]);
     }


     public function pharmacys(){
          $data = DB::table("pharmacy")->where(["active"=>1,"status"=>1])->select("address","longitude","latitude","name","id")->get();
            return response()->json(["data"=>$data]);
     }

      public function update_address(Request $request){
       $address  = $request->address;

        DB::table("ambulance")->where(["id"=>auth("pharmacy")->user()->id])->update([

            "latitude"=>$request->latitude,
            "address"=>$address,
            "longitude"=>$request->longitude
            ]);
                return response()->json(["message"=>"Updated!"]);
    }

    public function reviews(){
        //important fields, and please the spelling should be thesame as the example below.
        //example: {"id":"1","patient_first_name":"Mohammed","patient_last_name":"Aliyu","rating":"2","comment":"This is a nice app","created_at":"2021-12-23 01:37:25"}

        $data          = [];
        $data[]       = ['id' => '1', "patient_first_name"=>"Mohammed","patient_last_name"=>"Aliyu","logistic_id" => "48","userid" => "14","rating" => "2","comment" => "This is a nice app", "created_at" => "2021-12-23 01:37:25"];
        $data[]       = ['id' => '2', "patient_first_name"=>"Musa","patient_last_name"=>"Ibrahim","logistic_id" => "48","userid" => "14","rating" => "5","comment" => "This is a nice logistic", "created_at" => "2021-12-23 01:37:25"];
        $data[]       = ['id' => '3', "patient_first_name"=>"Nelson","patient_last_name"=>"Nil","logistic_id" => "48","userid" => "14","rating" => "1","comment" => "Great service", "created_at" => "2021-12-23 01:37:25"];
        $data[]       = ['id' => '4', "patient_first_name"=>"Godspower","patient_last_name"=>"power","logistic_id" => "48","userid" => "14","rating" => "5","comment" => "I like it", "created_at" => "2021-12-23 01:37:25"];

        return response()->json(["data"=>$data]);
    }

    public function transaction_history(){
        //important fields, and please the spelling should be thesame as the example below.
        //example: {"id":"1","patient_first_name":"Mohammed","patient_last_name":"Aliyu","rating":"2","comment":"This is a nice app","created_at":"2021-12-23 01:37:25"}

        $account   = ["balance" => "200100","account-type" => "Independent",];
        $transactions   = [];
        $transactions[] = ['id' => '1', "status" => "Pending","type" => "withdrawal","amount" => "2500", "date" => "2021-12-23 01:37:25"];
        $transactions[] = ['id' => '2', "status" => "Approved","type" => "withdrawal","amount" => "5000", "date" => "2021-12-23 01:37:25"];
        $transactions[] = ['id' => '3', "status" => "Approved","type" => "withdrawal","amount" => "11000", "date" => "2021-12-23 01:37:25"];
        $transactions[] = ['id' => '4', "status" => "Approved","type" => "withdrawal","amount" => "760", "date" => "2021-12-23 01:37:25"];

        $transactions = DB::table('pharmacy_transaction')->where('pharmacy_id', auth('pharmacy')->user()->id)->get();

        return response()->json(['data' => $transactions, 'balance'=>auth("pharmacy")->user()->wallet]);

    }

    public function preferences(){
        $data = DB::table('pharmacy_preference')->get();

        return response()->json(['data' => $data]);
    }


    public function get_preferences(){
        $selected_preference = DB::table('pharmacy_preference')->where('pharmacy_id', auth('pharmacy')->user()->id)->get();

        return response()->json(['selected_service_preference'=>$selected_preference]);
    }


    public function set_service_preferences(Request $req){
        $data = "empty";///DB::table('pharmacy_preference')->get();

        $pharmacy_preference = DB::table('pharmacy_preference')->where('pharmacy_id', auth('pharmacy')->user()->id)->get();

        $req->amount;
        $req->preference_type;
        $req->type;
        if(count($pharmacy_preference) != 0){
            $data = "not empty";
            /*

pharmacy_id
preference_type
amount
type
created_at
            */
            DB::table("pharmacy_preference")->where(["pharmacy_id"=>auth("pharmacy")->user()->id])->update([
            "pharmacy_id"=>auth("pharmacy")->user()->id,
            "preference_type"=>$req->preference_type,
            "amount"=>$req->amount,
            "type"=>$req->type,
            ]);
        }else{
            DB::table("pharmacy_preference")->insert([
            "pharmacy_id"=>auth("pharmacy")->user()->id,
            "preference_type"=>$req->preference_type,
            "amount"=>$req->amount,
            "type"=>$req->type,
            ]);
        }


        return response()->json(['data' => $data, 'pref'=>$pharmacy_preference, 'amount'=>$req->amount, 'pref_type'=>$req->preference_type, 'type'=>$req->type]);
    }

     public function withdrawal(Request $req){
        $money = DB::table('pharmacy')->where('id' , auth('pharmacy')->user()->id)->first();

        if($money->wallet == null ){
            return response()->json(['message' => 'Update Your Account']);
        }

            if($req->amount < 1000){
                 return response()->json(['message' => 'You Cant Withdraw LessThan 1000 ']);

            }
            if($money->wallet < $req->amount){
                return response()->json(['message' => 'Insufficient Fund']);
            }
                $withdraw = DB::table('pharmacy')->where('id' , auth('pharmacy')->user()->id)->decrement("wallet",$req->amount);
                DB::table("pharmacy_transaction")->insert(["amount"=>$req->amount,"type"=>"Withdrawal","pharmacy_id"=>auth("pharmacy")->user()->id]);

                if($withdraw){
                     return response()->json(['message' =>  "Widthrawal Successful Submited, the amount will be settled in to your Account shortly"]);
                }
                     return response()->json(['message' =>  "Please Try Again"]);
    }
        public function accept_order(request $request){
         if(!DB::table("orders")->where(["id"=>$request->id])->exists()){
             return response()->json(["message"=>"Order Not Found!"],404);
         }
        $update = DB::table("orders")->where(["id"=>$request->id])->update(["status"=>"Accepted"]);


             return response()->json(['message'=>'Order Accepted Successfuly']);


    }

     public function cancel_order(request $request){
         if(!DB::table("orders")->where(["id"=>$request->id])->exists()){
             return response()->json(["message"=>"Order Not Found!"],404);
         }
        $update = DB::table("orders")->where(["id"=>$request->id])->update(["status"=>"Declined"]);


             return response()->json(['message'=>'Order Declined Successfuly',"id"=>$request->id]);




    }

     public function confirmOrderHandover(request $request){
         if(!DB::table("orders")->where(["id"=>$request->id])->exists()){
             return response()->json(["message"=>"Order Not Found!"],404);
         }
        $update = DB::table("orders")->where(["id"=>$request->id])->update(["status"=>"Handover", "lid"=>$request->deliveryID]);
             return response()->json(['message'=>'Order Declined Successfuly',"id"=>$request->id]);
    }

}
