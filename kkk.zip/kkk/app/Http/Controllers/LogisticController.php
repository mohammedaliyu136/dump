<?php

namespace App\Http\Controllers;

use Auth;
use DB;
use Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Twilio\Rest\Client;

class LogisticController extends Controller
{
    //
    public function logistics()
    {
        $data = DB::table("logistic")->where(["active" => 1, "status" => 1])->select("id", "address", "longitude", "latitude", "name", "fee")->get();
        return response()->json(["data" => $data]);
    }
    public function register(Request $request)
    {
        $name = $request->name;
        $email = $request->email;
        $phone = $request->phone;
        $token = rand(1111, 9999);
        $password = Hash::make($request->password);
        /*
        $dob = $request->dob;
        $password = Hash::make($request->password);
        $state  = $request->state_id;
        $lga = $request->lga_id;
         */
        /*
        if(!DB::table("preferences")->where(["id"=>$request->service_id])->exists()){
        return response()->json(["message"=>"Invalid Prefences #ID"],404);
        }
         */
        $check = DB::table("logistic")->where(["email" => $email])->exists();
        if ($check) {
            return response()->json(["message" => "User Mail Already Exists!"], 409);
        }
        $check = DB::table("logistic")->where(["phone" => $phone])->exists();
        if ($check) {
            return response()->json(["message" => "User Phone Number Already Exists!"], 409);
        }
        DB::table("logistic")->insert([
            "name" => $name,
            "email" => $email,
            "phone" => $phone,
            "token" => $token,
            "dob" => "12-12-12",
            "password" => $password,
            "state_id" => 1,
            "lga_id" => 1,
            "service_id" => $request->service_id,
            "fee" => "100",
        ]);

        $user = DB::table("logistic")->where(["email" => $email])->first();

        /*
        $twilio_number = "+14043345663";
        $account_sid = 'ACa07d9dfe8d7018ff2d519f75dcb7df84';
        $auth_token = '98ad77cf03cbffdcd030173e84c8beb9';
        $client = new Client($account_sid, $auth_token);
        $client->messages->create(
        // Where to send a text message (your cell phone?)
        "$request->phone",
        array(
        'from' => $twilio_number,
        'body' => "OTP verification code from sonocare: $token"
        )
        );
         */
/*
working code, comment twilio is out of token
$twilio_number = "sonocare";
$account_sid = 'ACa07d9dfe8d7018ff2d519f75dcb7df84';
$auth_token = '98ad77cf03cbffdcd030173e84c8beb9';
$client = new Client($account_sid, $auth_token);
$client->messages->create(
// Where to send a text message (your cell phone?)
"+234$request->phone",
array(
'from' => $twilio_number,
'body' => "OTP verification code from sonocare: $token"
)
);
 */

        \Mail::send('mail2', ["user" => $user], function ($message) use ($user, $request) {

            $message->to($user->email)->subject("Email Verification | SonoCare");
        });
        $user = DB::table("logistic")->where(["email" => $email])->select("email", "phone", "name")->first();
        return response()->json(["message" => "Registration SuccessFul!", "user" => $user]);

    }

    public function verify(Request $request)
    {
        $email = $request->email;
        $token = $request->token;
        $check = DB::table("logistic")->where(["email" => $email, "token" => $token])->exists();
        if ($check) {
            DB::table("logistic")->where(["email" => $email, "token" => $token])->update(["active" => 1]);
            return response()->json(["message" => "Registration Success!"]);
        } else {
            return response()->json(["message" => "Invalid OTP provided!"], 400);
        }
    }

    public function login(Request $request)
    {
        try{
        /*
        $credentials = request(['email', 'password']);

        if($token = auth("logistic")->attempt($credentials)){
        $email = auth("logistic")->user()->email;
        if(auth("logistic")->user()->active != 1){
        $user = DB::table("logistic")->where(["email"=>$email])->first();
        $twilio_number = "sonocare";
        $account_sid = 'ACa07d9dfe8d7018ff2d519f75dcb7df84';
        $auth_token = '98ad77cf03cbffdcd030173e84c8beb9';
        $client = new Client($account_sid, $auth_token);
        $client->messages->create(
        // Where to send a text message (your cell phone?)
        "$user->phone",
        array(
        'from' => $twilio_number,
        'body' => "OTP verification code from sonocare: $user->token"
        )
        );
         */
        $credentials = request(['email', 'password']);

        if ($token = auth("logistic")->attempt($credentials)) {
            $email = auth("logistic")->user()->email;
            if (auth("logistic")->user()->active != 1) {
                $user = DB::table("logistic")->where(["email" => $email])->first();
                $twilio_number = "sonocare";
                $account_sid = 'ACa07d9dfe8d7018ff2d519f75dcb7df84';
                $auth_token = '98ad77cf03cbffdcd030173e84c8beb9';
                $client = new Client($account_sid, $auth_token);
                $client->messages->create(
                    // Where to send a text message (your cell phone?)
                    "+234$user->phone",
                    array(
                        'from' => $twilio_number,
                        'body' => "OTP verification code from sonocare: $user->token",
                    )
                );

                \Mail::send('mail2', ["user" => $user], function ($message) use ($user, $request) {

                    $message->to($user->email)->subject("Email Verification | SonoCare");
                });
                $user = DB::table("logistic")->where(["email" => $email])->select("email", "phone", "name")->first();
                return response()->json(["message" => "Account Not Verified", "user" => $user], 401);
            }
            if (auth("logistic")->user()->status != 1) {
                return response()->json(["message" => "Account Pending For Verification", "token" => $token], 400);
            }
            return $this->respondWithToken($token);
        } else {
            return response()->json(["message" => "Invalid Login Details!"], 401);
        }
    }catch (\Exception $e){
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, ".$e->getMessage()], 500);
        }
    }

    public function me()
    {
        try{
        return response()->json(["user" => auth("logistic")->user()]);
    }catch (\Exception $e){
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, ".$e->getMessage()], 500);
        }
    }

    protected function respondWithToken($token)
    {
        try{
        return response()->json([
            'access_token' => $token,
            'token_type' => 'bearer',
            'expires_in' => auth("logistic")->factory()->getTTL() * 60,
            'user' => auth("logistic")->user(),
        ]);
    }catch (\Exception $e){
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, ".$e->getMessage()], 500);
        }
    }

    public function updateprofile2(Request $request)
    {
        try{
        $name = $request->name;
        $dob = $request->dob;
        $state = $request->state_id;
        $lga = $request->lga_id;
        DB::table("logistic")->where(["id" => auth("logistic")->user()->id])->update(["dob" => $dob, "name" => $name, "state_id" => $state, "lga_id" => $lga]);
        return response()->json(["message" => "Updated SuccessFully!"]);
    }catch (\Exception $e){
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, ".$e->getMessage()], 500);
        }
    }

    public function updateprofile(Request $request)
    {try{
        $check = DB::table("logistic")->where(["id" => $request->id])->exists();
        if (!$check) {
            return response()->json(["message" => "Profile Not found!"], 404);
        }

        DB::table("logistic")->where(["id" => $request->id])->update([
            "first_name" => $request->first_name,
            "last_name" => $request->last_name,
            "name" => $request->name,
            "email" => $request->email,
            "phone" => $request->phone,
            "address" => $request->address,
        ]);
        return response()->json(["message" => "Updated SuccessFully!", "data" => $request->except("token")]);
    }catch (\Exception $e){
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, ".$e->getMessage()], 500);
        }
    }

    public function resend_otp(Request $request)
    {
        try{
        $email = $request->email;
        $user = DB::table("logistic")->where(["email" => $email])->first();
        if (!$user) {
            return response()->json(["message" => "Invalid User Email!"], 404);
        }

        $token = $user->token;
        $twilio_number = "sonocare";
        $account_sid = 'ACa07d9dfe8d7018ff2d519f75dcb7df84';
        $auth_token = '98ad77cf03cbffdcd030173e84c8beb9';
        $client = new Client($account_sid, $auth_token);
        $client->messages->create(
            // Where to send a text message (your cell phone?)
            "$user->phone",
            array(
                'from' => $twilio_number,
                'body' => "OTP verification code from sonocare: $token",
            )
        );

        \Mail::send('mail3', ["user" => $user], function ($message) use ($user, $request) {

            $message->to($user->email)->subject("Email Verification | SonoCare");
        });

        return response()->json(["message" => "OTP resent successfully!"]);
    }catch (\Exception $e){
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, ".$e->getMessage()], 500);
        }
    }
    public function update_fcm(Request $request)
    {
        try{
        $fcm = $request->fcm;
        DB::table("logistic")->where(["id" => auth("logistic")->user()->id])->update(["fcm" => $fcm]);
        return response()->json(["message" => "Updated!"]);
    }catch (\Exception $e){
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, ".$e->getMessage()], 500);
        }
    }

    public function update_address(Request $request)
    {
        try{
        $address = $request->address;

        DB::table("logistic")->where(["id" => auth("logistic")->user()->id])->update([

            "latitude" => $request->latitude,
            "address" => $address,
            "longitude" => $request->longitude,
        ]);
        return response()->json(["message" => "Updated!"]);
    }catch (\Exception $e){
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, ".$e->getMessage()], 500);
        }
    }

    public function add_price_km(Request $request)
    {
        $from = $request->from;
        $to = $request->to;
        $price = $request->price;
        $check = DB::table("logistic_price")->where(["from" => $from, "to" => $to, "lid" => auth("logistic")->user()->id])->exists();
        if ($check) {
            return response()->json(["message" => "KM already exists!"], 400);
        } else {
            DB::table("logistic_price")->insert(["from" => $from, "to" => $to, "price" => $price, "lid" => auth("logistic")->user()->id]);
            return response()->json(["message" => "Added!"]);
        }
    }

    public function all_km()
    {
        $data = DB::table("logistic_price")->where(["lid" => auth("logistic")->user()->id])->get();
        return response()->json(["data" => $data]);
    }

    public function accept_pickup(Request $request)
    {
        /*
        $data = \Http::get("https://sonocare-51b1c-default-rtdb.firebaseio.com/pickup/$request->firebase_id.json");

        $data = $data->object();

        if($data == null){
        return response()->json(["message"=>"Something went wrong, check firebase id"],400);
        }
        if($data->status == "ongoing"){
        return response()->json(["message"=>"Request Already Accepted!"],400);
        }

        \Http::patch("https://sonocare-51b1c-default-rtdb.firebaseio.com/pickup/$request->firebase_id.json",[

        "logistic"=>auth("logistic")->user()->id,
        "status"=>"ongoing"

        ]);*/

        DB::table("pickup")->where(["id" => $request->requestID])->update([

            "logistic" => auth("logistic")->user()->id,
            "status" => "ongoing",

        ]);

        return response()->json(["message" => "Accepted"]);

    }

    public function complete_pickup(Request $request)
    {
        /*
        $data = \Http::get("https://sonocare-51b1c-default-rtdb.firebaseio.com/pickup/$request->firebase_id.json");

        $data = $data->object();

        if($data == null){
        return response()->json(["message"=>"Something went wrong, check firebase id"],400);
        }
        if($data->status == "completed"){
        return response()->json(["message"=>"Request Already Completed!"],400);
        }

        $p = DB::table("settings")->where(["type"=>"logistic_percentage"])->first();
        $percentInDecimal = $p->text / 100;

        $percent = $percentInDecimal * $p->text;

        \Http::patch("https://sonocare-51b1c-default-rtdb.firebaseio.com/pickup/$request->firebase_id.json",[

        "status"=>"completed"

        ]);
         */
        $p = DB::table("settings")->where(["type" => "logistic_percentage"])->first();
        $percentInDecimal = $p->text / 100;

        $percent = $percentInDecimal * $p->text;

        DB::table("pickup")->where(["id" => $request->requestID])->update([

            "status" => "completed",

        ]);
        DB::table("logistic")->where(["id" => auth("logistic")->user()->id])->increment("wallet", $percent);
        return response()->json(["message" => "Completed"]);

    }

    public function cancel_pickup(Request $request)
    {

        DB::table("pickup")->where(["id" => $request->requestID])->update([

            "status" => "canceled",

        ]);
        return response()->json(["message" => "Pickup canceled"]);
    }

    public function my_pickup()
    {
        try{
        $data = DB::table("pickup")->where(["logistic" => auth("logistic")->user()->id])->join("patient", "patient.id", "=", "pickup.pid")->select("pickup.*", DB::raw("CONCAT(first_name, ' ', last_name) AS patient_name"), "patient.image")->get();
        return response()->json(["data" => $data]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public function step2verification(Request $request)
    {
        $userid = auth("logistic")->user()->id;

        DB::table("logistic_step2")->insert([
            "company" => $request->company,
            "from" => $request->from,
            "logistic_id" => $userid,
            "to" => $request->to,
            "current" => $request->current,

        ]);
        return response()->json(["message" => "Success!", "data" => $request->all()]);

    }

    public function step1verification(Request $request)
    {
        $userid = auth("logistic")->user()->id;
        $check = DB::table("logistic_step1")->where(["logistic_id" => $userid])->exists();
        if ($check) {
            return response()->json(["message" => "Already Registered!"], 400);
        } else {

            $id_card = time() . $request->file('id_card')->getClientOriginalName();
            $request->id_card->move(public_path('logistic'), $id_card);

            DB::table("logistic_step1")->insert([
                "country" => $request->country,
                "state" => $request->state,
                "logistic_id" => $userid,
                "refer" => $request->refer,
                "id_card" => "/logistic/$id_card",
                "account_number" => $request->account_number,
                "account_bank" => $request->account_bank,
                "account_name" => $request->account_name,
                "bank_code" => $request->bank_code,
            ]);
            return response()->json(["message" => "Success!", "data" => $request->all()]);
        }
    }

    public function update_account(Request $request)
    {

        $data = [
            "account_number" => $request->account_number,
            "account_name" => $request->account_name,
            "account_bank" => $request->account_bank,
            "bank_code" => $request->bank_code,
        ];

        $update = DB::table('logistic')
            ->where('id', auth('logistic')->user()->id)
            ->update($data);

        if ($update) {
            return response()->json(["message" => "Updated Successfully"]);
        } else {
            return response()->json(["message" => "Account Already Updated "]);
        }

    }

    public function reviews()
    {
        //important fields, and please the spelling should be thesame as the example below.
        //example: {"id":"1","patient_first_name":"Mohammed","patient_last_name":"Aliyu","rating":"2","comment":"This is a nice app","created_at":"2021-12-23 01:37:25"}

        $data = [];
        $data[] = ['id' => '1', "patient_first_name" => "Mohammed", "patient_last_name" => "Aliyu", "logistic_id" => "48", "userid" => "14", "rating" => "2", "comment" => "This is a nice app", "created_at" => "2021-12-23 01:37:25"];
        $data[] = ['id' => '2', "patient_first_name" => "Musa", "patient_last_name" => "Ibrahim", "logistic_id" => "48", "userid" => "14", "rating" => "5", "comment" => "This is a nice logistic", "created_at" => "2021-12-23 01:37:25"];
        $data[] = ['id' => '3', "patient_first_name" => "Nelson", "patient_last_name" => "Nil", "logistic_id" => "48", "userid" => "14", "rating" => "1", "comment" => "Great service", "created_at" => "2021-12-23 01:37:25"];
        $data[] = ['id' => '4', "patient_first_name" => "Godspower", "patient_last_name" => "power", "logistic_id" => "48", "userid" => "14", "rating" => "5", "comment" => "I like it", "created_at" => "2021-12-23 01:37:25"];

        //$review = DB::table("logistic_review")
        //->join("patient","patient.id","=","logistic_review.userid")
        //->where(["logistic_review.logistic_id"=>auth("logistic")->user()->id])
        //->select("logistic_review.*","patient.first_name as patient_first_name","patient.last_name as patient_last_name",)
        //->get();

        $review = DB::table("logistic_review")
            ->join("patient", "patient.id", "=", "logistic_review.userid")
            ->where(["logistic_review.logistic_id" => auth("logistic")->user()->id])
            ->select("logistic_review.*", "patient.first_name as patient_first_name",
                "patient.last_name as patient_last_name")
            ->get();
        return response()->json(["data" => $review]);
    }

    public function transaction_history()
    {
        //important fields, and please the spelling should be thesame as the example below.
        //example: {"id":"1","patient_first_name":"Mohammed","patient_last_name":"Aliyu","rating":"2","comment":"This is a nice app","created_at":"2021-12-23 01:37:25"}

        $account = ["balance" => "200100", "account-type" => "Independent"];
        $transactions = [];
        $transactions[] = ['id' => '1', "status" => "Pending", "type" => "withdrawal", "amount" => "2500", "date" => "2021-12-23 01:37:25"];
        $transactions[] = ['id' => '2', "status" => "Approved", "type" => "withdrawal", "amount" => "5000", "date" => "2021-12-23 01:37:25"];
        $transactions[] = ['id' => '3', "status" => "Approved", "type" => "withdrawal", "amount" => "11000", "date" => "2021-12-23 01:37:25"];
        $transactions[] = ['id' => '4', "status" => "Approved", "type" => "withdrawal", "amount" => "760", "date" => "2021-12-23 01:37:25"];

        $data = DB::table('logistic_transaction')->where('logistic_id', auth('logistic')->user()->id)->get();

        return response()->json(["data" => $data, 'balance' => auth("logistic")->user()->wallet]);
    }

    public function preference(Request $req)
    {
        $data = DB::table('logistic_preference')->get();
        return response()->json(['data' => $data]);
    }

    public function get_preferences()
    {
        $selected_preference = DB::table('logistic_preference')->where('logistic_id', auth('logistic')->user()->id)->get();

        return response()->json(['selected_service_preference' => $selected_preference]);
    }

    public function set_service_preferences(Request $req)
    {
        $data = "empty"; ///DB::table('pharmacy_preference')->get();

        $logistic_preference = DB::table('logistic_preference')->where('logistic_id', auth('logistic')->user()->id)->get();

        $req->amount;
        $req->preference_type;
        $req->type;
        if (count($logistic_preference) != 0) {
            $data = "not empty";
            DB::table("logistic_preference")->where(["logistic_id" => auth("logistic")->user()->id])->update([
                "logistic_id" => auth("logistic")->user()->id,
                "preference_type" => $req->preference_type,
                "amount" => $req->amount,
                "type" => $req->type,
            ]);
        } else {
            DB::table("logistic_preference")->insert([
                "logistic_id" => auth("logistic")->user()->id,
                "preference_type" => $req->preference_type,
                "amount" => $req->amount,
                "type" => $req->type,
            ]);
        }

        return response()->json(['data' => $data]);
    }

    public function withdrawal(Request $req)
    {
        $money = DB::table('logistic')->where('id', auth('logistic')->user()->id)->first();

        if ($money->wallet == null) {
            return response()->json(['message' => 'Update Your Account']);
        }

        if ($req->amount < 1000) {
            return response()->json(['message' => 'You Cant Withdraw LessThan 1000 ']);

        }
        if ($money->wallet < $req->amount) {
            return response()->json(['message' => 'Insufficient Fund']);
        }
        $withdraw = DB::table('logistic')->where('id', auth('logistic')->user()->id)->decrement("wallet", $req->amount);
        DB::table("logistic_transaction")->insert(["amount" => $req->amount, "type" => "Withdrawal", "logistic_id" => auth("logistic")->user()->id]);

        if ($withdraw) {
            return response()->json(['message' => "Widthrawal Successful Submited, the amount will be settled in to your Account shortly"]);
        }
        return response()->json(['message' => "Please Try Again"]);
    }

}
