<?php

namespace App\Http\Controllers;

use App\CentralLogics\Helpers;
use App\Models\VitalSign;
use Auth;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth as FacadesAuth;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Twilio\Rest\Client;

class AdminController extends Controller
{
    //

    public function sender($name, $email, $phone, $reason, $type, $dtype)
    {
        try {
            $m = $reason;
            if ($type == "approve") {

                \Mail::send('approvemail', ["name" => $name, "email" => $email, "phone" => $phone, "reason" => $reason, "dtype" => $dtype, "type" => $type, "data" => "Your Account Have Been Approved"], function ($message) use ($email) {

                    $message->to($email)->subject("Account Verification Status | SonoCare");
                });

                // if ($phone != "") {
                //     $twilio_number = "+14043345663";
                //     $account_sid = 'ACa07d9dfe8d7018ff2d519f75dcb7df84';
                //     $auth_token = '98ad77cf03cbffdcd030173e84c8beb9';
                //     $client = new Client($account_sid, $auth_token);
                //     $client->messages->create(
                //         // Where to send a text message (your cell phone?)
                //         "+234$phone",
                //         array(
                //             'from' => $twilio_number,
                //             'body' => "Dear $name, Your Account Have Been Approved!",
                //         )
                //     );

                // }

            } else {
                \Mail::send('declinemail', ["name" => $name, "email" => $email, "phone" => $phone, "reason" => $reason, "type" => $type, "dtype" => $dtype, "data" => $m], function ($message) use ($email) {

                    $message->to($email)->subject("Account Verification Status | SonoCare");
                });
                // if ($phone != "") {
                //     $twilio_number = "+14043345663";
                //     $account_sid = 'ACa07d9dfe8d7018ff2d519f75dcb7df84';
                //     $auth_token = '98ad77cf03cbffdcd030173e84c8beb9';
                //     $client = new Client($account_sid, $auth_token);
                //     $client->messages->create(
                //         // Where to send a text message (your cell phone?)
                //         "+234$phone",
                //         array(
                //             'from' => $twilio_number,
                //             'body' => "Dear $name, $m!",
                //         )
                //     );
                // }
            }
        } catch (\Exception $e) {
            return redirect()->back()->with('status', $e->getMessage());
        }
    }

    public function setmode(Request $request)
    {
        try {
            $mode = $request->mode;
            session()->put("mode", $mode);
        } catch (\Exception $e) {
            return redirect()->back()->with('status', $e->getMessage());
        }
    }

    public function apptesting(Request $request)
    {
        try {
            $doctors = DB::table("doctors")->latest()->orderBy("id", "DESC")->get();
            $patients = DB::table("patient")->latest()->orderBy("id", "DESC")->get();
            $nurses = DB::table("nurses")->latest()->orderBy("id", "DESC")->get();
            return view("admin.apptest.apptest", compact("doctors",
                "patients", "nurses"));
        } catch (\Exception $e) {
            return redirect()->back()->with('status', $e->getMessage());
        }
    }

    public function testBookDoctor(Request $request)
    {
        try {
            //1-12-2022 87 10:00AM 4
            //$schedule = DB::table("doctor_schedule")->where(["doc_id"=>$request->doc_id])->first();

            // Convert to timetamps
            $min = strtotime(1111);
            $max = strtotime(2023);

            // Generate random number using above bounds
            $val = rand($min, $max);

            // Convert back to desired date format
            $da = date('Y-m-d', $val);

            $schedule_id = DB::table("doctor_schedule")->insertGetId([
                "date" => rand(1, 28) . "-" . rand(1, 12) . "-" . rand(1000, 2023),
                "doctor_id" => $request->doc_id,
                "time" => rand(1, 12) . ":" . rand(1, 59) . "AM",
                "day" => rand(1, 7),

            ]);

            $service = DB::table("doctors_services")->where(["doctor_id" => $request->doc_id])->first();
            if (!$service) {
                $service_id = DB::table("doctors_services")->insertGetId([
                    "services_type" => "Independent",
                    "price" => 200,
                    "doctor_id" => $request->doc_id,

                ]);
            } else {
                $service_id = $service->id;
            }

            $doctors_appointment = DB::table("doctors_appointment")->insertGetId([
                "schedule_id" => $schedule_id,
                "patient_id" => $request->patient_id,
                "service_id" => $service_id,
                "trans_id" => "83889",
                "type" => "type",

            ]);

            Helpers::send_push_notif_to_topic(
                //"fqAEpgCQQzm5v-2q89wIb-:APA91bG3yws8LZDDoSAvVLz844BpH-dSb0yiX9eXbmKKcIhVUQys-Ky-fMbzPMRATcGDnwdGlAA9GHx-MQw4hV_Zx2Cq_NjtLUDXU6dRcO0eJ92dZXjWlkQXwksWj_E5Drr6jXqRfcvp",
                'doctor_' . $request->doc_id,
                //'partner',
                ["title" => "New Booking!!!", "description" => "Patient have booked an appointment", 'type' => 'doctor', 'token' => $doctors_appointment, 'channel' => $request->patient_id, 'user' => 'doctor']
            );

            return redirect('/app/testing');
        } catch (\Exception $e) {
            return redirect()->back()->with('status', $e->getMessage());
        }
    }

    public function testBookNurse(Request $request)
    {
        try {
            $VitalSign = VitalSign::insertGetId([
                'nurse_id' => $request->nurse_id,
                'patient_id' => $request->patient_id,
                "latitude" => 10.633615,
                "longitude" => 6.926008,

            ]);

            Helpers::send_push_notif_to_topic(
                //"fqAEpgCQQzm5v-2q89wIb-:APA91bG3yws8LZDDoSAvVLz844BpH-dSb0yiX9eXbmKKcIhVUQys-Ky-fMbzPMRATcGDnwdGlAA9GHx-MQw4hV_Zx2Cq_NjtLUDXU6dRcO0eJ92dZXjWlkQXwksWj_E5Drr6jXqRfcvp",
                'nurse_' . $request->nurse_id,
                ["title" => "New Booking!!!", "description" => "Vital sign reading", 'type' => 'nurse', 'token' => $VitalSign, 'channel' => "", 'user' => 'nurse', 'vitalsign_id' => $VitalSign, 'patient_id' => $request->patient_id]
            );
            return redirect('/app/testing');
        } catch (\Exception $e) {
            return redirect()->back()->with('status', $e->getMessage());
        }
    }

    public function login()
    {
        try {
            // Check if the user is already authenticated
            if (FacadesAuth::check()) {
                // Redirect to dashboard if authenticated
                return redirect()->route('dashboard')->with('status', 'session exists');
            }
            return view("admin.login");
        } catch (\Exception $e) {
            return redirect()->back()->with('status', $e->getMessage());
        }
    }

    public function plogin(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);

        try {
            $email = $request->email;
            $password = $request->password;

            // Pass plain password for Auth::attempt()
            if (FacadesAuth::guard("web")->attempt(["email" => $email, "password" => $password])) {
                return redirect()->route('dashboard');
            } else {
                return redirect()->back()->with('status', "Invalid Login Details");
            }
        } catch (\Exception $e) {
            return redirect()->back()->with('status', $e->getMessage());
        }
    }

    public function logout(Request $request)
    {
        try {
            // Log the user out of the application
            Auth::logout();

            // Invalidate the user's session and regenerate the CSRF token
            $request->session()->invalidate();
            $request->session()->regenerateToken();

            // Redirect the user to the login page or home page
            return redirect()->route('login')->with('status', 'You have been logged out successfully!');

        } catch (\Exception $e) {
            return redirect()->back()->with('status', $e->getMessage());
        }
    }
    public function dash()
    {
        try {
            $doctors = DB::table("doctors")->latest()->orderBy("id", "DESC")->limit(4)->get();
            $patients = DB::table("patient")->latest()->orderBy("id", "DESC")->limit(5)->get();
            $nurses = DB::table("nurses")->latest()->orderBy("id", "DESC")->limit(5)->get();
            return view("admin.dash", compact("doctors", "patients", "nurses"));
        } catch (\Exception $e) {
            return redirect()->back()->with('status', $e->getMessage());
        }
    }

    public function doctors()
    {
        try {
            $data = DB::table("doctors")->orderBy("id", "DESC")->simplePaginate(10);
            return view("admin.doctor.doctors", compact("data"));
        } catch (\Exception $e) {
            return redirect()->back()->with('status', $e->getMessage());
        }
    }

    public function nurses()
    {
        try {
            $data = DB::table("nurses")->orderBy("id", "DESC")->simplePaginate(10);
            return view("admin.nurses", compact("data"));
        } catch (\Exception $e) {
            return redirect()->back()->with('status', $e->getMessage());
        }
    }

    public function patients()
    {
        try {
            $data = DB::table("patient")->orderBy("id", "DESC")->simplePaginate(10);
            return view("admin.patients", compact("data"));
        } catch (\Exception $e) {
            return redirect()->back()->with('status', $e->getMessage());
        }
    }

    public function doctorprofile(Request $request)
    {
        try {
            $id = $request->id;
            $data = DB::table("doctors")->where(["id" => $id])->first();
            if (!$data) {
                return view("admin.error");
            } else {
                $type = 1;
                $lga = DB::table("lga")->where(["id" => $data->lga_id])->first();
                $state = DB::table("state")->where(["id" => $data->state_id])->first();
                $step1 = DB::table("d_step1")->where(["doctor_id" => $id])->first();
                $step2 = DB::table("d_step2")->where(["doctor_id" => $id])->first();
                $step3 = DB::table("d_step3")->where(["doctor_id" => $id])->first();
                $step4 = DB::table("d_step4")->where(["doctor_id" => $id])->get();

                return view("admin.doctor.doctorprofile", compact("data", "lga", "state", "step1", "step2", "step3", "step4", "type"));
            }
        } catch (\Exception $e) {
            return redirect()->back()->with('status', $e->getMessage());
        }
    }

    public function disapprove_doctor(Request $request)
    {
        try {
            $doctor = DB::table("doctors")->where(["id" => $request->id])->update(["status" => 2, "reason_for_disapprove" => $request->reason]);
            $doc = DB::table("doctors")->where(["id" => $request->id])->first();
            $this->sender($doc->first_name, $doc->email, $doc->phone_number, $request->reason, "disapprove", "Doctor");
            return response()->json(["message" => "SuccessFully Disapproved!"]);
        } catch (\Exception $e) {
            return redirect()->back()->with('status', $e->getMessage());
        }
    }

    public function approve_doctor(Request $request)
    {
        try {

            $doctor = DB::table("doctors")->where(["id" => $request->id])->update(["status" => 1]);
            $doc = DB::table("doctors")->where(["id" => $request->id])->first();
            $this->sender($doc->first_name, $doc->email, $doc->phone_number, "", "approve", "Doctor");
            return response()->json(["message" => "SuccessFully Approved!"]);
        } catch (\Exception $e) {
            return redirect()->back()->with('status', $e->getMessage());
        }
    }

    public function services(Request $request)
    {
        try {
            $data = DB::table("doctors")->where(["id" => $request->id])->first();
            if (!$data) {
                return view("admin.error");
            } else {
                $type = 2;
                $data2 = DB::table("doctors_services")->where(["doctor_id" => $request->id])->get();
                return view("admin.doctor.services", compact("data2", "data", "type"));

            }
        } catch (\Exception $e) {
            return redirect()->back()->with('status', $e->getMessage());
        }
    }

    public function appointments(Request $request)
    {
        try {
            $data = DB::table("doctors")->where(["id" => $request->id])->first();
            if (!$data) {
                return view("admin.error");
            } else {
                $type = 3;
                $data2 = DB::table("doctors_appointment")->join("doctor_schedule", "doctor_schedule.id", "=", "doctors_appointment.schedule_id")->where(["doctor_schedule.doctor_id" => $request->id])->get();
                return view("admin.doctor.appointments", compact("data2", "data", "type"));

            }
        } catch (\Exception $e) {
            return redirect()->back()->with('status', $e->getMessage());
        }
    }

    //nurse area

    public function nurseprofile(Request $request)
    {
        try {
            $id = $request->id;
            $data = DB::table("nurses")->where(["id" => $id])->first();
            if (!$data) {
                return view("admin.error");
            } else {
                $type = 1;
                $lga = DB::table("lga")->where(["id" => $data->lga_id])->first();
                $state = DB::table("state")->where(["id" => $data->state_id])->first();
                $step1 = DB::table("n_step1")->where(["nurse_id" => $id])->first();
                $step2 = DB::table("n_step2")->where(["nurse_id" => $id])->first();
                $step3 = DB::table("n_step3")->where(["nurse_id" => $id])->first();
                $step4 = DB::table("n_step4")->where(["nurse_id" => $id])->get();
                $sp = DB::table("preferences")->where(["id" => $data->service_preferences])->first();
                $ns = DB::table("nurse_services")->where(["id" => $data->nurse_service])->first();
                return view("admin.nurse.nurseprofile", compact("data", "lga", "state", "step1", "step2", "step3", "step4", "type", "ns", "sp"));
            }
        } catch (\Exception $e) {
            return redirect()->back()->with('status', $e->getMessage());
        }
    }

    public function disapprove_nurse(Request $request)
    {
        try {
            $doctor = DB::table("nurses")->where(["id" => $request->id])->update(["status" => 2, "reason_for_disapprove" => $request->reason]);
            $data = DB::table("nurses")->where(["id" => $request->id])->first();
            $this->sender($data->first_name, $data->email, $data->phone_number, $request->reason, "disapprove", "Nurse");
            return response()->json(["message" => "SuccessFully Disapproved!"]);
        } catch (\Exception $e) {
            \Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
        }
    }

    public function approve_nurse(Request $request)
    {
        try {
            $doctor = DB::table("nurses")->where(["id" => $request->id])->update(["status" => 1]);
            $data = DB::table("nurses")->where(["id" => $request->id])->first();
            $this->sender($data->first_name, $data->email, $data->phone_number, "", "approve", "Nurse");
            return response()->json(["message" => "SuccessFully Approved!"]);
        } catch (\Exception $e) {
            \Log::error('Error : ' . $e->getMessage());
            return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
        }
    }

    public function vitalsigns(Request $request)
    {
        try {
            $id = $request->id;
            $data = DB::table("nurses")->where(["id" => $id])->first();
            if (!$data) {
                return view("admin.error");
            } else {

                $type = 2;
                $data2 = DB::table("VitalSign")->where(["nurse_id" => $id])->get();
                return view("admin.nurse.vitalsigns", compact("type", "data", "data2"));
            }
        } catch (\Exception $e) {
            return redirect()->back()->with('status', $e->getMessage());
        }
    }

    public function trans(Request $request)
    {
        try {
            $id = $request->id;
            $data = DB::table("nurses")->where(["id" => $id])->first();
            if (!$data) {
                return view("admin.error");
            } else {

                $type = 3;
                $data2 = DB::table("nurse_transactions")->where(["nurse_id" => $id])->get();
                return view("admin.nurse.trans", compact("type", "data", "data2"));
            }
        } catch (\Exception $e) {
            return redirect()->back()->with('status', $e->getMessage());
        }
    }

    public function patientprofile(Request $request)
    {
        try {
            $id = $request->id;
            $data = DB::table("patient")->where(["id" => $id])->first();
            if (!$data) {
                return view("admin.error");
            } else {

                $type = 1;
                $lga = DB::table("lga")->where(["id" => $data->lga_id])->first();
                $state = DB::table("state")->where(["id" => $data->state_id])->first();

                $vitalSigns = DB::table("VitalSign")->where(["patient_id" => $id])->get();
                $appointments = DB::table("doctors_appointment")->join("doctor_schedule", "doctor_schedule.id", "=", "doctors_appointment.schedule_id")->where(["doctors_appointment.patient_id" => $request->id])->get();
                $transactions = DB::table("patient_transaction")->where(["userid" => $id])->get();

                return view("admin.patient.main", compact("type", "data", "state", "lga", "vitalSigns", "appointments", "transactions"));
            }
        } catch (\Exception $e) {
            return redirect()->back()->with('status', $e->getMessage());
        }
    }

    public function ptrans(Request $request)
    {
        try {
            $id = $request->id;
            $data = DB::table("patient")->where(["id" => $id])->first();
            if (!$data) {
                return view("admin.error");
            } else {

                $type = 2;
                $data2 = DB::table("patient_transaction")->where(["userid" => $id])->get();
                return view("admin.patient.trans", compact("type", "data", "data2"));
            }
        } catch (\Exception $e) {
            return redirect()->back()->with('status', $e->getMessage());
        }
    }

    public function pvitalsigns(Request $request)
    {
        try {
            $id = $request->id;
            $data = DB::table("patient")->where(["id" => $id])->first();
            if (!$data) {
                return view("admin.error");
            } else {

                $type = 3;
                $data2 = DB::table("VitalSign")->where(["patient_id" => $id])->get();
                return view("admin.patient.vitalsigns", compact("type", "data", "data2"));
            }
        } catch (\Exception $e) {
            return redirect()->back()->with('status', $e->getMessage());
        }
    }

    public function pappointments(Request $request)
    {
        try {

            $data = DB::table("patient")->where(["id" => $request->id])->first();
            if (!$data) {
                return view("admin.error");
            } else {
                $type = 4;
                $data2 = DB::table("doctors_appointment")->join("doctor_schedule", "doctor_schedule.id", "=", "doctors_appointment.schedule_id")->where(["doctors_appointment.patient_id" => $request->id])->get();
                return view("admin.patient.appointments", compact("data2", "data", "type"));

            }
        } catch (\Exception $e) {
            return redirect()->back()->with('status', $e->getMessage());
        }
    }

    public function indexlogistic(Request $request)
    {
        try {
            $data = DB::table("logistic")->simplePaginate(10);

            return view("admin.logistic.main", compact("data"));
        } catch (\Exception $e) {
            return redirect()->back()->with('status', $e->getMessage());
        }
    }

    public function indexambulance(Request $request)
    {
        try{
        $data = DB::table("ambulance")->simplePaginate(10);
        return view("admin.ambulance.main", compact("data"));
    } catch (\Exception $e) {
        return redirect()->back()->with('status', $e->getMessage());
    }
    }

    public function logisticdash(Request $request)
    {
        try{
        $id = $request->id;
        $data = DB::table("logistic")->where(["id" => $id])->first();
        if (!$data) {
            return view("admin.error");
        } else {

            $type = 1;
            $lga = DB::table("lga")->where(["id" => $data->lga_id])->first();
            $state = DB::table("state")->where(["id" => $data->state_id])->first();
            return view("admin.logistic.dash", compact("type", "data", "state", "lga"));
        }
    } catch (\Exception $e) {
        return redirect()->back()->with('status', $e->getMessage());
    }
    }

    public function disapprove_logistic(Request $request)
    {
        try{
        $doctor = DB::table("logistic")->where(["id" => $request->id])->update(["status" => 2, "reason_for_disapprove" => $request->reason]);
        $data = DB::table("logistic")->where(["id" => $request->id])->first();
        $this->sender($data->name, $data->email, $data->phone, $request->reason, "disapprove", "Logistic");
        return response()->json(["message" => "SuccessFully Disapproved!"]);
    } catch (\Exception $e) {
        \Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public function approve_logistic(Request $request)
    {
        try{
        $doctor = DB::table("logistic")->where(["id" => $request->id])->update(["status" => 1]);
        $data = DB::table("logistic")->where(["id" => $request->id])->first();
        $this->sender($data->name, $data->email, $data->phone, "", "approve", "Logistic");
        return response()->json(["message" => "SuccessFully Approved!"]);
    } catch (\Exception $e) {
        \Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public function ambulancedash(Request $request)
    {
try{
        $id = $request->id;
        $data = DB::table("ambulance")->where(["id" => $id])->first();
        if (!$data) {
            return view("admin.error");
        } else {

            $type = 1;
            $lga = DB::table("lga")->where(["id" => $data->lga_id])->first();
            $state = DB::table("state")->where(["id" => $data->state_id])->first();
            $lga = DB::table("lga")->where(["id" => $data->lga_id])->first();
            $state = DB::table("state")->where(["id" => $data->state_id])->first();
            $step1 = DB::table("am_step1")->where(["am_id" => $id])->first();
            $step2 = DB::table("am_step2")->where(["am_id" => $id])->first();
            $step3 = DB::table("am_step3")->where(["am_id" => $id])->first();
            $step4 = DB::table("am_step4")->where(["am_id" => $id])->get();

            return view("admin.ambulance.dash", compact("data", "lga", "state", "step1", "step2", "step3", "step4", "type"));

        }
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public function disapprove_ambulance(Request $request)
    {
        try{
        $doctor = DB::table("ambulance")->where(["id" => $request->id])->update(["status" => 2, "reason_for_disapprove" => $request->reason]);
        $data = DB::table("ambulance")->where(["id" => $request->id])->first();
        $this->sender($data->name, $data->email, $data->phone, $request->reason, "disapprove", "Ambulance");
        return response()->json(["message" => "SuccessFully Disapproved!"]);

    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public function approve_ambulance(Request $request)
    {
        try{
        $doctor = DB::table("ambulance")->where(["id" => $request->id])->update(["status" => 1]);
        $data = DB::table("ambulance")->where(["id" => $request->id])->first();
        $this->sender($data->name, $data->email, $data->phone, "", "approve", "Ambulance");
        return response()->json(["message" => "SuccessFully Approved!"]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public function doctor_type()
    {
        try{
        $data = DB::table("doctor_type")->simplePaginate(8);
        return view("admin.type.doctor_type", compact("data"));
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public function nurse_type()
    {
        try{
        $data = DB::table("nurse_type")->simplePaginate(8);
        return view("admin.type.nurse_type", compact("data"));
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public function nurse_type_delete(Request $request)
    {
        try{
        $id = $request->id;
        DB::table("nurse_type")->where(["id" => $id])->delete();
        return response()->json(["message" => "Deleted SuccessFully!"]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public function new_nurse_type(Request $request)
    {
        try{
        $name = $request->name;
        DB::table("nurse_type")->insert(["title" => $name]);
        return response()->json(["message" => "Created!"]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public function edit_nurse_type(Request $request)
    {
        try{
        $name = $request->name;
        $id = $request->id;
        DB::table("nurse_type")->where(["id" => $id])->update(["title" => $name]);
        return response()->json(["message" => "Updated!"]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public function doctor_type_delete(Request $request)
    {
        try{
        $id = $request->id;
        DB::table("doctor_type")->where(["id" => $id])->delete();
        return response()->json(["message" => "Deleted SuccessFully!"]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public function new_doctor_type(Request $request)
    {
        try{
        $name = $request->name;
        DB::table("doctor_type")->insert(["name" => $name]);
        return response()->json(["message" => "Created!"]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public function edit_doctor_type(Request $request)
    {
        try{
        $name = $request->name;
        $id = $request->id;
        DB::table("doctor_type")->where(["id" => $id])->update(["name" => $name]);
        return response()->json(["message" => "Updated!"]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public function vitaldata()
    {
        try{
        $data = DB::table("VitalSign")
            ->join("patient", "patient.id", "=", "VitalSign.patient_id")
            ->join("nurses as nurse", "nurse.id", "=", "VitalSign.nurse_id")
            ->select("VitalSign.*", "nurse.first_name as nurse_firstname", "nurse.last_names as nurse_lastname", "patient.first_name as pfirstname", "patient.last_name as plastname", "patient.id as pid", "nurse.id as nid")
            ->simplePaginate(8);
        return view("admin.nurse.services.vitalsigns", compact("data"));
    } catch (\Exception $e) {
        return redirect()->back()->with('status', $e->getMessage());
    }
    }

    public function labcategory()
    {
        try{
        $data = DB::table("lab_category")->simplePaginate(8);
        return view("admin.lab.category", compact("data"));
    } catch (\Exception $e) {
        return redirect()->back()->with('status', $e->getMessage());
    }
    }

    public function labsubcategory()
    {
        try{
        $data = DB::table("lab_subcat")->join("lab_category", "lab_category.id", "=", "lab_subcat.category_id")->select("lab_subcat.*", "lab_category.name as catname", "lab_category.id  as catid")->simplePaginate(8);
        return view("admin.lab.subcategory", compact("data"));
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public function labdeletecat(Request $request)
    {
        try{
        $id = $request->id;
        DB::table("lab_category")->where(["id" => $id])->delete();
        return response()->json(["message" => "Deleted SuccessFully!"]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public function labnewcat(Request $request)
    {
        try{
      return  $name = $request->name;
        DB::table("lab_category")->insert(["name" => $name]);
        return response()->json(["message" => "Created!"]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public function labeditcat(Request $request)
    {
        try{
        $name = $request->name;
        $id = $request->id;
        DB::table("lab_category")->where(["id" => $id])->update(["name" => $name]);
        return response()->json(["message" => "Updated!"]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }
    public function labnewsubcat(Request $request)
    {
        try{
        $name = $request->name;
        $cat = $request->cat;
        DB::table("lab_subcat")->insert(["name" => $name, "category_id" => $cat]);
        return response()->json(["message" => "Created!"]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public function labeditsubcat(Request $request)
    {
        try{
        $name = $request->name;
        $cat = $request->cat;
        DB::table("lab_subcat")->where(["id" => $request->id])->update(["name" => $name, "category_id" => $cat]);
        return response()->json(["message" => "Updated!"]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public function labdeletesubcat(Request $request)
    {
        try{
        $id = $request->id;
        DB::table("lab_subcat")->where(["id" => $id])->delete();
        return response()->json(["message" => "Deleted SuccessFully!"]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public function labreport()
    {
        try{
        $data = DB::table("lab_report")
            ->join("laboratories", "laboratories.id", "=", "lab_report.labid")
            ->join("lab_services", "lab_services.id", "=", "lab_report.lab_service_id")
            ->select("lab_report.*", "laboratories.name as labname", "lab_services.amount as labfee")
            ->simplePaginate(8);
        return view("admin.lab.report", compact("data"));
    } catch (\Exception $e) {
        return redirect()->back()->with('status', $e->getMessage());
    }
    }

    public function labtrans()
    {
        try{
        $data = DB::table("lab_transactions")
            ->join("laboratories", "laboratories.id", "=", "lab_transactions.labid")
            ->select("lab_transactions.*", "laboratories.name as labname")
            ->simplePaginate(8);
        return view("admin.lab.trans", compact("data"));
    } catch (\Exception $e) {
        return redirect()->back()->with('status', $e->getMessage());
    }
    }

    public function subscription(Request $request)
    {
        try{
        $data = DB::table("subscription")->simplePaginate(8);
        return view("admin.subscription", compact("data"));
    } catch (\Exception $e) {
        return redirect()->back()->with('status', $e->getMessage());
    }
    }

    public function updateplan(Request $request)
    {
        try{
        $title = $request->title;
        $price = $request->price;
        $type = $request->type;
        $des = $request->des;
        DB::table("subscription")->where(["id" => $request->id])->update(["subscription_title" => $title, "price" => $price, "type" => $type, "description" => $des]);
        return response()->json(["message" => "Updated!"]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public function settings()
    {
        try{
        $data = DB::table("settings")->get();
        return view("admin.settings", compact("data"));
    } catch (\Exception $e) {
        return redirect()->back()->with('status', $e->getMessage());
    }
    }

    public function psettings(Request $request)
    {
        try{
        $data = $request->except("_token");

        foreach ($data as $d => $dd) {

            DB::table("settings")->where(["type" => $d])->update(["text" => $dd]);
        }

        return response()->json(["message" => "Updated!"]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }

    }

    public function questions()
    {
        try{
        $data = DB::table("questions")->orderBy("id", "DESC")->simplePaginate(8);
        return view("admin.questions", compact("data"));
    } catch (\Exception $e) {
        return redirect()->back()->with('status', $e->getMessage());
    }
    }

    public function new_question(Request $request)
    {
        try{
        $name = $request->name;
        DB::table("questions")->insert(["title" => $name]);
        return response()->json(["message" => "Created!"]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public function edit_question(Request $request)
    {
        try{
        $name = $request->name;
        $id = $request->id;
        DB::table("questions")->where(["id" => $id])->update(["title" => $name]);
        return response()->json(["message" => "Updated!"]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }

    }

    public function delete_question(Request $request)
    {
        try{
        $id = $request->id;
        DB::table("questions")->where(["id" => $id])->delete();
        return response()->json(["message" => "Deleted SuccessFully!"]);
    } catch (\Exception $e) {
        return redirect()->back()->with('status', $e->getMessage());
    }
    }

    public function lab_users()
    {
        try{
        $data = DB::table("laboratories")->simplePaginate(10);
        return view("admin.lab.users", compact("data"));
    } catch (\Exception $e) {
        return redirect()->back()->with('status', $e->getMessage());
    }
    }

    public function lab_user(Request $request)
    {
        try{
        $id = $request->id;
        $data = DB::table("laboratories")->where(["id" => $id])->first();
        $step1 = DB::table("lab_step1")->where(["labid" => $id])->first();
        $step2 = DB::table("lab_step2")->where(["labid" => $id])->first();
        $step3 = DB::table("lab_step3")->where(["labid" => $id])->first();
        if (!$data) {
            return redirect()->back();
        }
        $type = 1;

        $sp = DB::table("preferences")->where(["id" => $data->service_preferences])->first();
        return view("admin.lab.labprofile", compact("data", "step1", "step2", "step3", "type", "sp"));
    } catch (\Exception $e) {
        return redirect()->back()->with('status', $e->getMessage());
    }
    }

    public function disapprove_lab(Request $request)
    {
        try{
        $doctor = DB::table("laboratories")->where(["id" => $request->id])->update(["status" => 2, "reason_for_disapprove" => $request->reason]);
        $doc = DB::table("laboratories")->where(["id" => $request->id])->first();
        $this->sender($doc->name, $doc->email, $doc->phone, $request->reason, "disapprove", "Lab");
        return response()->json(["message" => "SuccessFully Disapproved!"]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public function approve_lab(Request $request)
    {
        try{
        $doctor = DB::table("laboratories")->where(["id" => $request->id])->update(["status" => 1]);
        $doc = DB::table("laboratories")->where(["id" => $request->id])->first();
        $this->sender($doc->name, $doc->email, $doc->phone, "", "approve", "Lab");
        return response()->json(["message" => "SuccessFully Approved!"]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public function phar_users()
    {
        try{
        $data = DB::table("pharmacy")->simplePaginate(10);
        return view("admin.pharmacy.users", compact("data"));
    } catch (\Exception $e) {
        return redirect()->back()->with('status', $e->getMessage());
    }

    }

    public function phar_user($id)
    {
        try{
        $data = DB::table("pharmacy")->where(["id" => $id])->first();
        $step1 = DB::table("p_step1")->where(["pid" => $id])->first();
        $step2 = DB::table("p_step2")->where(["pid" => $id])->first();
        $step3 = DB::table("p_step3")->where(["pid" => $id])->first();
        if (!$data) {
            return redirect()->back();
        }
        $type = 1;

        $sp = DB::table("preferences")->where(["id" => $data->service_preferences])->first();
        return view("admin.pharmacy.phaprofile", compact("data", "step1", "step2", "step3", "type", "sp"));
    } catch (\Exception $e) {
        return redirect()->back()->with('status', $e->getMessage());
    }
    }

    public function disapprove_phar(Request $request)
    {
        try{
        $doctor = DB::table("pharmacy")->where(["id" => $request->id])->update(["status" => 2, "reason_for_disapprove" => $request->reason]);
        $doc = DB::table("pharmacy")->where(["id" => $request->id])->first();
        $this->sender($doc->name, $doc->email, $doc->phone, $request->reason, "disapprove", "Pharmacy");
        return response()->json(["message" => "SuccessFully Disapproved!"]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public function approve_phar(Request $request)
    {
        try{
        $doctor = DB::table("pharmacy")->where(["id" => $request->id])->update(["status" => 1]);
        $doc = DB::table("pharmacy")->where(["id" => $request->id])->first();
        $this->sender($doc->name, $doc->email, $doc->phone, "", "approve", "Lab");
        return response()->json(["message" => "SuccessFully Approved!"]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public function indexhospital(Request $request)
    {
        try{
        $data = DB::table("hospital")->simplePaginate(10);
        return view("admin.hospital.main", compact("data"));
    } catch (\Exception $e) {
        return redirect()->back()->with('status', $e->getMessage());
    }
    }

    public function hospitaldash(Request $request)
    {
        try{
        $id = $request->id;
        $data = DB::table("hospital")->where(["id" => $id])->first();
        if (!$data) {
            return view("admin.error");
        } else {

            $type = 1;
            $step1 = DB::table("h_step1")->where(["hid" => $id])->first();
            $step2 = DB::table("h_step2")->where(["hid" => $id])->first();
            $step3 = DB::table("h_step3")->where(["hid" => $id])->first();
            $step4 = DB::table("h_step4")->where(["hid" => $id])->get();
            $type = $request->type;
            $bookings = DB::table("hospital_bookings")
                ->join("hospital_schedule", "hospital_schedule.id", "=", "hospital_bookings.schedule_id")
                ->join("hospital_service", "hospital_service.id", "=", "hospital_bookings.service_id")
                ->join("patient", "patient.id", "=", "hospital_bookings.userid")
                ->select("hospital_schedule.time", "hospital_schedule.day", "hospital_bookings.*", "hospital_service.service_name", "patient.first_name", "patient.last_name")
                ->where(["hospital_bookings.hid" => $id])->get();
            $services = DB::table("hospital_service")->where(["hid" => $id])->get();
            return view("admin.hospital.dash", compact("type", "data", "step1", "step2", "step3", "step4", "type", "id", "bookings", "services"));
        }
    } catch (\Exception $e) {
        return redirect()->back()->with('status', $e->getMessage());
    }
    }

    public function disapprove_hospital(Request $request)
    {
        try{
        $doctor = DB::table("hospital")->where(["id" => $request->id])->update(["status" => 2, "reason_for_disapprove" => $request->reason]);
        $data = DB::table("hospital")->where(["id" => $request->id])->first();
        $this->sender($data->first_name, $data->email, "", $request->reason, "disapprove", "Hospital");
        return response()->json(["message" => "SuccessFully Disapproved!"]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public function approve_hospital(Request $request)
    {
        try{
        $doctor = DB::table("hospital")->where(["id" => $request->id])->update(["status" => 1]);
        $data = DB::table("hospital")->where(["id" => $request->id])->first();
        $this->sender($data->first_name, $data->email, "", "", "approve", "Hospital");
        return response()->json(["message" => "SuccessFully Approved!"]);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public function list_of_banks(Request $request)
    {

        try{
        //https://api.paystack.co/bank
        $response = Http::get('https://api.paystack.co/bank');
        //return response()->json($response,200);
        return response()->json(json_decode($response->body()), 200);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public function resolve_bank(Request $request)
    {
        try{
        //https://api.paystack.co/bank
        $url = 'https://api.paystack.co/bank/resolve?account_number=' . $request->account_number . '&bank_code=' . $request->bank_code;
        $response = Http::withHeaders([
            'Authorization' => 'Bearer sk_test_52531adfdfd74ee21276c6f64b20e257cd6a631e',
        ])->get('https://api.paystack.co/bank/resolve?account_number=' . $request->account_number . '&bank_code=' . $request->bank_code);
        //return response()->json(['account_number'=>$request->account_number, 'bank_code'=>$request->bank_code, 'qw'=>$url],200);
        return response()->json(json_decode($response->body()), 200);
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

    public static function send_push_notif_to_topic($topic, $data, $web_push_link = null)
    {
        try{
        $url = "https://fcm.googleapis.com/fcm/send";
        $header = array(
            "authorization: key=AAAA4unw2EQ:APA91bGM5R6U7HTz096YExo_ktdW3zTFePeXtpvh88GWTT4rbFQvj49KQHmZpiq8-qmslwk_ZFysdeBnXRmdb3mSpo66wct6U2OA4zssEb8EUn6KCgYMUKJ0xn-rByFNy66FnaADu7Q5",
            "content-type: application/json",
        );
        $click_action = "";
        if ($web_push_link) {
            $click_action = ',
            "click_action": "' . $web_push_link . '"';
        }

        if (isset($data['order_id'])) {
            $postdata = '{
                "to" : "/topics/' . $topic . '",
                "mutable_content": true,
                "data" : {
                    "title":"' . $data['title'] . '",
                    "body" : "' . $data['description'] . '",
                    "is_read": 0,
                    "type":"' . $type . '"
                },
                "notification" : {
                    "title":"' . $data['title'] . '",
                    "body" : "' . $data['description'] . '",
                    "is_read": 0,
                    "icon" : "new",
                    "sound": "notification.wav",
                    "android_channel_id": "stackfood"
                    ' . $click_action . '
                  }
            }';
        } else {
            $postdata = '{
                "to" : "/topics/' . $topic . '",
                "mutable_content": true,
                "data" : {
                    "title":"' . $data['title'] . '",
                    "body" : "' . $data['description'] . '",
                    "token" : "' . $data['token'] . '",
                    "channel" : "' . $data['channel'] . '",
                    "type" :"' . $data['type'] . '",
                    "is_read": 0,
                },
                "notification" : {
                    "title":"' . $data['title'] . '",
                    "body" : "' . $data['description'] . '",
                    "is_read": 0,
                    "icon" : "new",
                    "sound": "notification.wav",
                    "android_channel_id": "stackfood"
                    ' . $click_action . '
                  }
            }';
        }

        $ch = curl_init();
        $timeout = 120;
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);

        // Get URL content
        $result = curl_exec($ch);
        // close handle to release resources
        curl_close($ch);

        return $result;
    } catch (\Exception $e) {
        Log::error('Error : ' . $e->getMessage());
        return response()->json(["message" => "Error Occurred, " . $e->getMessage()], 500);
    }
    }

}
