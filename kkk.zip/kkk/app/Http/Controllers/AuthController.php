<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Hash;
use App\Models\Patient;
use Mailer;
  use Twilio\Rest\Client;
  use DB;
class AuthController extends Controller
{
    public function register(Request $request){
        
        $fields=$request->validate([
            'first_name' => 'required|string',
            'other_name' => 'required|string',
            'last_name' => 'required|string',
            'email' => 'required',
            'phone_number' => 'required',
            'password' => 'required',
        ]);
        
        
 // Available alpha caracters
$characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

// generate a pin based on 2 * 7 digits + a random character
$pin = mt_rand(1, 9)
    . mt_rand(10, 99)
    . $characters[rand(0, strlen($characters) - 1)];

// shuffle the result
$email_verification_code =  rand(11111,99999);
  
 //validate
 $check1=Patient::where('email', $fields['email'])->first();
 $check2=Patient::where('phone_number', $fields['phone_number'])->first();

if($check1){
 return response()->json([
     'status'=> false,
     'message'=> 'Email already exists..'
 ],409);
}elseif($check2){
    return response()->json([
        'status'=> false,
        'message'=> 'Phone number already exists..'
    ],409);
}else{
            $user=Patient::create([
            'first_name' => $fields['first_name'],
            'other_name' => $fields['other_name'],
            'last_name' => $fields['last_name'],
            'email' => $fields['email'],
            'phone_number' => $fields['phone_number'],
            'password' => bcrypt($fields['password']),
             'email_verification_code' => $email_verification_code,
             "address"=>$request->address,
             "unique_id"=>rand()
            
        ]);

        $token=$user ->createToken('myapptoken')->plainTextToken;

        $response=[
            'message' => "User Registration Success",
            'email' => $user->email
        ];
        
  $phone =  $fields['phone_number'];
//       // Your Account SID and Auth Token from twilio.com/console
// $account_sid = 'ACa07d9dfe8d7018ff2d519f75dcb7df84';
// $auth_token = '98ad77cf03cbffdcd030173e84c8beb9';
// // In production, these should be environment variables. E.g.:
// // $auth_token = $_ENV["TWILIO_AUTH_TOKEN"]

// // A Twilio number you own with SMS capabilities
// $twilio_number = "+14043345663";

// $client = new Client($account_sid, $auth_token);
// $client->messages->create(
//     // Where to send a text message (your cell phone?)
//     "$phone",
//     array(
//         'from' => $twilio_number,
//         'body' => "OTP verification code from sonocare: $email_verification_code"
//     )
// );
 
   \Mail::send('mail', ["user"=>$user], function ($message) use($user,$request) {

        $message->to($user->email)->subject("Email Verification | SonoCare");
    });     
    
       \Mail::send('welcome', ["user"=>$user], function ($message) use($user,$request) {

        $message->to($user->email)->subject("Personal Welcome Message  from the CEO");
    });     
        
       if($request->refer != null){
           $d = DB::table("patient")->where(["phone_number"=>$request->refer])->first();
           if($d){
              DB::table("ref")->insert(["userid"=>$user->id,"refid"=>$d->id]);
           }
       }
    
 
    }
        return response($response,201);
    }

    public function login(Request $request){
        $fields=$request->validate([
            'email' => 'required|string',
            'password' => 'required|string',
        ]);

        $credentials = request(['email', 'password']);

        if (! $token = auth("api")->attempt($credentials)) {
            return response()->json(['error' => 'Invalid Login Details'], 401);
        }

$user = auth("api")->user();
if(auth("api")->user()->status == 0){
      $phone =   auth("api")->user()->phone_number;
       // Your Account SID and Auth Token from twilio.com/console
$account_sid = 'ACa07d9dfe8d7018ff2d519f75dcb7df84';
$auth_token = '98ad77cf03cbffdcd030173e84c8beb9';
// In production, these should be environment variables. E.g.:
// $auth_token = $_ENV["TWILIO_AUTH_TOKEN"]

// A Twilio number you own with SMS capabilities
//$twilio_number = "+14043345663";

//$client = new Client($account_sid, $auth_token);
//$client->messages->create(
    // Where to send a text message (your cell phone?)
//    "+234$phone",
//    array(
//        'from' => $twilio_number,
//        'body' => "OTP verification code from sonocare: $user->email_verification_code"
//    )
//);
 
   \Mail::send('mail', ["user"=>$user], function ($message) use($user,$request) {

        $message->to($user->email)->subject("Email Verification | SonoCare");
    });   
    
    return response()->json(["message"=>"User Not Verfied!","email"=>$request->email],400);
}
        return $this->respondWithToken($token);
      
    }
        protected function respondWithToken($token)
    {
        return response()->json([
            'access_token' => $token,
            'token_type' => 'bearer',
            'expires_in' => auth("api")->factory()->getTTL() * 60,
            'user'=>auth("api")->user()
        ]);
    }
    
    public function resetpass(Request $request){
        $email = $request->email;
        $check = DB::table("patient")->where(["email"=>$email])->first();
        if(!$check){
            return response()->json(["message"=>"Email Not Found!"],404);
        }
        $token = rand(1111,9999);
        
          // Your Account SID and Auth Token from twilio.com/console
$account_sid = 'ACa07d9dfe8d7018ff2d519f75dcb7df84';
$auth_token = '98ad77cf03cbffdcd030173e84c8beb9';
// In production, these should be environment variables. E.g.:
// $auth_token = $_ENV["TWILIO_AUTH_TOKEN"]

// A Twilio number you own with SMS capabilities
$twilio_number = "+14043345663";

$client = new Client($account_sid, $auth_token);
$client->messages->create(
    // Where to send a text message (your cell phone?)
    "$check->phone_number",
    array(
        'from' => $twilio_number,
        'body' => "OTP verification code from sonocare: $token"
    )
);

    
        DB::table("patient")->where(["email"=>$email])->update(["resettoken"=>$token]);
        
        
           \Mail::send('reset', ["user"=>$check,"resettoken"=>$token], function ($message) use($check,$request) {

        $message->to($check->email)->subject("Reset Password | SonoCare");
    });     
    
        return response()->json(["message"=>"Reset password OTP sent!"]);
    }
    
    public function setpass(Request $request){
        $otp = $request->otp;
        $email = $request->email;
        $password = $request->password;
        $data = DB::table("patient")->where(["email"=>$email,"resettoken"=>$otp])->first();
        if(!$data){
            return response()->json(["message"=>"Invalid OTP provided"],404);
        }
        DB::table("patient")->where(["email"=>$email])->update(["password"=>\Hash::make($password)]);
        return response()->json(["message"=>"Passowrd Reset Was SuccessFul"]);
    }

   
   
}
