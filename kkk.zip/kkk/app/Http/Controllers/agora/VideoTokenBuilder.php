
<?php
// namespace App\Http\Controllers\agora;

include("RtcTokenBuilderBase.php");

function get_Token($uid_param, $channel_param) {
        $appId = "cbfe053bc6c5442593628b1c359cb11c";
        $appCertificate = "fa4a9155d8514ac5967cb85476af603f";
        $channelName = $channel_param;//"7d72365eb983485397e3e3f9d460bdda";
        $uid = $uid_param;//2882341274;
        $tokenExpirationInSeconds = 3600;
        $privilegeExpirationInSeconds = 3600;

        $token = RtcTokenBuilder2::buildTokenWithUid($appId, $appCertificate, $channelName, $uid, RtcTokenBuilder2::ROLE_PUBLISHER, $tokenExpirationInSeconds, $privilegeExpirationInSeconds);
        return $token . PHP_EOL;
    }
// class VideoTokenBuilder {


//   }

/*

$appId = "cbfe053bc6c5442593628b1c359cb11c";
$appCertificate = "fa4a9155d8514ac5967cb85476af603f";
$channelName = "7d72365eb983485397e3e3f9d460bdda";
//$uid = 2882341273;
$uid = 2882341274;
//$uidStr = "2882341273";
$uidStr = "2882341274";
$tokenExpirationInSeconds = 3600;
$privilegeExpirationInSeconds = 3600;

$token = RtcTokenBuilder2::buildTokenWithUid($appId, $appCertificate, $channelName, $uid, RtcTokenBuilder2::ROLE_PUBLISHER, $tokenExpirationInSeconds, $privilegeExpirationInSeconds);
echo 'Token with int uid: ' . $token . PHP_EOL;
*/


/*
$token = RtcTokenBuilder2::buildTokenWithUserAccount($appId, $appCertificate, $channelName, $uidStr, RtcTokenBuilder2::ROLE_PUBLISHER, $tokenExpirationInSeconds, $privilegeExpirationInSeconds);
echo 'Token with user account: ' . $token . PHP_EOL;

$token = RtcTokenBuilder2::buildTokenWithUidAndPrivilege($appId, $appCertificate, $channelName, $uid, $privilegeExpirationInSeconds, $privilegeExpirationInSeconds, $privilegeExpirationInSeconds, $privilegeExpirationInSeconds, $privilegeExpirationInSeconds);
echo 'Token with int uid and privilege: ' . $token . PHP_EOL;

$token = RtcTokenBuilder2::buildTokenWithUserAccountAndPrivilege($appId, $appCertificate, $channelName, $uidStr, $privilegeExpirationInSeconds, $privilegeExpirationInSeconds, $privilegeExpirationInSeconds, $privilegeExpirationInSeconds, $privilegeExpirationInSeconds);
echo 'Token with user account and privilege: ' . $token . PHP_EOL;
*/
