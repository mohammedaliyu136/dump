<?php

include("RtcTokenBuilder.php");

$tokenGenerator = new VideoTokenBuilder();
echo $tokenGenerator->get_Token(2882341273, "7d72365eb983485397e3e3f9d460bdda");
  
?>