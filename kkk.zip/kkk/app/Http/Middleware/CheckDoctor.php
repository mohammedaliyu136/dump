<?php
namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class CheckDoctor
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        // Check if doctor is authenticated
        if (!auth("doctor")->check()) {
            return response()->json(["message" => "Unauthorized User"], 401);
        }

        $doctor = auth("doctor")->user();

        // Check doctor verification status
        if ($doctor->status == 0) {
            return response()->json(["message" => "Doctor Not Verified!"], 400);
        }

        if ($doctor->status == 2) {
            return response()->json(["message" => "Account Has Been Disapproved!", "reason" => $doctor->reason_for_disapprove], 400);
        }

        return $next($request);
    }
}
