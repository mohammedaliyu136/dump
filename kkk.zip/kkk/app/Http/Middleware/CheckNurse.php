<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class CheckNurse
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        
             if(auth("nurse")->user()->status == 0){
    return response()->json(["message"=>"Nurse Not Verified!"]);
}

if(auth("nurse")->user()->status == 2){
    return response()->json(["message"=>"Account Have Been Disapproved!","reason"=>auth("nurse")->user()->reason_for_disapprove],400);
}
        return $next($request);
    }
}
