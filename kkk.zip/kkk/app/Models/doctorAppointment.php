<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\Patient as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;


class doctorAppointment extends Model
{
    use HasFactory, Notifiable, HasApiTokens;
    protected $table='doctors_appointment';
    protected $fillable = [
        'patient_id',
        'doctor_id',
        'consultation_id',
        'time',
        'appintment_date',
        'status',
    ];
}
