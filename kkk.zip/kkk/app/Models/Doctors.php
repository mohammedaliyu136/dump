<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Tymon\JWTAuth\Contracts\JWTSubject;

class Doctors extends Authenticatable implements JWTSubject
{
    use HasFactory, Notifiable, HasApiTokens;
    protected $table = 'doctors';

    public function getJWTIdentifier()
    {
        return $this->getKey();
    }

    /**
     * Return a key value array, containing any custom claims to be added to the JWT.
     *
     * @return array
     */
    public function getJWTCustomClaims()
    {
        return [];
    }
    protected $fillable = [
        'first_name',
        'other_name',
        'last_name',
        'email',
        'phone_number',
        'address',
        'state_id',
        'lga_id',
        'language',
        'hieght',
        'genotype',
        'blood_group',
        'family_member_contact',
        'email_verification_code',
        'phone_number_verification_code',
        'email_verification_status',
        'phone_number_verification_status',
        'password',
        'doctor_type',
        'status',
        'gender',
        'language',
        'mcdn_number',
        'speciality_code',
        'other_language',
        'picture',
        'campany_organisation',
        'working_from',
        'working_to',
        'service_fee',
        'country',
        'refered_by',
        'degree_cert',
        'medical_licence',
        'backing_inform',
        'about_me',
    ];
}
