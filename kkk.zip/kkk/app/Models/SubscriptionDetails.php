<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\Doctors as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class SubscriptionDetails extends Model
{
    use HasFactory, Notifiable, HasApiTokens;
    protected $table='subscription_plan_description';
    protected $fillable = [
        'title',
    ];
}
