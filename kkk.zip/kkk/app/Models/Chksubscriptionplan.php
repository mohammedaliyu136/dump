<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\Doctors as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class Chksubscriptionplan extends Model
{
    use HasFactory, Notifiable, HasApiTokens;
    protected $table='patient_subscription';
    protected $fillable = [
        'patient_id',
        'subscription_id',
        'start_month',
        'end_month'
    ];
}
