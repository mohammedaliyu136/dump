<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\Doctors as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class VitalSign extends Model
{
    use HasFactory, Notifiable, HasApiTokens;
    protected $table='VitalSign';
    protected $fillable = [
        'patient_id',
        'nurse_id',
        'consultation_id',
        'blood_group',
        'temprature',
        'pulse_rate',
        'respiration',
        'sp02',
        'latitude',
        'longitude',
        'body_mass'
    ];
}
