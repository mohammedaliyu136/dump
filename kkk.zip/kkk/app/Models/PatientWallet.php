<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\Patient as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;


class PatientWallet extends Model
{
    use HasFactory, Notifiable, HasApiTokens;
    protected $table='patient_wallet';
    protected $fillable = [
        'patient_id',
        'transaction_amount',
        'wallat_balance',
        'transaction_for',
        
    ];
}
