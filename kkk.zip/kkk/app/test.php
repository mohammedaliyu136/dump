<?php

namespace App;

enum test
{
    //
}
