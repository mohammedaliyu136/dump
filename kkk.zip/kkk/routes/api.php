<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\AmbulanceController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CallController;
use App\Http\Controllers\DoctorsController;
use App\Http\Controllers\Hospital;
use App\Http\Controllers\LabController;
use App\Http\Controllers\LogisticController;
use App\Http\Controllers\NursesController;
use App\Http\Controllers\PharmacyController;
use App\Http\Controllers\userAppController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

// Route::get('/user', function (Request $request) {
//     return $request->user();
// })->middleware('auth:sanctum']);

Route::get("/rand", function () {
    $user = DB::table("patient")->get();
    foreach ($user as $u) {
        DB::table("patient")->where(["id" => $u->id])->update(["unique_id" => rand()]);
    }
});

//---------------call start
Route::post('/call', [CallController::class, 'makeCall']);
//---------------end call

Route::post('/doctor/listtt', [DoctorsController::class, 'get_doctors_list']);

Route::get('/am_list', [AmbulanceController::class, 'am_list']);
Route::get('/pharmacys', [PharmacyController::class, 'pharmacys']);
Route::get('/logistics', [LogisticController::class, 'logistics']);
Route::get('/logistics/reviews', [LogisticController::class, 'reviews']);
Route::get('/logistics/transactions', [LogisticController::class, 'transaction_history']);
Route::post('/get_products', [PharmacyController::class, 'get_products']);

Route::get('/products', [userAppController::class, 'products']);
Route::post('/products_search', [userAppController::class, 'products_search']);
Route::get('/services', [userAppController::class, 'services']);
Route::get('/pharmacyList', [userAppController::class, 'pharmacyList']);
Route::post('/pharmacyProducts', [userAppController::class, 'pharmacyProducts']);

Route::post('/register', [AuthController::class, 'register']);
Route::post('/login', [AuthController::class, 'login']);

Route::post('/patient/resetpass', [AuthController::class, 'resetpass']);
Route::post('/patient/setpass', [AuthController::class, 'setpass']);
Route::post('/patient/new_order', [userAppController::class, 'new_order_product']);
Route::post('/patient/book_hospital', [userAppController::class, 'book_hospital']);
Route::get('/patient/hospital_bookings', [userAppController::class, 'hospital_bookings']);
Route::post('/patient/hospital_booking_data', [userAppController::class, 'hospital_booking_data']);
Route::get('/patient/orders', [userAppController::class, 'orders']);

Route::get('/patient/getAnswers', [userAppController::class, 'getAnswers']);

//logistic
Route::post('/patient/get_logistic_price', [userAppController::class, 'get_logistic_price']);
Route::post('/patient/new_pickup', [userAppController::class, 'new_pickup']);
Route::get('/patient/my_pickup', [userAppController::class, 'my_pickup']);

//ambulance

Route::post('/patient/get_am_price', [userAppController::class, 'get_am_price']);
Route::post('/patient/new_ambulance', [userAppController::class, 'new_ambulance']);
Route::get('/patient/my_am_requests', [userAppController::class, 'my_am_requests']);
Route::post('/hospital_services', [userAppController::class, 'hospital_services']);
Route::get('/hospitals', [userAppController::class, 'hospitals']);
Route::get('/hospital_dates', [userAppController::class, 'hospital_dates']);
Route::post('/h_getSchedule', [userAppController::class, 'h_getSchedule']);

Route::get('/patientProfile', [userAppController::class, 'getPatientProfile']);
Route::post('/ratedoctor', [userAppController::class, 'ratedoctor']);
Route::post('/getdoctorrating', [userAppController::class, 'getdoctorrating']);
Route::post('/patientsearch', [userAppController::class, 'patientsearch']);
Route::post('/addnursereview', [userAppController::class, 'addnursereview']);
Route::post('/adddocreview', [userAppController::class, 'adddocreview']);
Route::post('/addpharreview', [userAppController::class, 'addpharreview']);
Route::post('/updateProfile', [userAppController::class, 'updateProfile']);
Route::post('/addlabreview', [userAppController::class, 'addlabreview']);
Route::post('/addamreview', [userAppController::class, 'addamreview']);
Route::post('/verifyemail', [userAppController::class, 'verifyemail']);
Route::post('/patientupdateimage', [userAppController::class, 'patientupdateimage']);
Route::post('/sendVitalSignRequest', [userAppController::class, 'sendVitalSignRequest']);
Route::post('/getdocconsultationFee', [userAppController::class, 'getConsultationFee']);
Route::post('/booklab', [LabController::class, 'booklab']);
Route::get('/mybookings', [LabController::class, 'mybookings']);
Route::get('/refers', [userAppController::class, 'refers']);
Route::post('/getVitalSign', [userAppController::class, 'getVitalSign']);
Route::get('/chkPatientWalletBalance', [userAppController::class, 'chkPatientWalletBalance']);
Route::post('/fundwallet', [userAppController::class, 'fundwallet']);
Route::post('/createEncounter', [userAppController::class, 'createEncounter']);
Route::get('/questions', [userAppController::class, 'questions']);
Route::post('/answers', [userAppController::class, 'answer']);

Route::get('/getAllConsultation', [userAppController::class, 'getAllConsultation']);
Route::get('/getConsultationById', [userAppController::class, 'getConsultationById']);
Route::get('/getAllSubscriptionPlan', [userAppController::class, 'getAllSubscriptionPlan']);
Route::post('/subcribe_medical', [userAppController::class, 'subcribe_medical']);
Route::post('/getdoctorap', [userAppController::class, 'getdoctorap']);
Route::post('/getdoctor-schedule', [userAppController::class, 'getDoctorSchedule']);
Route::get('/getSubscriptionPlanDetails', [userAppController::class, 'getSubscriptionPlanDetails']);

Route::get('/viewWalletHistory', [userAppController::class, 'viewWalletHistory']);
Route::get('/chkSubscriptionPlan', [userAppController::class, 'chkSubscriptionPlan']);

Route::post('/bookAppointmentWithDoctor', [userAppController::class, 'bookAppointmentWithDoctor']);
Route::get('/GetAllAppointment', [userAppController::class, 'GetAllAppointment']);
Route::get('/nurse_type', [NursesController::class, 'nurse_type']);
Route::post('/update_fcm', [NursesController::class, 'update_fcm']);
Route::post('/nurse_withdrawal', [NursesController::class, 'withdrawal']);
Route::post('/nuseupdateimage', [NursesController::class, 'nuseupdateimage']);
Route::get('/preferences', [NursesController::class, 'preferences']);
Route::get('/get_nurse_service_fee', [NursesController::class, 'get_nurse_service_fee']);
Route::post('/set_nurse_service_fee', [NursesController::class, 'set_nurse_service_fee']);

Route::post('/nurse/resetpass', [NursesController::class, 'resetpass']);
Route::post('/nurse/setpass', [NursesController::class, 'setpass']);

Route::group(['middleware' => ['auth:sanctum']], function () {
    Route::get('/doctors', [doctorsController::class, 'index']);
    Route::post('/logout', [AuthController::class, 'logout']);
});

//nurses
Route::post('/nurseRegistration', [NursesController::class, 'register']);
Route::post('/nurselogin', [NursesController::class, 'nurselogin']);
Route::post('/nurseverification', [NursesController::class, 'verification']);
Route::post('/getNurseNearby', [NursesController::class, 'getNurseNearby']);
Route::get('/nurse_services', [NursesController::class, 'nurse_services']);
Route::post('/step1verification', [NursesController::class, 'step1verification']);
Route::post('/step2verification', [NursesController::class, 'step2verification']);
Route::post('/step3verification', [NursesController::class, 'step3verification']);
Route::post('/step4verification', [NursesController::class, 'step4verification']);
Route::post('/nursesetfee', [NursesController::class, 'setfee']);
Route::get('/getAllNurses', [NursesController::class, 'getAllNurses']);
Route::get('/nurse_reviews', [NursesController::class, 'reviews']);
Route::middleware('nurseauth')->group( function () {
    Route::get('/getNurseProfile', [NursesController::class, 'getNurseProfile']);
    Route::post('/updateNurseProfile', [NursesController::class, 'updateNurseProfile']);
    Route::post('/updateVitalSign', [NursesController::class, 'updateVitalSign']);
    Route::post('/createVitalSign', [NursesController::class, 'createVitalSign']);
    Route::post('/getnursevital', [NursesController::class, 'getnursevital']);
    Route::post('/getpatientvital', [NursesController::class, 'getPatientvital']);
    Route::post('/update_account', [NursesController::class, 'update_account']);
    Route::post('/acceptVitalsignRequest', [NursesController::class, 'acceptVitalsignRequest']);
    Route::post('/complete_VitalsignRequest', [NursesController::class, 'complete_VitalsignRequest']);
    Route::get('/nurse/transactions', [NursesController::class, 'transactions']);

    Route::post('/nurse/accept_pickup', [NursesController::class, 'accept_pickup']);
    Route::post('/nurse/complete_pickup', [NursesController::class, 'complete_pickup']);
    Route::post('/nurse/cancel_pickup', [NursesController::class, 'cancel_pickup']);
    Route::get('/nurse/my_pickup', [NursesController::class, 'my_pickup']);
});

//Doctors
Route::post('/DoctorRegistration', [DoctorsController::class, 'DoctorRegistration']);
Route::post('/doc_answer', [DoctorsController::class, 'answer']);
Route::get('/doc_answers', [DoctorsController::class, 'answers']);
Route::post('/doc_withdrawal', [DoctorsController::class, 'withdrawal']);
Route::post('/update_doctor_account', [DoctorsController::class, 'update_account']);
Route::get('/dates', [DoctorsController::class, 'dates']);
Route::get('/docreviews', [DoctorsController::class, 'docreviews']);
Route::post('/doctor_update_fcm', [DoctorsController::class, 'update_fcm']);
Route::post('/doctorlogin', [DoctorsController::class, 'doctorlogin']);
Route::post('/verifyAccount', [DoctorsController::class, 'verifyAccount']);
Route::get('/getDoctorbyRating', [DoctorsController::class, 'getDoctorbyRating']);
Route::get('/getAllDoctors', [DoctorsController::class, 'getAllDoctors']);
Route::post('/dgetPatientProfile', [DoctorsController::class, 'dgetPatientProfile']);
Route::post('/dstep1verification', [DoctorsController::class, 'step1verification']);
Route::post('/dstep2verification', [DoctorsController::class, 'step2verification']);
Route::post('/dstep3verification', [DoctorsController::class, 'step3verification']);
Route::post('/dstep4verification', [DoctorsController::class, 'step4verification']);
Route::post('/doctorsearch', [DoctorsController::class, 'doctorsearch']);
Route::get('/doctransactions', [DoctorsController::class, 'transaction']);
Route::post('/doctor/resetpass', [DoctorsController::class, 'resetpass']);
Route::post('/doctor/setpass', [DoctorsController::class, 'setpass']);

Route::post('/doctorverifyemail', [DoctorsController::class, 'doctorverifyemail']);
Route::get('/getAllGeneralDoctors', [DoctorsController::class, 'getAllGeneralDoctors']);
Route::get('/getAllSpecialistDoctors', [DoctorsController::class, 'getAllSpecialistDoctors']);
Route::get('/doctor_type', [DoctorsController::class, 'doctor_type']);
Route::middleware(['doctorauth'])->group( function () {
    Route::get('/getDoctorProfile', [DoctorsController::class, 'getDoctorProfile']);
    Route::post('/updateDoctorProfile', [DoctorsController::class, 'updateDoctorProfile']);
    Route::post('/setConsultationFee', [DoctorsController::class, 'setConsultationFee']);
    Route::post('/getPatientProfile', [DoctorsController::class, 'getPatientProfile']);
    Route::get('/getAlAppointments', [DoctorsController::class, 'getAlAppointments']);
    Route::post('/AcceptAppointmentment', [DoctorsController::class, 'AcceptAppointmentment']);
    Route::post('/AppointmentDetails', [DoctorsController::class, 'AppointmentDetails']);
    Route::post('/DeclineAppointmentment', [DoctorsController::class, 'DeclineAppointmentment']);
    Route::post('/closeDoctorAppointment', [DoctorsController::class, 'closeAppointmentment']);
    Route::get('/getConsultationFee', [DoctorsController::class, 'getConsultationFee']);
    Route::post('/updateConsultationFee', [DoctorsController::class, 'updateConsultationFee']);
    Route::post('/deleteConsultationFee', [DoctorsController::class, 'deleteConsultationFee']);
    Route::post('/setSchedule', [DoctorsController::class, 'setSchedule']);
    Route::post('/getSchedule', [DoctorsController::class, 'getSchedule']);
    // Route::post('/updateSchedule',[DoctorsController::class,'updateSchedule']);
    Route::post('/deleteSchedule', [DoctorsController::class, 'deleteSchedule']);
    Route::post('/prescription', [DoctorsController::class, 'prescription']);
    Route::post('/getAppointmentID', [DoctorsController::class, 'getAppointmentID']);
    Route::post('/setSchedule', [DoctorsController::class, 'setSchedule']);
    Route::post('/updateschedule', [DoctorsController::class, 'updateschedule']);
    Route::post('/get_agora_token', [DoctorsController::class, 'get_agora_token']);

    Route::get('/doctor/transactions', [DoctorsController::class, 'transaction']);
    Route::get('/get_preferences', [DoctorsController::class, 'get_preferences']);
    Route::post('/set_service_preferences', [DoctorsController::class, 'set_service_preferences']);
    Route::post('/withdrawal', [DoctorsController::class, 'withdrawal']);

});
//general getAllState
Route::post('/get_agora_tokennn', [DoctorsController::class, 'get_agora_token']);
Route::post('/get_agora_token_2', [DoctorsController::class, 'get_agora_tokennn']);
//get_agora_tokennn

Route::get('/getAllState', [DoctorsController::class, 'getAllState']);
Route::post('/getLGAByStateID', [DoctorsController::class, 'getLGAByStateID']);
Route::post('/doctorupdateimage', [DoctorsController::class, 'doctorupdateimage']);

Route::prefix('logistic')->group(function () {
    Route::post('/register', [LogisticController::class, 'register']);
    Route::post('/verify', [LogisticController::class, 'verify']);
    Route::post('/login', [LogisticController::class, 'login']);
    Route::get('/me', [LogisticController::class, 'me']);
    Route::post('/profile/update', [LogisticController::class, 'updateprofile']);
    Route::post('/resend_otp', [LogisticController::class, 'resend_otp']);
    Route::post('/update_fcm', [LogisticController::class, 'update_fcm']);
    Route::post('/update_address', [LogisticController::class, 'update_address']);
    Route::post('/add_price_km', [LogisticController::class, 'add_price_km']);
    Route::get('/all_km', [LogisticController::class, 'all_km']);
    Route::post('/accept_pickup', [LogisticController::class, 'accept_pickup']);
    Route::post('/complete_pickup', [LogisticController::class, 'complete_pickup']);
    Route::post('/cancel_pickup', [LogisticController::class, 'cancel_pickup']);
    Route::get('/my_pickup', [LogisticController::class, 'my_pickup']);
    Route::post('/step1verification', [LogisticController::class, 'step1verification']);
    Route::post('/step2verification', [LogisticController::class, 'step2verification']);

    Route::post('/update_account', [LogisticController::class, 'update_account']);
    Route::get('/preference', [LogisticController::class, 'preference']);

    Route::get('/get_preferences', [LogisticController::class, 'get_preferences']);

    Route::post('/set_service_preferences', [LogisticController::class, 'set_service_preferences']);

    Route::post('/withdrawal', [LogisticController::class, 'withdrawal']);

});

Route::prefix('ambulance')->group(function () {
    Route::post('/register', [AmbulanceController::class, 'register']);
    Route::post('/verify', [AmbulanceController::class, 'verify']);
    Route::post('/login', [AmbulanceController::class, 'login']);
    Route::get('/me', [AmbulanceController::class, 'me']);
    Route::post('/profile/update', [AmbulanceController::class, 'updateprofile']);
    Route::post('/resend_otp', [AmbulanceController::class, 'resend_otp']);

    Route::post('/step1verification', [AmbulanceController::class, 'step1verification']);
    Route::post('/step2verification', [AmbulanceController::class, 'step2verification']);
    Route::post('/step3verification', [AmbulanceController::class, 'step3verification']);
    Route::post('/step4verification', [AmbulanceController::class, 'step4verification']);
    Route::post('/update_fcm', [AmbulanceController::class, 'update_fcm']);
    Route::get('/reviews', [AmbulanceController::class, 'am_reviews']);
    Route::post('/update_address', [AmbulanceController::class, 'update_address']);
    Route::post('/request/accept', [AmbulanceController::class, 'accept_request']);
    Route::post('/request/cancel', [AmbulanceController::class, 'cancel_request']);
    Route::post('/complete_request', [AmbulanceController::class, 'complete_request']);
    Route::get('/my_requests', [AmbulanceController::class, 'my_requests']);

    Route::post('/update_account', [AmbulanceController::class, 'update_account']);
    Route::get('/preference', [App\Http\Controllers\AmbulanceController::class, 'preference']);

    Route::get('/transactions', [AmbulanceController::class, 'transaction_history']);

    Route::get('/get_preferences', [AmbulanceController::class, 'get_preferences']);

    Route::post('/set_service_preferences', [AmbulanceController::class, 'set_service_preferences']);

    Route::post('/withdrawal', [AmbulanceController::class, 'withdrawal']);

});

Route::prefix('lab')->group(function () {
    Route::post('/register', [LabController::class, 'register']);
    Route::post('/update_address', [LabController::class, 'update_address']);
    Route::post('/verification', [LabController::class, 'verification']);
    Route::post('/login', [LabController::class, 'login']);
    Route::post('/step1', [LabController::class, 'step1']);
    Route::post('/step2', [LabController::class, 'step2']);
    Route::post('/step3', [LabController::class, 'step3']);
    Route::post('/step4', [LabController::class, 'step4']);
    Route::get('/labcategory', [LabController::class, 'labcategory']);
    Route::post('/labsub_cat', [LabController::class, 'labsub_cat']);
    Route::post('/setlabfee', [LabController::class, 'setlabfee']);
    Route::post('/labsub_cat_labfee', [LabController::class, 'labsub_cat_lab']);
    Route::post('/search', [LabController::class, 'search']);
    Route::post('/labfee', [LabController::class, 'labfee']);
    Route::get('/mybookings', [LabController::class, 'mybookings2']);
    Route::get('/transactions', [LabController::class, 'transactions']);
    Route::post('/addreport', [LabController::class, 'addreport']);
    Route::get('/reports', [LabController::class, 'reports']);
    Route::post('/completed_report', [LabController::class, 'completed_report']);
    Route::post('/booking-details', [LabController::class, 'booking_details']);
    Route::post('/accept', [LabController::class, 'accept']);
    Route::post('/decline', [LabController::class, 'decline']);
    Route::get('/user', [LabController::class, 'me']);
    Route::post('/resend_otp', [LabController::class, 'resend_otp']);
    Route::post('/profile/update', [LabController::class, 'updateprofile']);
    Route::get('/reviews', [LabController::class, 'lab_reviews']);

    Route::post('/withdrawal', [LabController::class, 'withdrawal']);
    Route::post('/update_account', [LabController::class, 'update_account']);

    Route::get('/get_preferences', [LabController::class, 'get_preferences']);

    Route::post('/set_service_preferences', [LabController::class, 'set_service_preferences']);
});

Route::prefix('pharmacy')->group(function () {
    Route::post('/register', [PharmacyController::class, 'register']);
    Route::post('/profile/update', [PharmacyController::class, 'updateprofile']);
    Route::post('/update_address', [PharmacyController::class, 'update_address']);
    Route::post('/product/delete', [PharmacyController::class, 'deleteproduct']);
    Route::post('/verification', [PharmacyController::class, 'verification']);
    Route::post('/login', [PharmacyController::class, 'login']);
    Route::post('/step1', [PharmacyController::class, 'step1']);
    Route::post('/step2', [PharmacyController::class, 'step2']);
    Route::post('/step3', [PharmacyController::class, 'step3']);
    Route::post('/step4', [PharmacyController::class, 'step4']);
    Route::get('/user', [PharmacyController::class, 'user']);
    Route::post('/create_product', [PharmacyController::class, 'create_product']);
    Route::get('/products', [PharmacyController::class, 'products']);
    Route::post('/updateproduct', [PharmacyController::class, 'updateproduct']);
    Route::post('/search', [PharmacyController::class, 'search']);
    Route::post('/resend_otp', [PharmacyController::class, 'resend_otp']);
    Route::post('/update_fcm', [PharmacyController::class, 'update_fcm']);
    Route::get('/phar_review', [PharmacyController::class, 'phar_reviews']);
    Route::get('/orders', [PharmacyController::class, 'orders']);
    Route::post('/accept/order', [PharmacyController::class, 'accept_order']);
    Route::post('/cancel/order', [PharmacyController::class, 'cancel_order']);
    Route::post('/order/details', [PharmacyController::class, 'order_detail']);
    Route::post('/add_price_km', [PharmacyController::class, 'add_price_km']);
    Route::post('/confirmOrderHandover', [PharmacyController::class, 'confirmOrderHandover']);
    Route::get('/all_km', [PharmacyController::class, 'all_km']);
    Route::get('/reviews', [PharmacyController::class, 'reviews']);
    Route::get('/transactions', [PharmacyController::class, 'transaction_history']);
    Route::post('/update_account', [PharmacyController::class, 'update_account']);

    Route::get('/preferences', [PharmacyController::class, 'preferences']);

    Route::get('/get_preferences', [PharmacyController::class, 'get_preferences']);

    Route::post('/set_service_preferences', [PharmacyController::class, 'set_service_preferences']);

    Route::post('/withdrawal', [PharmacyController::class, 'withdrawal']);

});

Route::prefix('hospital')->group(function () {
    Route::post('/register', [Hospital::class, 'register']);
    Route::post('/profile/update', [Hospital::class, 'updateprofile']);
    Route::post('/verify', [Hospital::class, 'verify']);
    Route::post('/login', [Hospital::class, 'login']);
    Route::get('/bookings', [Hospital::class, 'bookings']);
    Route::post('/bookings/detail', [Hospital::class, 'bookingDetail']);
    Route::post('/view_booking', [Hospital::class, 'view_booking']);
    Route::post('/request/accept', [Hospital::class, 'accept']);
    Route::post('/request/cancel', [Hospital::class, 'decline']);
    Route::post('/request/close', [Hospital::class, 'close_booking']);
    Route::post('/complete', [Hospital::class, 'complete']);
    Route::post('/step1verification', [Hospital::class, 'step1verification']);
    Route::post('/step2verification', [Hospital::class, 'step2verification']);
    Route::post('/step3verification', [Hospital::class, 'step3verification']);
    Route::post('/step4verification', [Hospital::class, 'step4verification']);
    Route::get('/user', [Hospital::class, 'user']);
    Route::post('/update_account', [Hospital::class, 'update_account']);

    Route::post('/resend_otp', [Hospital::class, 'resend_otp']);
    Route::post('/update_fcm', [Hospital::class, 'update_fcm']);
    Route::get('/services', [Hospital::class, 'services']);
    Route::post('/add_service', [Hospital::class, 'add_service']);
    Route::post('/edit_service', [Hospital::class, 'edit_service']);
    Route::post('/delete_service', [Hospital::class, 'delete_service']);

    Route::post('/setSchedule', [Hospital::class, 'setSchedule']);
    Route::post('/getSchedule', [Hospital::class, 'getSchedule']);
    Route::post('/updateSchedule', [Hospital::class, 'updateSchedule']);
    Route::get('/dates', [Hospital::class, 'dates']);
    Route::get('/schedules', [Hospital::class, 'schedules']);
    Route::post('/deleteSchedule', [Hospital::class, 'deleteSchedule']);
    Route::get('/reviews', [Hospital::class, 'reviews']);
    Route::get('/transactions', [Hospital::class, 'transaction_history']);
    Route::get('/review', [Hospital::class, 'hospital_review']);
    Route::post('/hospital_withdrawal', [Hospital::class, 'withdrawal']);

    Route::get('/get_preferences', [Hospital::class, 'get_preferences']);

    Route::post('/set_service_preferences', [Hospital::class, 'set_service_preferences']);

});

//list_of_banks
Route::prefix('admin')->group(function () { //resolve_bank
    Route::get('/list/banks', [AdminController::class, 'list_of_banks']);
    Route::get('/resolve/banks', [AdminController::class, 'resolve_bank']);
});
Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::fallback(function () {
    return response()->json(["message" => "Invalid route"], 404);

});
