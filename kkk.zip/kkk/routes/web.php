<?php

use App\Http\Controllers\AdminController;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
 */

Route::get('/app/testing', [AdminController::class, 'apptesting']);

Route::get('/app/testing/book/doctor', [AdminController::class, 'testBookDoctor']);

Route::get('/app/testing/book/nurse', [AdminController::class, 'testBookNurse']);

Route::get('/dd', function () {

    Mail::raw([], function ($message) {
        $message->from('info@sonocare.com', 'Company name');
        $message->to('allphonesblog@gmail.com');
        $message->subject('5% off all our website');
        $message->setBody('<html><h1>5% off its awesome</h1><p>Go get it now !</p></html>', 'text/html');
        $message->addPart("5% off its awesome\n\nGo get it now!", 'text/plain');
    });
    return;
    $d = DB::table("doctors")->get();
    foreach ($d as $dd) {
        $date = rand(1, 3);
        $dx = rand(0, 23);
        $time = $dx . ":" . str_pad(rand(0, 59), 2, "0", STR_PAD_LEFT);
        if ($time < "12") {
            $type = "AM";
            $day = "morning";
        } else
        /* If the time is grater than or equal to 1200 hours, but less than 1700 hours, so good afternoon */
        if ($time >= "12" && $time < "17") {
            $type = "PM";
            $day = "afternoon";
        } else
        /* Should the time be between or equal to 1700 and 1900 hours, show good evening */
        if ($time >= "17" && $time < "19") {
            $day = "evening";
            $type = "PM";
        } else {
            $type = "PM";
            $day = "evening";
        }
        $time = $time . "$type";
        DB::table("doctor_schedule")->insert(["doctor_id" => $dd->id, "time" => $time, "day" => $day, "date" => $date]);
    }
});

Route::get('/', [AdminController::class, 'login'])->name('login');
Route::post('/admin/login', [AdminController::class, 'plogin']);
Route::get('/admin/logout', [AdminController::class, 'logout']);

Route::prefix('/admin')->middleware('auth')->group(function () {
    Route::get('/dashboard', [AdminController::class, 'dash'])->name('dashboard');
    Route::post('/setmode', [AdminController::class, 'setmode']);
    Route::get('/doctors', [AdminController::class, 'doctors']);
    Route::get('/patients', [AdminController::class, 'patients']);
    Route::get('/nurses', [AdminController::class, 'nurses']);
    Route::get('/questions', [AdminController::class, 'questions']);
    Route::get('/doctorprofile/{id}', [AdminController::class, 'doctorprofile']);
    Route::get('/nurseprofile/{id}', [AdminController::class, 'nurseprofile']);
    Route::get('/patientprofile/{id}', [AdminController::class, 'patientprofile'])->middleware('auth');
    Route::prefix('doctor')->group(function () {
        Route::post('/disapprove', [AdminController::class, 'disapprove_doctor']);
        Route::post('/approve', [AdminController::class, 'approve_doctor']);
        Route::get('/services/{id}', [AdminController::class, 'services']);
        Route::get('/appointments/{id}', [AdminController::class, 'appointments']);
    });

    Route::prefix('nurse')->group(function () {
        Route::post('/disapprove', [AdminController::class, 'disapprove_nurse']);
        Route::post('/approve', [AdminController::class, 'approve_nurse']);
        Route::get('/vitalsigns/{id}', [AdminController::class, 'vitalsigns']);
        Route::get('/transaction/{id}', [AdminController::class, 'trans']);

        Route::prefix('service')->group(function () {
            Route::get('/vitalsign', [AdminController::class, 'vitaldata']);
        });

    });

    Route::prefix('patient')->group(function () {
        Route::get('/vitalsigns/{id}', [AdminController::class, 'pvitalsigns']);
        Route::get('/transaction/{id}', [AdminController::class, 'ptrans']);
        Route::get('/appointments/{id}', [AdminController::class, 'pappointments']);
    });

    Route::prefix('logistic')->group(function () {
        Route::get('/', [AdminController::class, 'indexlogistic']);
        Route::get('/dash/{id}', [AdminController::class, 'logisticdash']);
        Route::get('/transaction/{id}', [AdminController::class, 'logistic_transaction']);
        Route::post('/disapprove', [AdminController::class, 'disapprove_logistic']);
        Route::post('/approve', [AdminController::class, 'approve_logistic']);
        // Route::get('/appointments/{id}', [AdminController::class, 'pappointments']);
    });

    Route::prefix('ambulance')->group(function () {
        Route::get('/', [AdminController::class, 'indexambulance']);
        Route::get('/dash/{id}', [AdminController::class, 'ambulancedash']);
        Route::get('/transaction/{id}', [AdminController::class, 'ambulance_transaction']);
        Route::post('/disapprove', [AdminController::class, 'disapprove_ambulance']);
        Route::post('/approve', [AdminController::class, 'approve_ambulance']);
        // Route::get('/appointments/{id}', [AdminController::class, 'pappointments']);
    });

    Route::prefix('hospital')->group(function () {

        Route::get('/', [AdminController::class, 'indexhospital']);
        Route::get('/dash/{id}/{type}', [AdminController::class, 'hospitaldash']);
        Route::get('/dash/{id}', [AdminController::class, 'hospitaldash']);
        Route::get('/transaction/{id}', [AdminController::class, 'hospital_transaction']);
        Route::post('/disapprove', [AdminController::class, 'disapprove_hospital']);
        Route::post('/approve', [AdminController::class, 'approve_hospital']);

    });

    Route::get('/subscription', [AdminController::class, 'subscription']);
    Route::post('/updateplan', [AdminController::class, 'updateplan']);
    Route::get('/nurse_type', [AdminController::class, 'nurse_type']);
    Route::get('/doctor_type', [AdminController::class, 'doctor_type']);
    Route::post('/nurse_type_delete', [AdminController::class, 'nurse_type_delete']);
    Route::post('/new_nurse_type', [AdminController::class, 'new_nurse_type']);
    Route::post('/edit_nurse_type', [AdminController::class, 'edit_nurse_type']);

    Route::post('/doctor_type_delete', [AdminController::class, 'doctor_type_delete']);
    Route::post('/new_doctor_type', [AdminController::class, 'new_doctor_type']);
    Route::post('/edit_doctor_type', [AdminController::class, 'edit_d octor_type']);

    Route::prefix('lab')->group(function () {
        Route::get('/category', [AdminController::class, 'labcategory']);
        Route::get('/subcategory', [AdminController::class, 'labsubcategory']);

        Route::post('/deletecat', [AdminController::class, 'labdeletecat'])->name('admin.lab.category.destroy');
        Route::post('/newcat', [AdminController::class, 'labnewcat'])->name('admin.lab.category.store');
        Route::post('/editcat', [AdminController::class, 'labeditcat'])->name('admin.lab.category.update');

        Route::post('/deletesubcat', [AdminController::class, 'labdeletesubcat']);
        Route::post('/newsubcat', [AdminController::class, 'labnewsubcat']);
        Route::post('/editsubcat', [AdminController::class, 'labeditsubcat']);

        Route::get('/report', [AdminController::class, 'labreport']);
        Route::get('/transactions', [AdminController::class, 'labtrans']);
        Route::get('/users', [AdminController::class, 'lab_users']);
        Route::get('/user/{id}', [AdminController::class, 'lab_user']);
        Route::post('/disapprove', [AdminController::class, 'disapprove_lab']);
        Route::post('/approve', [AdminController::class, 'approve_lab']);

    });

    Route::prefix('pharmacy')->group(function () {

        Route::get('/requests', [AdminController::class, 'phar_requests']);
        Route::get('/transactions', [AdminController::class, 'phartrans']);
        Route::get('/users', [AdminController::class, 'phar_users']);
        Route::get('/user/{id}', [AdminController::class, 'phar_user']);
        Route::post('/disapprove', [AdminController::class, 'disapprove_phar']);
        Route::post('/approve', [AdminController::class, 'approve_phar']);

    });

    Route::get('/settings', [AdminController::class, 'settings']);
    Route::post('/settings', [AdminController::class, 'psettings']);

    Route::post('/new_question', [AdminController::class, 'new_question']);
    Route::post('/edit_question', [AdminController::class, 'edit_question']);
    Route::post('/delete_question', [AdminController::class, 'delete_question']);
});

Route::get('/put/{email}', function ($email) {
    DB::table("pharmacy")->where(["email" => $email])->update(["active" => 1, "verififcation_status" => 1, "status" => 1]);
    $data = DB::table("pharmacy")->where(["email" => $email])->first();
    dd($data);
});

Route::fallback(function () {
    return view('admin.error');
});

Route::get('/emai', function ($email) {

    $data = ['email' => 'meyorpop@gmail.com',
        'subject' => "test",
        'message' => "testing email"];
    Mail::send('Html.view', $data, function ($message, $data) {
        $message->to($data['email'], 'John Doe');
        $message->subject('Subject');
    });
    return 'yess';
});
