
<p>Your OTP reset password code is {{$resettoken}}</p>