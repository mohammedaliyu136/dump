@include("admin.layout.header")


<div class="content">
    <h2 class="intro-y text-lg font-medium mt-10">
            App Testing
    </h2>
    <div class="grid grid-cols-12">
        <!-- BEGIN: Data List -->
        <a href="#" class="btn btn-primary shadow-md mr-2" data-toggle="modal" data-target="#doctor_create_appointment">Create Doctor Appointment</a>
        
        <a href="#" class="btn btn-primary shadow-md mr-2" data-toggle="modal" data-target="#nurse_create_appointment">Create Nurse Appointment</a>
        
        <a href="#" class="btn btn-primary shadow-md mr-2" data-toggle="modal" data-target="#hospital_create_appointment">Create Hospital Appointment</a>

        <a href="#" class="btn btn-primary shadow-md mr-2" data-toggle="modal" data-target="#patient_fund_account">Fund Patient Account</a>


        <!-- END: Data List -->
    </div>
                    
                     


          
   <div id="edititem" class="modal" tabindex="-1" aria-hidden="true">
   <div class="modal-dialog">
         <form id="edit_item">
      <div class="modal-content">
          <div class="modal-header">
                 <h2 class="font-medium text-base mr-auto">Edit Subcription</h2>
                 </div>
         <div class="modal-body p-10  ">
             
             <div class="mt-3"> <label for="regular-form-4" class="form-label">Title</label> <input id="etitle" type="text" class="form-control" placeholder="Enter Title"> </div>
            <div class="mt-3"> <label for="regular-form-4" class="form-label">Price</label> <input id="eprice" type="text" class="form-control" placeholder="Enter Price"> </div>
            <div class="mt-3"> <label for="regular-form-4" class="form-label">Type</label> <input id="etype" type="text" class="form-control" placeholder="Enter Type"> </div>
            <div class="mt-3"> <label for="regular-form-4" class="form-label">Description</label> <input id="edes" type="text" class="form-control" placeholder="Enter Description"> </div>
                        </div>
        <div class="modal-footer text-right"><button type="submit" class="btn btn-primary ">Update</button></div>
      </div>
            </form>
   </div>
</div>
                    
                </div>
                    <div id="patient_fund_account" class="modal" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog">
                            <form id="newtype">
                                <div class="modal-content">
                                    <div class="modal-header">
                                            <h2 class="font-medium text-base mr-auto">Fund Patient Account</h2>
                                            </div>
                                    <div class="modal-body p-10  ">
                                        <div class="mt-3"> <label for="regular-form-4" class="form-label">Patient</label>
                                            <div class="w-full mt-3 xl:mt-0 flex-1">
                                                <select id="category" class="form-select">
                                                @if ($patients->count())

                                                    @foreach($patients as $patient)
                                                    <option value="{{ $patient->id }}" >{{ $patient->first_name }} {{ $patient->other_name }} {{ $patient->last_name }}</option> 
                                                    @endforeach   

                                                @endif
                                                </select>
                                            </div>
                                        </div>
                                        
                                        <div class="mt-3"> <label for="regular-form-4" class="form-label">Amount</label> 
                                        
                                        <input name="patient_fund_amount" type="text" class="form-control" placeholder="Enter Amount"> </div>
                                    <div class="modal-footer text-right"><button type="submit" class="btn btn-primary ">Fund</button></div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div id="doctor_create_appointment" class="modal" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog">
                            <form id="newtype" action="/app/testing/book/doctor">
                                <div class="modal-content">
                                    <div class="modal-header">
                                            <h2 class="font-medium text-base mr-auto">Create Doctor Appointment</h2>
                                            </div>
                                    <div class="modal-body p-10  ">
                                        
                                        <div class="mt-3"> <label for="regular-form-4" class="form-label">Doctor</label>
                                            <div class="w-full mt-3 xl:mt-0 flex-1">
                                                <select id="category" class="form-select" name="doc_id">
                                                @if ($doctors->count())

                                                    @foreach($doctors as $doctor)
                                                    <option value="{{ $doctor->id }}" >{{ $doctor->first_name }} {{ $doctor->other_name }} {{ $doctor->last_name }}</option> 
                                                    @endforeach   

                                                @endif
                                                </select>
                                            </div>
                                        </div>
                                        <div class="mt-3"> <label for="regular-form-4" class="form-label">Patient</label>
                                            <div class="w-full mt-3 xl:mt-0 flex-1">
                                                <select id="category" class="form-select" name="patient_id">
                                                @if ($patients->count())

                                                    @foreach($patients as $patient)
                                                    <option value="{{ $patient->id }}" >{{ $patient->first_name }} {{ $patient->other_name }} {{ $patient->last_name }}</option> 
                                                    @endforeach   

                                                @endif
                                                </select>
                                            </div>
                                        </div>
                                    <div class="modal-footer text-right"><button type="submit" class="btn btn-primary ">Create</button></div>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                    <div id="nurse_create_appointment" class="modal" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog">
                            <form id="newtype" action="/app/testing/book/nurse">
                                <div class="modal-content">
                                    <div class="modal-header">
                                            <h2 class="font-medium text-base mr-auto">Create Nurse Appointment</h2>
                                            </div>
                                    <div class="modal-body p-10  ">
                                        
                                        <div class="mt-3"> <label for="regular-form-4" class="form-label">Nurse</label> 
                                        <select id="category" class="form-select" name="nurse_id">
                                                @if ($nurses->count())

                                                    @foreach($nurses as $nurse)
                                                    <option value="{{ $nurse->id }}" >{{ $nurse->first_name }} {{ $nurse->other_names }} {{ $nurse->last_names }}</option> 
                                                    @endforeach   

                                                @endif
                                                </select>
                                        </div>
                                        
                                        <div class="mt-3"> <label for="regular-form-4" class="form-label">Patient</label>
                                            <div class="w-full mt-3 xl:mt-0 flex-1">
                                                <select id="category" class="form-select" name="patient_id">
                                                @if ($patients->count())

                                                    @foreach($patients as $patient)
                                                    <option value="{{ $patient->id }}" >{{ $patient->first_name }} {{ $patient->other_name }} {{ $patient->last_name }}</option> 
                                                    @endforeach   

                                                @endif
                                                </select>
                                            </div>
                                        </div>
                                    <div class="modal-footer text-right"><button type="submit" class="btn btn-primary ">Create</button></div>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                    <div id="hospital_create_appointment" class="modal" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog">
                            <form id="newtype">
                                <div class="modal-content">
                                    <div class="modal-header">
                                            <h2 class="font-medium text-base mr-auto">Create Hospital Appointment</h2>
                                            </div>
                                    <div class="modal-body p-10  ">
                                    <div class="mt-3"> <label for="regular-form-4" class="form-label">Nurse</label> 
                                        <select id="category" class="form-select">
                                                @if ($nurses->count())

                                                    @foreach($nurses as $nurse)
                                                    <option value="{{ $nurse->id }}" >{{ $nurse->first_name }} {{ $nurse->other_names }} {{ $nurse->last_names }}</option> 
                                                    @endforeach   

                                                @endif
                                                </select>
                                        </div>

                                        
                                        <div class="mt-3"> <label for="regular-form-4" class="form-label">Patient</label>
                                            <div class="w-full mt-3 xl:mt-0 flex-1">
                                                <select id="category" class="form-select">
                                                @if ($patients->count())

                                                    @foreach($patients as $patient)
                                                    <option value="{{ $patient->id }}" >{{ $patient->first_name }} {{ $patient->other_name }} {{ $patient->last_name }}</option> 
                                                    @endforeach   

                                                @endif
                                                </select>
                                            </div>
                                        </div>
                                        
                                        <div class="mt-3"> <label for="regular-form-4" class="form-label">Title</label> 
                                        
                                        <input id="name" type="text" class="form-control" placeholder="Enter Title"> </div>
                                        </div>
                                    <div class="modal-footer text-right"><button type="submit" class="btn btn-primary ">Create</button></div>
                                </div>
                            </form>
                        </div>
                    </div>
                <input type="hidden" id="id"/>
@include("admin.layout.footer")

<script>
    


  $('#edit_item').submit( function (event) {
	// prevent the usual form submission behaviour; the "action" attribute of the form
	event.preventDefault();
	// validation goes below...
const title = $("#etitle").val()
const type = $("#etype").val()
const des = $("#edes").val()
const price = $("#eprice")
const id = $("#id").val()
	// now for the big event
	$.ajax({
	  // the server script you want to send your data to
		'url': '/admin/lab/editcat',
		// all of your POST/GET variables
		'data': {
			// 'dataname': $('input').val(), ...
			title,
			type,
			des,
			price,
			id,
			"_token":"{{csrf_token()}}"
		},
		// you may change this to GET, if you like...
		'type': 'post',
	 
		'beforeSend': function () {
			// anything you want to have happen before sending the data to the server...
			// useful for "loading" animations
			$("button").attr("disabled",true)
		}
	})
	.done( function (response) {
		// what you want to happen when an ajax call to the server is successfully completed
		// 'response' is what you get back from the script/server
		// usually you want to format your response and spit it out to the page
		document.getElementById("showsuccess").click()
		$("#message").html(response.message)
		location.reload()
		
	})
	.fail( function (code, status) {
		// what you want to happen if the ajax request fails (404 error, timeout, etc.)
		// 'code' is the numeric code, and 'status' is the text explanation for the error
		// I usually just output some fancy error messages
		$("#message2").html(code.responseJSON.message)
		document.getElementById("showerror").click()
	})
	.always( function (xhr, status) {
		// what you want to have happen no matter if the response is success or error
		// here, you would "stop" your loading animations, and maybe output a footer at the end of your content, reading "done"
		$("button").attr("disabled",false)
	    
	});
});
    function deletebtn(){
        const id = $("#id").val()
        $.post('/admin/lab/deletecat',{
            id,
            "_token":"{{csrf_token()}}"
        }).done(function(response){
          	document.getElementById("showsuccess").click()
		$("#message").html(response.message)
		location.reload()  
        })
    }
    
    
    function setID(id){
        $("#id").val(id)
    }
    
    function setID2(id,title,price,type,des){
        $("#id").val(id)
        $("#etitle").val(title)
        $("#eprice").val(price)
        $("#etype").val(type)
        $("#edes").val(des)
    }
</script>