@include("admin.layout.header")


<div class="content">
                    <h2 class="intro-y text-lg font-medium mt-10">
                       Vital Sign
                    </h2>
                    <div class="grid grid-cols-12 gap-6 mt-5">
                        <div class="intro-y col-span-12 flex flex-wrap sm:flex-nowrap items-center mt-2">
                            
                          
                            <div class="hidden md:block mx-auto text-gray-600"></div>
                            <div class="w-full sm:w-auto mt-3 sm:mt-0 sm:ml-auto md:ml-0">
                                <div class="w-56 relative text-gray-700 dark:text-gray-300">
                                    <input type="text" class="form-control w-56 box pr-10 placeholder-theme-8" placeholder="Search...">
                                    <i class="w-4 h-4 absolute my-auto inset-y-0 mr-3 right-0" data-feather="search"></i> 
                                </div>
                            </div>
                        </div>
                        <!-- BEGIN: Data List -->
                        <div class="intro-y col-span-12 overflow-auto table-responsive lg:overflow-visible">
                            <table class="table table-report -mt-2">
                                <thead>
                                    <tr>
                                    <th class="text-center">ID</th>
                                    <th class="text-center">NURSE</th>
                                    <th class="text-center">PATIENT</th>
                                    <th class="text-center">BLOOD GROUP</th>
                                    <th class="text-center">TEMPRATURE</th>
                                    <th class="text-center">PULSE RATE</th>
                                    <th class="text-center">RESPIRATION</th>
                                    <th class="text-center">SPO2</th>
                                    <th class="text-center">BODY MASS</th>
                                    <th class="text-center">STATUS</th>
                                        <th class="text-center">DATE</th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($data as $d)
                                    <tr class="intro-x">
                                          <td class="text-center">{{$d->id}}</td>
                                           <td class="text-center"><a href="/admin/nurseprofile/{{$d->nid}}">{{$d->nurse_firstname}} {{$d->nurse_lastname}}</a></td>
                                             <td class="text-center"><a href="/admin/patientprofile/{{$d->pid}}">{{$d->pfirstname}} {{$d->plastname}}</a></td>
                                             <td class="text-center">{{$d->blood_group}}</td>
                                             
                                              <td class="text-center">{{$d->temprature}}</td>
                                          
                                             <td class="text-center">{{$d->pulse_rate}}</td>
                                             <td class="text-center">{{$d->respiration}}</td>
                                             <td class="text-center">{{$d->sp02}}</td>
                                             <td class="text-center">{{$d->body_mass}}</td> 
                                             <td class="text-center">
                                                 @if($d->status == 1)
                                                 
                                                 Active
                                                 
                                                 @elseif($d->status == 2)
                                                 
                                                 InActive
                                                 
                                                 @else
                                                 
                                                 Pending
                                                 
                                                 @endif
                                                 
                                             </td> 
                                            <td class="text-center">{{$d->created_at}}</td>
                                       
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        <!-- END: Data List -->
                        <!-- BEGIN: Pagination -->
                        <div class="intro-y col-span-12 flex flex-wrap sm:flex-row sm:flex-nowrap ">
                           {{$data->links()}}    
                        </div>
                        <!-- END: Pagination -->
                    </div>
                    
                     


          
   
@include("admin.layout.footer")
 