@include('admin.nurse.sidehead')
<div class="col-span-12 lg:col-span-8 xxl:col-span-9">

    <div class="grid grid-cols-12 gap-6">
        <!-- BEGIN: Daily Sales -->
        <div class="intro-y box col-span-12 xxl:col-span-6">
            <div class="flex items-center px-5 py-5 sm:py-3 border-b border-gray-200 dark:border-dark-5">
                <h2 class="font-medium text-base mr-auto">
                    Transactions
                </h2>
                <div class="dropdown ml-auto sm:hidden">
                    <a class="dropdown-toggle w-5 h-5 block" href="javascript:;" aria-expanded="false"> <i
                            data-feather="more-horizontal" class="w-5 h-5 text-gray-600 dark:text-gray-300"></i> </a>
                    <div class="dropdown-menu w-40">
                        <div class="dropdown-menu__content box dark:bg-dark-1 p-2">
                            <a href="javascript:;"
                                class="flex items-center p-2 transition duration-300 ease-in-out bg-white dark:bg-dark-1 hover:bg-gray-200 dark:hover:bg-dark-2 rounded-md">
                                <i data-feather="file" class="w-4 h-4 mr-2"></i> Download Excel </a>
                        </div>
                    </div>
                </div>
                <button class="btn btn-outline-secondary hidden sm:flex"> <i data-feather="file"
                        class="w-4 h-4 mr-2"></i> Download Excel </button>
            </div>
            <div class="p-5">
                <div class="grid grid-cols-12 gap-6 mt-5">
                    @foreach ($data2 as $d)
                        <div class="intro-y col-span-12 md:col-span-6 lg:col-span-7">
                            <div class="box">

                                <div class="text-center lg:text-left p-3" style="font-size: 12px;">
                                    <div>
                                        <li>Transaction Type: {{ $d->type }}</li>
                                        <li>Status: {{ $d->status }}</li>
                                        <li>Amount: NGN{{ number_format($d->amount, 2) }}</li>
                                        <li>Date: {{ $d->created_at }}</li>

                                    </div>


                                </div>

                            </div>
                        </div>
                    @endforeach
                </div>

            </div>
        </div>



    </div>
</div>
@include('admin.nurse.sidefoot')
