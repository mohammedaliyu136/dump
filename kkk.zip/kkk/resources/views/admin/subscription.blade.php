@include("admin.layout.header")


<div class="content">
                    <h2 class="intro-y text-lg font-medium mt-10">
                         Subscription
                    </h2>
                    <div class="grid grid-cols-12 gap-6 mt-5">
                        <div class="intro-y col-span-12 flex flex-wrap sm:flex-nowrap items-center mt-2">
                            
                          
                            <div class="hidden md:block mx-auto text-gray-600"></div>
                            <div class="w-full sm:w-auto mt-3 sm:mt-0 sm:ml-auto md:ml-0">
                                <div class="w-56 relative text-gray-700 dark:text-gray-300">
                                    <input type="text" class="form-control w-56 box pr-10 placeholder-theme-8" placeholder="Search...">
                                    <i class="w-4 h-4 absolute my-auto inset-y-0 mr-3 right-0" data-feather="search"></i> 
                                </div>
                            </div>
                        </div>
                        <!-- BEGIN: Data List -->
                        <div class="intro-y col-span-12 overflow-auto lg:overflow-visible">
                            <table class="table table-report -mt-2">
                                <thead>
                                    <tr>
                                        <th class="text-center">ID</th>
                                        <th class="text-center">SUBCRIPTION TITLE</th>
                                         <th class="text-center">PRICE</th>
                                          <th class="text-center">TYPE</th>
                                           <th class="text-center">DESCRIPTION</th> 
                                        <th class="text-center">ACTIONS</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($data as $d)
                                    <tr class="intro-x">
                                          <td class="text-center">{{$d->id}}</td>
                                           <td class="text-center">{{$d->subscription_title}}</td>
                                            <td class="text-center">NGN{{number_format($d->price,2)}}</td>
                                              <td class="text-center">{{$d->type}}</td>
                                                <td class="text-center">{{$d->description}}</td>
                                        <td class="table-report__action w-56">
                                            <div class="flex justify-center items-center">
                                                <a class="flex items-center mr-3" href="javascript:;" data-toggle="modal" data-target="#edititem" onclick="setID2({{$d->id}},'{{$d->subscription_title}}','{{$d->price}}','{{$d->type}}','{{$d->description}}')"> <i data-feather="check-square" class="w-4 h-4 mr-1"></i> Edit </a>
      
                                            </div>
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        <!-- END: Data List -->
                        <!-- BEGIN: Pagination -->
                        <div class="intro-y col-span-12 flex flex-wrap sm:flex-row sm:flex-nowrap ">
                           {{$data->links()}}    
                        </div>
                        <!-- END: Pagination -->
                    </div>
                    
                     


          
                    <div id="edititem" class="modal" tabindex="-1" aria-hidden="true">
   <div class="modal-dialog">
         <form id="edit_item">
      <div class="modal-content">
          <div class="modal-header">
                 <h2 class="font-medium text-base mr-auto">Edit Subcription</h2>
                 </div>
         <div class="modal-body p-10  ">
             
             <div class="mt-3"> <label for="regular-form-4" class="form-label">Title</label> <input id="etitle" type="text" class="form-control" placeholder="Enter Title"> </div>
            <div class="mt-3"> <label for="regular-form-4" class="form-label">Price</label> <input id="eprice" type="text" class="form-control" placeholder="Enter Price"> </div>
            <div class="mt-3"> <label for="regular-form-4" class="form-label">Type</label> <input id="etype" type="text" class="form-control" placeholder="Enter Type"> </div>
            <div class="mt-3"> <label for="regular-form-4" class="form-label">Description</label> <input id="edes" type="text" class="form-control" placeholder="Enter Description"> </div>
                        </div>
        <div class="modal-footer text-right"><button type="submit" class="btn btn-primary ">Update</button></div>
      </div>
            </form>
   </div>
</div>
                    
                </div>
                <input type="hidden" id="id"/>
@include("admin.layout.footer")

<script>
    


  $('#edit_item').submit( function (event) {
	// prevent the usual form submission behaviour; the "action" attribute of the form
	event.preventDefault();
	// validation goes below...
const title = $("#etitle").val()
const type = $("#etype").val()
const des = $("#edes").val()
const price = $("#eprice")
const id = $("#id").val()
	// now for the big event
	$.ajax({
	  // the server script you want to send your data to
		'url': '/admin/lab/editcat',
		// all of your POST/GET variables
		'data': {
			// 'dataname': $('input').val(), ...
			title,
			type,
			des,
			price,
			id,
			"_token":"{{csrf_token()}}"
		},
		// you may change this to GET, if you like...
		'type': 'post',
	 
		'beforeSend': function () {
			// anything you want to have happen before sending the data to the server...
			// useful for "loading" animations
			$("button").attr("disabled",true)
		}
	})
	.done( function (response) {
		// what you want to happen when an ajax call to the server is successfully completed
		// 'response' is what you get back from the script/server
		// usually you want to format your response and spit it out to the page
		document.getElementById("showsuccess").click()
		$("#message").html(response.message)
		location.reload()
		
	})
	.fail( function (code, status) {
		// what you want to happen if the ajax request fails (404 error, timeout, etc.)
		// 'code' is the numeric code, and 'status' is the text explanation for the error
		// I usually just output some fancy error messages
		$("#message2").html(code.responseJSON.message)
		document.getElementById("showerror").click()
	})
	.always( function (xhr, status) {
		// what you want to have happen no matter if the response is success or error
		// here, you would "stop" your loading animations, and maybe output a footer at the end of your content, reading "done"
		$("button").attr("disabled",false)
	    
	});
});
    function deletebtn(){
        const id = $("#id").val()
        $.post('/admin/lab/deletecat',{
            id,
            "_token":"{{csrf_token()}}"
        }).done(function(response){
          	document.getElementById("showsuccess").click()
		$("#message").html(response.message)
		location.reload()  
        })
    }
    
    
    function setID(id){
        $("#id").val(id)
    }
    
    function setID2(id,title,price,type,des){
        $("#id").val(id)
        $("#etitle").val(title)
        $("#eprice").val(price)
        $("#etype").val(type)
        $("#edes").val(des)
    }
</script>