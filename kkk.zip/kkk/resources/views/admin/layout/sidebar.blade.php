 <div class="deznav">
     <div class="deznav-scroll">
         <ul class="metismenu" id="menu">
             <li><a class="ai-icon" href="/admin/dashboard" aria-expanded="false">
                     <i class="flaticon-381-home"></i>
                     <span class="nav-text">Dashboard</span>
                 </a>
             </li>
             <li><a href="/admin/doctors" class="ai-icon" aria-expanded="false">
                     <i class="flaticon-381-menu"></i>
                     <span class="nav-text">Doctors</span>
                 </a>
             </li>
             <li><a href="/admin/nurses" class="ai-icon" aria-expanded="false">
                     <i class="flaticon-381-id-card-4"></i>
                     <span class="nav-text">Nurses</span>
                 </a>
             </li>

             <li><a class="ai-icon" href="/admin/patients" aria-expanded="false">
                     <i class="flaticon-381-television"></i>
                     <span class="nav-text">Patients</span>
                 </a>
             </li>
             <li><a class="ai-icon" href="/admin/ambulance" aria-expanded="false">
                     <i class="flaticon-381-controls-3"></i>
                     <span class="nav-text">Ambulances</span>
                 </a>
             </li>

             <li><a href="/admin/hospital" class="ai-icon" aria-expanded="false">
                     <i class="flaticon-381-menu"></i>
                     <span class="nav-text">Hospital</span>
                 </a>
             </li>
             <li><a href="/admin/logistic" class="ai-icon" aria-expanded="false">
                     <i class="flaticon-381-menu"></i>
                     <span class="nav-text">Logistics</span>
                 </a>
             </li>
             <li><a href="/admin/pharmacy/users" class="ai-icon" aria-expanded="false">
                     <i class="flaticon-381-menu"></i>
                     <span class="nav-text">Pharmacy</span>
                 </a>
             </li>

             <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                     <i class="flaticon-381-controls-3"></i>
                     <span class="nav-text">Lab</span>
                 </a>
                 <ul aria-expanded="false">
                     <li><a href="/admin/lab/users">Lab Users</a></li>
                     <li><a href="/admin/lab/category">Lab Category</a></li>
                     <li><a href="/admin/lab/subcategory">LAb Sub-category</a></li>
                     <li><a href="/admin/lab/report">Report</a></li>
                     <li><a href="/admin/lab/transactions">Transactions</a></li>
                 </ul>
             </li>

             <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                     <i class="flaticon-381-controls-3"></i>
                     <span class="nav-text">Nurse Service</span>
                 </a>
                 <ul aria-expanded="false">
                     <li><a href="/admin/nurse/service/vitalsign">Vital Signs Reading</a></li>
                     <li><a href="chart-chartjs.html">Lab Sample Pickup</a></li>
                     <li><a href="chart-chartist.html">Nurse Care</a></li>
                 </ul>
             </li>
             <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                     <i class="flaticon-381-controls-3"></i>
                     <span class="nav-text">Admin Settings</span>
                 </a>
                 <ul aria-expanded="false">
                     <li><a href="/admin/questions">Questions</a></li>
                     <li><a href="/admin/nurse_type">Nurse Type</a></li>
                     <li><a href="/admin/doctor_type">Doctor Type</a></li>
                     <li><a href="/admin/subscriptions">Subscriptions</a></li>
                     <li><a href="/admin/settings">Application Settings</a></li>
                 </ul>
             </li>


         </ul>

         {{-- <div class="plus-box">
                     <p class="fs-16 font-w500 mb-1">Check your job schedule</p>
                     <a class="text-white fs-26" href="javascript:;"><i class="las la-long-arrow-alt-right"></i></a>
                 </div> --}}

         <hr />

         <div class="copyright" style="">
             <p class="fs-14 font-w200"><strong class="font-w400">Sonocare Hospital Admin Dashboard</strong> ©
                 2024
                 All Rights Reserved</p>
         </div>
     </div>
 </div>
