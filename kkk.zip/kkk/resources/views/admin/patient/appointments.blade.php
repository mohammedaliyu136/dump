
@include("admin.patient.sidehead")
                        <!-- END: Profile Menu -->
                        <div class="col-span-12 lg:col-span-8 xxl:col-span-9">
                            
                            <div class="grid grid-cols-12 gap-6">
                                <!-- BEGIN: Daily Sales -->
                                <div class="intro-y box col-span-12 xxl:col-span-6">
                                    <div class="flex items-center px-5 py-5 sm:py-3 border-b border-gray-200 dark:border-dark-5">
                                        <h2 class="font-medium text-base mr-auto">
                                       Doctor Appointment
                                        </h2>
                                        <div class="dropdown ml-auto sm:hidden">
                                            <a class="dropdown-toggle w-5 h-5 block" href="javascript:;" aria-expanded="false"> <i data-feather="more-horizontal" class="w-5 h-5 text-gray-600 dark:text-gray-300"></i> </a>
                                            <div class="dropdown-menu w-40">
                                                <div class="dropdown-menu__content box dark:bg-dark-1 p-2">
                                                    <a href="javascript:;" class="flex items-center p-2 transition duration-300 ease-in-out bg-white dark:bg-dark-1 hover:bg-gray-200 dark:hover:bg-dark-2 rounded-md"> <i data-feather="file" class="w-4 h-4 mr-2"></i> Download Excel </a>
                                                </div>
                                            </div>
                                        </div>
                                        <button class="btn btn-outline-secondary hidden sm:flex"> <i data-feather="file" class="w-4 h-4 mr-2"></i> Download Excel </button>
                                    </div>
                                    <div class="p-5">
                                       <div class="grid grid-cols-12 gap-6 mt-5">
                        
                        <!-- BEGIN: Users Layout -->
                        @foreach($data2 as $d)
                        <?php $user = DB::table("doctors")->where(["id"=>$d->doctor_id])->first();?>
                      <div class="intro-y col-span-12 md:col-span-6">
                            <div class="box">
                                <div class="flex flex-col lg:flex-row items-center p-5">
                                    <div class="w-24 h-24 lg:w-12 lg:h-12 image-fit lg:mr-1">
                                        <img alt="Icewall Tailwind HTML Admin Template" class="rounded-full" src="{{$user->image}}">
                                    </div>
                                    <div class="lg:ml-2 lg:mr-auto text-center lg:text-left mt-3 lg:mt-0">
                                        <a href="/admin/doctorprofile/{{$user->id}}" class="font-medium">{{$user->first_name}} {{$user->last_name}}</a> 
                                        <div class="text-gray-600 text-xs mt-0.5">
                                            @if($d->status == 0)
                                            Pending..
                                            @elseif($d->status == 1)
                                            Approved
                                            @elseif($d->status == 2)
                                            Disapproved
                                            @endif
                                            </div>
                                    </div>
                                    <div class="flex mt-4 lg:mt-0">
                                        <!--<button class="btn btn-primary py-1 px-2 mr-2">Message</button>-->
                                        @if($d->status == 2)
                                        
                                        <div class="text-gray-600 text-xs mt-0.5 ml-2">
                                            {{$d->date}} / {{$d->time}} / {{$d->day}}
                                                <br>
                                            <span style="color: red">Rescheduled</span>
                                            </div>
                                           
                                            @else
                                            
                                            <div class="text-gray-600 text-xs mt-0.5">
                                            {{$d->date}} / {{$d->time}} / {{$d->day}}
                                            </div>
                                            @endif
                                                               </div>
                                </div>
                            </div>
                        </div>
                        @endforeach
                         
                    </div>

                                    </div>
                                </div>
    
    
    
                            </div>
                        </div>
                                 
@include("admin.patient.sidefoot")