
@include("admin.patient.sidehead")
   <div class="col-span-12 lg:col-span-8 xxl:col-span-9">
                            
                            <div class="grid grid-cols-12 gap-6">
                                <!-- BEGIN: Daily Sales -->
                                <div class="intro-y box col-span-12 xxl:col-span-6">
                                    <div class="flex items-center px-5 py-5 sm:py-3 border-b border-gray-200 dark:border-dark-5">
                                        <h2 class="font-medium text-base mr-auto">
                                       Nurse VitalSigns
                                        </h2>
                                        <div class="dropdown ml-auto sm:hidden">
                                            <a class="dropdown-toggle w-5 h-5 block" href="javascript:;" aria-expanded="false"> <i data-feather="more-horizontal" class="w-5 h-5 text-gray-600 dark:text-gray-300"></i> </a>
                                            <div class="dropdown-menu w-40">
                                                <div class="dropdown-menu__content box dark:bg-dark-1 p-2">
                                                    <a href="javascript:;" class="flex items-center p-2 transition duration-300 ease-in-out bg-white dark:bg-dark-1 hover:bg-gray-200 dark:hover:bg-dark-2 rounded-md"> <i data-feather="file" class="w-4 h-4 mr-2"></i> Download Excel </a>
                                                </div>
                                            </div>
                                        </div>
                                        <button class="btn btn-outline-secondary hidden sm:flex"> <i data-feather="file" class="w-4 h-4 mr-2"></i> Download Excel </button>
                                    </div>
                                    <div class="p-5">
                                       <div class="grid grid-cols-12 gap-6 mt-5">
                        @foreach($data2 as $d)
                        <?php $user = DB::table("nurses")->where(["id"=>$d->nurse_id])->first();?>
                        @if($user != null)
                          <div class="intro-y col-span-12 md:col-span-6 lg:col-span-4" onclick="location.href='/admin/nurseprofile/{{$user->id}}'">
                            <div class="box">
                                <div class="flex items-start px-5 pt-5">
                                    <div class="w-full flex flex-col lg:flex-row items-center">
                                        <div class="w-16 h-16 image-fit">
                                            <img alt="Icewall Tailwind HTML Admin Template" class="rounded-full" style="height:40px !important; width: 40px !important" src="{{$user->image}}">
                                        </div>
                                        <div class="lg:ml-4 text-center lg:text-left mt-3 lg:mt-0">
                                            <a href="" class="font-medium">{{$user->first_name}} {{$user->last_names}}</a> 
                                            <div class="text-gray-600 text-xs mt-0.5">{{$user->nurse_type}}</div>
                                        </div>
                                    </div>
                                   
                                </div>
                                <div class="text-center lg:text-left p-5">
                                    <div>
                                        <li>Blood Group: {{$d->blood_group}}</li>
                                          <li>Temprature: {{$d->temprature}}</li>
                                            <li>Pulse Rate: {{$d->pulse_rate}}</li>
                                            <li>Respiration: {{$d->respiration}}</li>
                                               <li>SP02: {{$d->sp02}}</li>
                                                  <li>Body Mass: {{$d->body_mass}}</li>
                                                     <li>Status: {{$d->status == 1? 'Active' : 'Pending'}}</li>
                                        </div>
                                   
                                   
                                                                   </div>
                                
                            </div>
                        </div>
                        @endif
                         @endforeach
                    </div>

                                    </div>
                                </div>
    
    
    
                            </div>
                        </div>
@include("admin.patient.sidefoot")