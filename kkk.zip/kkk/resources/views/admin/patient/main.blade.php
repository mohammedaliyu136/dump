 @extends('admin.layout.app', ['title' => 'Patient ' . $data->first_name . ' ' . $data->last_name])

 @section('content')
     <div class="content-body">
         <!-- row -->
         <div class="container-fluid">
             <div class="d-block d-sm-flex mb-3 mb-md-4">
                 <select class="default-select ms-auto me-1 image-select style-2">
                     <option data-thumbnail="images/svg/check-circle 1.svg"
                         data-content="<img src='images/svg/check-circle%201.svg'/>">Available</option>
                     <option data-thumbnail="images/svg/check-circle 1.svg"
                         data-content="<img src='images/svg/check-circle%201.svg'/>">Daily</option>
                     <option data-thumbnail="images/svg/check-circle 1.svg"
                         data-content="<img src='images/svg/check-circle%201.svg'/>">Weekly</option>
                     <option data-thumbnail="images/svg/check-circle 1.svg"
                         data-content="<img src='images/svg/check-circle%201.svg'/>">Monthly</option>
                 </select>
                 <a href="javascript:void(0);" class="btn btn-primary btn-rounded mb-2 ms-2"><i
                         class="las scale5 la-pencil-alt me-2"></i> Edit</a>
             </div>
             <div class="row">
                 <div class="col-xl-12 col-xxl-12 col-lg-12">
                     <div class="card">
                         <div class="card-body">
                             <div class="media d-sm-flex d-block text-center text-sm-start pb-4 mb-4 border-bottom">
                                 <img alt="image" class="rounded me-sm-4 me-0" width="130" src="{{ $data->image }}">
                                 <div class="media-body align-items-center">
                                     <div class="d-sm-flex d-block justify-content-between my-3 my-sm-0">
                                         <div>
                                             <h3 class="fs-22 text-black font-w600 mb-0">
                                                 {{ $data->first_name . ' ' . $data->last_name }}</h3>
                                             <p class="mb-2 mb-sm-2">Check In date {{ $data->created_at }}</p>
                                         </div>
                                         <span>#{{ substr(md5($data->id), 0, 5) . '...' }}</span>
                                     </div>
                                     <a href="javascript:void(0);" class="btn btn-primary light btn-rounded mb-2 me-2">
                                         <svg class="me-2 scale5" width="14" height="14" viewBox="0 0 26 26"
                                             fill="none" xmlns="http://www.w3.org/2000/svg">
                                             <path
                                                 d="M18 0.500061V3.00006H21.25L16.625 7.62506C15 6.25006 12.875 5.50006 10.5 5.50006C5 5.50006 0.5 10.0001 0.5 15.5001C0.5 21.0001 5 25.5001 10.5 25.5001C16 25.5001 20.5 21.0001 20.5 15.5001C20.5 13.1251 19.75 11.0001 18.375 9.37506L23 4.75006V8.00006H25.5V0.500061H18ZM10.5 23.0001C6.375 23.0001 3 19.6251 3 15.5001C3 11.3751 6.375 8.00006 10.5 8.00006C14.625 8.00006 18 11.3751 18 15.5001C18 19.6251 14.625 23.0001 10.5 23.0001Z"
                                                 fill="#2BC155"></path>
                                         </svg>
                                         {{ strtoupper($data->gender ?? '') }}
                                     </a>

                                 </div>
                             </div>
                             <div class="row">
                                 <div class="col-lg-6 mb-3">
                                     <div class="media align-items-start">
                                         <span class="p-3 border border-primary-light rounded-circle me-3">
                                             <svg width="22" height="22" viewBox="0 0 32 32" fill="none"
                                                 xmlns="http://www.w3.org/2000/svg">
                                                 <g clip-path="url(#clip0)">
                                                     <path
                                                         d="M27.5716 13.4285C27.5716 22.4285 16.0001 30.1428 16.0001 30.1428C16.0001 30.1428 4.42871 22.4285 4.42871 13.4285C4.42871 10.3596 5.64784 7.41637 7.8179 5.24631C9.98797 3.07625 12.9312 1.85712 16.0001 1.85712C19.0691 1.85712 22.0123 3.07625 24.1824 5.24631C26.3524 7.41637 27.5716 10.3596 27.5716 13.4285Z"
                                                         stroke="#2BC155" stroke-width="3" stroke-linecap="round"
                                                         stroke-linejoin="round"></path>
                                                     <path
                                                         d="M16.0002 17.2857C18.1305 17.2857 19.8574 15.5588 19.8574 13.4286C19.8574 11.2983 18.1305 9.57141 16.0002 9.57141C13.87 9.57141 12.1431 11.2983 12.1431 13.4286C12.1431 15.5588 13.87 17.2857 16.0002 17.2857Z"
                                                         stroke="#2BC155" stroke-width="3" stroke-linecap="round"
                                                         stroke-linejoin="round"></path>
                                                 </g>
                                                 <defs>
                                                     <clipPath id="clip0">
                                                         <rect width="30.8571" height="30.8571" fill="white"
                                                             transform="translate(0.571533 0.571411)"></rect>
                                                     </clipPath>
                                                 </defs>
                                             </svg>
                                         </span>
                                         <div class="media-body">
                                             <span class="d-block text-black font-w600 mb-1">Address</span>
                                             <p>{{ $data->address }}
                                                 {{ $lga == null ? '--' : $lga->title }} <strong
                                                     class="text-dark">{{ $state == null ? '--' : $state->title }}</strong>
                                             </p>
                                         </div>
                                     </div>
                                 </div>
                                 <div class="col-lg-6">
                                     <div class="map-bx mb-3">
                                         <img src="images/svg/map.svg" alt="">
                                         <a href="javascript:void(0);" class="map-button">View in Fullscreen</a>
                                         <a class="map-marker" href="javascript:void(0);">
                                             <i class="las la-map-marker-alt"></i>
                                         </a>
                                     </div>
                                 </div>
                                 <div class="col-lg-6 mb-lg-0 mb-3">
                                     <div class="media">
                                         <span class="p-3 border border-primary-light rounded-circle me-3">
                                             <svg width="22" height="22" viewBox="0 0 31 31" fill="none"
                                                 xmlns="http://www.w3.org/2000/svg">
                                                 <path
                                                     d="M28.2884 21.7563V25.6138C28.2898 25.9719 28.2165 26.3264 28.073 26.6545C27.9296 26.9826 27.7191 27.2771 27.4553 27.5192C27.1914 27.7613 26.8798 27.9456 26.5406 28.0604C26.2014 28.1751 25.8419 28.2177 25.4853 28.1855C21.5285 27.7555 17.7278 26.4035 14.3885 24.238C11.2817 22.2638 8.64771 19.6297 6.67352 16.523C4.50043 13.1685 3.14808 9.34928 2.72601 5.37477C2.69388 5.0192 2.73614 4.66083 2.8501 4.32248C2.96405 3.98413 3.14721 3.67322 3.38792 3.40953C3.62862 3.14585 3.92159 2.93517 4.24817 2.79092C4.57475 2.64667 4.9278 2.57199 5.28482 2.57166H9.14232C9.76634 2.56552 10.3713 2.78649 10.8445 3.1934C11.3176 3.60031 11.6267 4.16538 11.714 4.78329C11.8768 6.01778 12.1788 7.22988 12.6141 8.39648C12.7871 8.85671 12.8245 9.35689 12.722 9.83775C12.6194 10.3186 12.3812 10.76 12.0354 11.1096L10.4024 12.7426C12.2329 15.9617 14.8983 18.6271 18.1174 20.4576L19.7504 18.8246C20.1001 18.4789 20.5414 18.2406 21.0223 18.1381C21.5031 18.0355 22.0033 18.073 22.4636 18.246C23.6302 18.6813 24.8423 18.9832 26.0767 19.1461C26.7014 19.2342 27.2718 19.5488 27.6796 20.0301C28.0874 20.5113 28.304 21.1257 28.2884 21.7563Z"
                                                     stroke="#2BC155" stroke-width="3" stroke-linecap="round"
                                                     stroke-linejoin="round"></path>
                                             </svg>
                                         </span>
                                         <div class="media-body">
                                             <span class="d-block text-black font-w600 mb-1">Phone</span>
                                             <p class=" font-w600 mb-0">{{ $data->phone_number }}</p>
                                         </div>
                                     </div>
                                 </div>
                                 <div class="col-lg-6">
                                     <div class="media">
                                         <span class="p-3 border border-primary-light rounded-circle me-3">
                                             <svg width="22" height="22" viewBox="0 0 31 31" fill="none"
                                                 xmlns="http://www.w3.org/2000/svg">
                                                 <path
                                                     d="M5.14344 5.14331H25.7168C27.1312 5.14331 28.2884 6.30056 28.2884 7.71498V23.145C28.2884 24.5594 27.1312 25.7166 25.7168 25.7166H5.14344C3.72903 25.7166 2.57178 24.5594 2.57178 23.145V7.71498C2.57178 6.30056 3.72903 5.14331 5.14344 5.14331Z"
                                                     stroke="#2BC155" stroke-width="3" stroke-linecap="round"
                                                     stroke-linejoin="round"></path>
                                                 <path d="M28.2884 7.71503L15.4301 16.7159L2.57178 7.71503" stroke="#2BC155"
                                                     stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                                                 </path>
                                             </svg>
                                         </span>
                                         <div class="media-body">
                                             <span class="d-block text-black font-w600 mb-1">Email</span>
                                             <p class="font-w600 mb-0">{{ $data->email }}</p>
                                         </div>
                                     </div>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>

                 <div class="intro-y card box col-span-12 xxl:col-span-6">
                     <div class="p-5">
                         <h3>Vital Signs</h3>
                         @if (count($vitalSigns) <= 0)
                             <center>
                                 <h3>No Record </h3>
                             </center>
                         @else
                             <div class="text-center lg:text-left p-5">
                                 <div>
                                     <li>Blood Group: {{ $vitalSigns->blood_group }}</li>
                                     <li>Temprature: {{ $vitalSigns->temprature }}</li>
                                     <li>Pulse Rate: {{ $vitalSigns->pulse_rate }}</li>
                                     <li>Respiration: {{ $vitalSigns->respiration }}</li>
                                     <li>SP02: {{ $vitalSigns->sp02 }}</li>
                                     <li>Body Mass: {{ $vitalSigns->body_mass }}</li>
                                     <li>Status: {{ $vitalSigns->status == 1 ? 'Active' : 'Pending' }}</li>
                                 </div>

                             </div>
                         @endif


                     </div>

                     <div class="p-5">
                         <h3>Appointments</h3>
                         @if (count($appointments))
                             <center>
                                 <h3>No Record </h3>
                             </center>
                         @else
                         @endif


                     </div>

                     <div class="p-5">
                         <h3>Transactions </h3>
                         @if (count($transactions) <= 0)
                             <center>
                                 <h3>No Record </h3>
                             </center>
                         @else
                         @endif


                     </div>

                 </div>

             </div>
         </div>
     </div>
 @endsection
