
@include("admin.hospital.sidehead")
                        <!-- END: Profile Menu -->
              @if($type == "bookings")
                        <div class="col-span-12 lg:col-span-8 xxl:col-span-9">
                            
                            <div class="grid grid-cols-12 gap-6">
                                <!-- BEGIN: Daily Sales -->
                                <div class="intro-y box col-span-12 xxl:col-span-6">
                                    <div class="flex items-center px-5 py-5 sm:py-3 border-b border-gray-200 dark:border-dark-5">
                                        <h2 class="font-medium text-base mr-auto">
                                          Bookings
                                        </h2>
                                        <div class="dropdown ml-auto sm:hidden">
                                            <a class="dropdown-toggle w-5 h-5 block" href="javascript:;" aria-expanded="false"> <i data-feather="more-horizontal" class="w-5 h-5 text-gray-600 dark:text-gray-300"></i> </a>
                                            <div class="dropdown-menu w-40">
                                                <div class="dropdown-menu__content box dark:bg-dark-1 p-2">
                                                    <a href="javascript:;" class="flex items-center p-2 transition duration-300 ease-in-out bg-white dark:bg-dark-1 hover:bg-gray-200 dark:hover:bg-dark-2 rounded-md"> <i data-feather="file" class="w-4 h-4 mr-2"></i> Download Excel </a>
                                                </div>
                                            </div>
                                        </div>
                                        <button class="btn btn-outline-secondary hidden sm:flex"> <i data-feather="file" class="w-4 h-4 mr-2"></i> Download Excel </button>
                                    </div>
                                    <div class="p-5">
                                            <div class="row">
                                                <table class="table table-auto">
  <thead>
    <tr>
      <th>Patient</th>
      <th>Schedule</th>
      <th>Service</th>
         <th>Amount</th> 
               <th>Status</th>
                  <th>Date</th>
    </tr>
  </thead>
  <tbody>
   @foreach($bookings as $b)
    <tr>
    
      <td><a href="/admin/patientprofile/{{$b->userid}}">{{$b->first_name}} {{$b->last_name}}</a></td>
        <td>{{$b->day}} {{$b->time}}</td>
          <td>{{$b->service_name}}</td>
            <td>{{$b->price}}</td>
              <td>{{$b->status}}</td>
                <td>{{$b->created_at}}</td>
              
    </tr>
   @endforeach
   
  </tbody>
</table>
                                            </div>

                                    </div>
                                </div>
                                <!-- END: General Statistics -->
                            </div>
                        </div>
              
              @elseif($type == "services")
                                       <div class="col-span-12 lg:col-span-8 xxl:col-span-9">
                            
                            <div class="grid grid-cols-12 gap-6">
                                <!-- BEGIN: Daily Sales -->
                                <div class="intro-y box col-span-12 xxl:col-span-6">
                                    <div class="flex items-center px-5 py-5 sm:py-3 border-b border-gray-200 dark:border-dark-5">
                                        <h2 class="font-medium text-base mr-auto">
                                          Services
                                        </h2>
                                        <div class="dropdown ml-auto sm:hidden">
                                            <a class="dropdown-toggle w-5 h-5 block" href="javascript:;" aria-expanded="false"> <i data-feather="more-horizontal" class="w-5 h-5 text-gray-600 dark:text-gray-300"></i> </a>
                                            <div class="dropdown-menu w-40">
                                                <div class="dropdown-menu__content box dark:bg-dark-1 p-2">
                                                    <a href="javascript:;" class="flex items-center p-2 transition duration-300 ease-in-out bg-white dark:bg-dark-1 hover:bg-gray-200 dark:hover:bg-dark-2 rounded-md"> <i data-feather="file" class="w-4 h-4 mr-2"></i> Download Excel </a>
                                                </div>
                                            </div>
                                        </div>
                                        <button class="btn btn-outline-secondary hidden sm:flex"> <i data-feather="file" class="w-4 h-4 mr-2"></i> Download Excel </button>
                                    </div>
                                    <div class="p-5">
                                            <div class="row">
                                                <table class="table table-auto">
  <thead>
    <tr>
      <th>Type</th>
      <th>Amount</th>
      <th>Date</th> 
    </tr>
  </thead>
  <tbody>
   @foreach($services as $b)
    <tr>
      
          <td>{{$b->service_name}}</td>
            <td>{{$b->amount}}</td> 
                <td>{{$b->created_at}}</td>
              
    </tr>
   @endforeach
   
  </tbody>
</table>
                                            </div>

                                    </div>
                                </div>
                                <!-- END: General Statistics -->
                            </div>
                        </div>
                      
            @else
                      <div class="col-span-12 lg:col-span-8 xxl:col-span-9">
                            
                            <div class="grid grid-cols-12 gap-6">
                                <!-- BEGIN: Daily Sales -->
                                <div class="intro-y box col-span-12 xxl:col-span-6">
                                    <div class="flex items-center px-5 py-5 sm:py-3 border-b border-gray-200 dark:border-dark-5">
                                        <h2 class="font-medium text-base mr-auto">
                                           Profile Information
                                        </h2>
                                        <div class="dropdown ml-auto sm:hidden">
                                            <a class="dropdown-toggle w-5 h-5 block" href="javascript:;" aria-expanded="false"> <i data-feather="more-horizontal" class="w-5 h-5 text-gray-600 dark:text-gray-300"></i> </a>
                                            <div class="dropdown-menu w-40">
                                                <div class="dropdown-menu__content box dark:bg-dark-1 p-2">
                                                    <a href="javascript:;" class="flex items-center p-2 transition duration-300 ease-in-out bg-white dark:bg-dark-1 hover:bg-gray-200 dark:hover:bg-dark-2 rounded-md"> <i data-feather="file" class="w-4 h-4 mr-2"></i> Download Excel </a>
                                                </div>
                                            </div>
                                        </div>
                                        <button class="btn btn-outline-secondary hidden sm:flex"> <i data-feather="file" class="w-4 h-4 mr-2"></i> Download Excel </button>
                                    </div>
                                    <div class="p-5">
                                        <div class="relative flex items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">FullName</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500">{{$data->first_name}} {{$data->last_name}}</div>
                                        </div>

                    
                                        
                                        
                                       
                                        
                                        <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li class="font-medium">Email</li> 

                                            </div>
                                            <div class="  text-gray-700 dark:text-gray-500">{{$data->email}}</div>
                                        </div>
                                        
                                       
                                        
                                        <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li class="font-medium">Wallet</li> 

                                            </div>
                                            <div class="  text-gray-700 dark:text-gray-500">NGN{{$data->wallet}}</div>
                                        </div>
                                     
                                    

                                        <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">Account Status</li> 

                                            </div>
                                            <div class="  text-gray-700 dark:text-gray-500">{{$data->active == 0 ? "Not Verified" : "Verified"}}</div>
                                        </div>
                                        
                                                           <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">Verification Status</li> 

                                            </div>
                                            <div class="  text-gray-700 dark:text-gray-500">
                                                
                                                @if($data->status == 0)
                                                
                                                Not Verified
                                                
                                                @elseif($data->status == 2)
                                                
                                                Disapproved
                                                
                                                @else
                                                
                                                Approved
                                                
                                                @endif
                                            </div>
                                        </div>
                                        
                                       
                                        
                                          

                                    </div>
                                </div>
  <div class="intro-y box col-span-12 xxl:col-span-6">
                                              <div class="flex items-center px-5 py-5 sm:py-3 border-b border-gray-200 dark:border-dark-5">
                                        <h2 class="font-medium text-base mr-auto">
                                           Verification Information
                                        </h2>
                                        <div class="dropdown ml-auto sm:hidden">
                                            <a class="dropdown-toggle w-5 h-5 block" href="javascript:;" aria-expanded="false"> <i data-feather="more-horizontal" class="w-5 h-5 text-gray-600 dark:text-gray-300"></i> </a>
                                            <div class="dropdown-menu w-40">
                                                <div class="dropdown-menu__content box dark:bg-dark-1 p-2">
                                                    <a href="javascript:;" class="flex items-center p-2 transition duration-300 ease-in-out bg-white dark:bg-dark-1 hover:bg-gray-200 dark:hover:bg-dark-2 rounded-md"> <i data-feather="file" class="w-4 h-4 mr-2"></i> Download Excel </a>
                                                </div>
                                            </div>
                                        </div>
                                        <!--<button class="btn btn-outline-secondary hidden sm:flex"> <i data-feather="file" class="w-4 h-4 mr-2"></i> Download Excel </button>-->
                                    </div>
                                    <div class="p-5">
                                        <h3>Step1 / Verification </h3>
                                        @if($step1 == null)
                                        <center><img src="/empty.svg" width="100"></center>
                                        @else
                                        <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">Hospital Name</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500">{{$step1->name}}</div>
                                        </div>
                                        
                                        <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">Category</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500">{{$step1->category}}</div>
                                        </div>
                                        
                                        <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">Registration Number</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500">{{$step1->reg_number}}</div>
                                        </div>
                                        
                                            
                                        <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">Open Hours</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500">{{$step1->open_hours}}</div>
                                        </div>
                                        
                                            
                                     
 @endif                                    
 

                                    </div>
                                 
                                    <div class="p-5">
                                        <h3>Step2 / Verification </h3>
                                        @if($step2 == null)
                                        <center><img src="/empty.svg" width="100"></center>
                                        @else
                                        <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">Country</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500">{{$step2->country}}</div>
                                        </div>
                                        
                                        <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">State</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500">{{$step2->state}}</div>
                                        </div>
                                        
                                        <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">Refferral</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500">{{$step2->ref_by}}</div>
                                        </div>
                                        
                                            
                                        
                                               
                                        <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">ID card</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500"><img src="{{$step2->identity_id}}" width="100"></div>
                                        </div>
                                        
                                             <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">Account Name</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500">{{$step2->account_name}}</div>
                                        </div>
                                        
                                        
                                             <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">Account Bank</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500">{{$step2->account_bank}}</div>
                                        </div>
                                        
                                             <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">Account Number</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500">{{$step2->account_number}}</div>
                                        </div>
                                        
                                        
                                        

 @endif                                    
 

                                    </div>
                                    
                                    <div class="p-5">
                                        <h3>Step3 / Verification </h3>
                                        @if($step3 == null)
                                        <center><img src="/empty.svg" width="100"></center>
                                        @else
                                        
                                        
                                            
                                        
                                               
                                        <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">Registration  Certificate</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500"><img src="{{$step3->reg_cert}}" width="100"></div>
                                        </div>
                                        
                                        
                                          <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">Valid License</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500"><img src="{{$step3->valid_license}}" width="100"></div>
                                        </div>
                                        
                                          <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">CAC</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500"><a href="{{$step3->cac}}"   download>Download</a></div>
                                        </div>
                                        
                                          <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">About</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500">{{$step3->about}}</div>
                                        </div>

 @endif                                    
 

                                    </div>
                                      <div class="p-5">
                                        <h3>Step4 / Verification </h3>
                                        @if(count($step4) == 0)
                                        <center><img src="/empty.svg" width="100"></center>
                                        @else
                                        @foreach($step4 as $d)
                                        <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">Company</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500">{{$d->company_org}}</div>
                                        </div>
                                        
                                         <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">From</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500">{{$d->from}}</div>
                                        </div>
                                        
                                         <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">To</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500">{{$d->to}}</div>
                                        </div>
                                         <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">Current</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500">{{$d->active == 0 ? "Left Job" : "Still With Job"}}</div>
                                        </div>
                                        <br><br>
                                        
                                        
                                        @endforeach

 @endif                                    
 

                                    </div>
                                </div>
                                <!-- END: General Statistics -->
                            </div>
                        </div>
            @endif
@include("admin.hospital.sidefoot")