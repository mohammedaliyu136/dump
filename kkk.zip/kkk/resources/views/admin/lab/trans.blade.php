@extends('admin.layout.app', ['title' => 'Lab Transactions'])

@section('content')
    <div class="content">
        <div class="content-body">
            <div class="container-fluid">
                <!-- Header -->
                <div class="intro-y flex flex-col sm:flex-row items-center mt-8">
                    <div class="w-full sm:w-auto flex mt-4 sm:mt-0">
                        {{-- <button class="btn btn-primary shadow-md mr-2" data-bs-toggle="modal" data-bs-target="#createnew">
                            <i class="fa fa-plus mr-2"></i> Add New Category
                        </button> --}}
                    </div>
                </div>

                <!-- Main Content -->
                <div class="grid grid-cols-12 gap-6 mt-5">
                    <div class="col-span-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="overflow-x-auto">
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th class="whitespace-nowrap">Type</th>
                                                <th class="whitespace-nowrap">Amount</th>
                                                <th class="whitespace-nowrap">Status</th>
                                                <th class="whitespace-nowrap">Created At</th>
                                                <th class="whitespace-nowrap">Action</th>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            @forelse($data as $d)
                                                <tr>
                                                    <td>{{ $d->type }}</td>
                                                    <td>NGN{{ number_format($d->amount, 2) }}</td>
                                                    <td>{{ $d->status }}</td>
                                                    <td>{{ $d->created_at }}</td>
                                                    <td>
                                                        <div class="flex">
                                                            <button class="btn btn-sm btn-primary mr-2"
                                                                onclick="editd({{ $d->id }})" data-bs-toggle="modal"
                                                                data-bs-target="#editModal">
                                                                <i class="fas fa-edit"></i>
                                                            </button>
                                                            <button class="btn btn-sm btn-danger"
                                                                onclick="deleted({{ $d->id }})"
                                                                data-bs-toggle="modal" data-bs-target="#deleteModal">
                                                                <i class="fas fa-trash"></i>
                                                            </button>
                                                        </div>
                                                    </td>
                                                </tr>
                                            @empty
                                                <tr>
                                                    <td colspan="4" class="text-center">No categories found</td>
                                                </tr>
                                            @endforelse
                                        </tbody>
                                    </table>
                                </div>
                                <!-- Pagination -->
                                <div class="mt-5">
                                    {{ $data->links() }}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
