@extends('admin.layout.app', ['title' => 'Lab Sub Categories'])

@section('content')
<div class="content">
    <div class="content-body">
        <div class="container-fluid">
            <!-- Header -->
            <div class="intro-y flex flex-col sm:flex-row items-center mt-8">
                <h2 class="text-lg font-medium mr-auto">Lab Sub Categories</h2>
                <div class="w-full sm:w-auto flex mt-4 sm:mt-0">
                    <button class="btn btn-primary shadow-md mr-2" data-bs-toggle="modal" data-bs-target="#createnew">
                        <i class="fa fa-plus mr-2"></i> Add New Sub Category
                    </button>
                </div>
            </div>

            <!-- Main Content -->
            <div class="grid grid-cols-12 gap-6 mt-5">
                <div class="col-span-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="overflow-x-auto">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th class="whitespace-nowrap">ID</th>
                                            <th class="whitespace-nowrap">Name</th>
                                            <th class="whitespace-nowrap">Category</th>
                                            <th class="whitespace-nowrap">Created At</th>
                                            <th class="whitespace-nowrap">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @forelse($data as $d)
                                            <tr>
                                                <td>{{ $d->id }}</td>
                                                <td>{{ $d->name }}</td>
                                                <td>{{ $d->catname }}</td>
                                                <td>{{ $d->created_at }}</td>
                                                <td>
                                                    <div class="flex justify-center">
                                                        <button class="btn btn-sm btn-primary mr-2"
                                                                onclick="setID2({{ $d->id }}, '{{ $d->name }}', '{{ $d->catid }}')"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#edititem">
                                                            <i class="fas fa-edit"></i>
                                                        </button>
                                                        <button class="btn btn-sm btn-danger"
                                                                onclick="setID({{ $d->id }})"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#delete-confirmation-modal">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        @empty
                                            <tr>
                                                <td colspan="5" class="text-center">No sub categories found</td>
                                            </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                            </div>
                            <!-- Pagination -->
                            <div class="mt-5">
                                {{ $data->links() }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Create Modal -->
    <div class="modal fade" id="createnew" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <form id="createForm">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Create New Sub Category</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group mb-3">
                            <label for="name" class="form-label">Sub Category Name</label>
                            <input type="text" class="form-control" id="name" name="name" required>
                            <div class="invalid-feedback" id="nameError"></div>
                        </div>
                        <div class="form-group">
                            <label for="cat" class="form-label">Parent Category</label>
                            <select class="form-select" id="cat" name="cat" required>
                                <option value="">Select category</option>
                                @foreach(DB::table("lab_category")->get() as $d)
                                    <option value="{{ $d->id }}">{{ $d->name }}</option>
                                @endforeach
                            </select>
                            <div class="invalid-feedback" id="catError"></div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Create</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit Modal -->
    <div class="modal fade" id="edititem" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <form id="editForm">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Edit Sub Category</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" id="id">
                        <div class="form-group mb-3">
                            <label for="ename" class="form-label">Sub Category Name</label>
                            <input type="text" class="form-control" id="ename" name="name" required>
                            <div class="invalid-feedback" id="editNameError"></div>
                        </div>
                        <div class="form-group">
                            <label for="ecat" class="form-label">Parent Category</label>
                            <select class="form-select" id="ecat" name="cat" required>
                                <option value="">Select category</option>
                                @foreach(DB::table("lab_category")->get() as $d)
                                    <option value="{{ $d->id }}">{{ $d->name }}</option>
                                @endforeach
                            </select>
                            <div class="invalid-feedback" id="editCatError"></div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Delete Modal -->
    <div class="modal fade" id="delete-confirmation-modal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Confirm Delete</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete this sub category? This action cannot be undone.</p>
                    <input type="hidden" id="delete_id">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-danger" onclick="deletebtn()">Delete</button>
                </div>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
// Create Sub Category
$('#createForm').on('submit', function(e) {
    e.preventDefault();

    $.ajax({
        url: '/admin/lab/newcat',
        type: 'POST',
        data: {
            name: $('#name').val(),
            cat: $('#cat').val(),
            "_token": "{{ csrf_token() }}"
        },
        beforeSend: function() {
            $("button[type='submit']").prop('disabled', true);
            $('#nameError, #catError').html('');
        },
        success: function(response) {
            $('#createnew').modal('hide');
            location.reload();
        },
        error: function(xhr) {
            $("button[type='submit']").prop('disabled', false);
            if(xhr.status === 422) {
                const errors = xhr.responseJSON.errors;
                if(errors.name) $('#nameError').html(errors.name[0]);
                if(errors.cat) $('#catError').html(errors.cat[0]);
            } else {
                alert('Something went wrong!');
            }
        }
    });
});

// Edit Sub Category
function setID2(id, name, catid) {
    $("#id").val(id);
    $("#ename").val(name);
    $("#ecat").val(catid);
}

$('#editForm').on('submit', function(e) {
    e.preventDefault();

    $.ajax({
        url: '/admin/lab/editsubcat',
        type: 'POST',
        data: {
            id: $('#id').val(),
            name: $('#ename').val(),
            cat: $('#ecat').val(),
            "_token": "{{ csrf_token() }}"
        },
        beforeSend: function() {
            $("button[type='submit']").prop('disabled', true);
            $('#editNameError, #editCatError').html('');
        },
        success: function(response) {
            $('#edititem').modal('hide');
            location.reload();
        },
        error: function(xhr) {
            $("button[type='submit']").prop('disabled', false);
            if(xhr.status === 422) {
                const errors = xhr.responseJSON.errors;
                if(errors.name) $('#editNameError').html(errors.name[0]);
                if(errors.cat) $('#editCatError').html(errors.cat[0]);
            } else {
                alert('Something went wrong!');
            }
        }
    });
});

// Delete Sub Category
function setID(id) {
    $("#id").val(id);
}

function deletebtn() {
    const id = $("#id").val();

    $.ajax({
        url: '/admin/lab/deletesubcat',
        type: 'POST',
        data: {
            id: id,
            "_token": "{{ csrf_token() }}"
        },
        beforeSend: function() {
            $(".btn-danger").prop('disabled', true);
        },
        success: function(response) {
            $('#delete-confirmation-modal').modal('hide');
            location.reload();
        },
        error: function() {
            $(".btn-danger").prop('disabled', false);
            alert('Error deleting sub category');
        }
    });
}

// Reset forms when modals are closed
$('.modal').on('hidden.bs.modal', function () {
    $(this).find('form').trigger('reset');
    $('.invalid-feedback').html('');
    $('.btn').prop('disabled', false);
});
</script>
@endpush
@endsection
