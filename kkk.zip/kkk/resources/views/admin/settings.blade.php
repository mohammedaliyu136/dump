@include("admin.layout.header")


<div class="content">
                    <h2 class="intro-y text-lg font-medium mt-10">
                       Settings
                    </h2>
                     <form>
                    <div class="grid grid-cols-12 gap-6 mt-5">
                      
                        <!-- BEGIN: Data List -->
                       
                        <div class="intro-y col-span-12 overflow-auto lg:overflow-visible">
                            @foreach($data as $d)
                                 <div class="mt-3"> <label for="regular-form-4" class="form-label">{{str_replace('_', ' ', $d->type)}}</label> <input id="{{$d->type}}" type="text" value="{{$d->text}}" class="form-control" required> </div>
            @endforeach
            
            <button class="btn btn-primary mt-3" type="submit">Update</button>
                        </div>
                        <!-- END: Data List -->

                    </div>
             </form>       
                 
                    <!-- END: Delete Confirmation Modal -->
                </div>
                <input type="hidden" id="id"/>
@include("admin.layout.footer")

<script>
  $('form').submit( function (event) {
	// prevent the usual form submission behaviour; the "action" attribute of the form
	event.preventDefault();
	// validation goes below...
@foreach($data as $d)
 const {{$d->type}} = $("#{{$d->type}}").val()
 @endforeach
	// now for the big event
	$.ajax({
	  // the server script you want to send your data to
		'url': '/admin/settings',
		// all of your POST/GET variables
		'data': {
			// 'dataname': $('input').val(), ...
			@foreach($data as $d)
			{{$d->type}},
			@endforeach
			"_token":"{{csrf_token()}}"
		},
		// you may change this to GET, if you like...
		'type': 'post',
	 
		'beforeSend': function () {
			// anything you want to have happen before sending the data to the server...
			// useful for "loading" animations
			$("button").attr("disabled",true)
		}
	})
	.done( function (response) {
		// what you want to happen when an ajax call to the server is successfully completed
		// 'response' is what you get back from the script/server
		// usually you want to format your response and spit it out to the page
		document.getElementById("showsuccess").click()
		$("#message").html(response.message)
// 		location.reload()
		
	})
	.fail( function (code, status) {
		// what you want to happen if the ajax request fails (404 error, timeout, etc.)
		// 'code' is the numeric code, and 'status' is the text explanation for the error
		// I usually just output some fancy error messages
		$("#message2").html(code.responseJSON.message)
		document.getElementById("showerror").click()
	})
	.always( function (xhr, status) {
		// what you want to have happen no matter if the response is success or error
		// here, you would "stop" your loading animations, and maybe output a footer at the end of your content, reading "done"
		$("button").attr("disabled",false)
	    
	});
});
</script>
 