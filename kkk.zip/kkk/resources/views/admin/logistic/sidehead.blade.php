 @include("admin.layout.header")

       
 <!-- END: Modal Toggle --> <!-- BEGIN: Modal Content --> 
<div id="basic-modal-preview" class="modal" tabindex="-1" aria-hidden="true">
   <div class="modal-dialog">
         <form id="disapprove">
      <div class="modal-content">
          <div class="modal-header">
                 <h2 class="font-medium text-base mr-auto">Account Verification</h2>
                 </div>
         <div class="modal-body p-10  ">
             <div class="form-group">
                 <label>Enter Reason For Disapproval</label>
                 <textarea class="form-control" id="reason"></textarea>
             </div>
             
             </div>
        <div class="modal-footer text-right"><button type="submit" class="btn btn-primary ">continue</button></div>
      </div>
            </form>
   </div>
</div>
 
 <!-- BEGIN: Modal Content -->
 <div id="delete-modal-preview" class="modal" tabindex="-1" aria-hidden="true">
     <div class="modal-dialog">
         <div class="modal-content">
             <div class="modal-body p-0">
                 <div class="p-5 text-center"> <i data-feather="x-circle" class="w-16 h-16 text-theme-24 mx-auto mt-3"></i>
                     <div class="text-3xl mt-5">Are you sure?</div>
                     <div class="text-gray-600 mt-2">Are you sure you want to approve {{$data->name}}</div>
                 </div>
                 <div class="px-5 pb-8 text-center"> <button type="button" data-dismiss="modal" class="btn btn-outline-secondary w-24 dark:border-dark-5 dark:text-gray-300 mr-1">Cancel</button> <button type="button" class="btn btn-danger w-24" onclick="approve()">Yes</button> </div>
             </div>
         </div>
     </div>
 </div> <!-- END: Modal Content -->
 <div class="content">
                    <div class="intro-y flex items-center mt-8">
                        <h2 class="text-lg font-medium mr-auto">
                            Profile Layout
                        </h2>
                    </div>
                    <div class="grid grid-cols-12 gap-6 mt-5">
                        <!-- BEGIN: Profile Menu -->
                       
 <div class="col-span-12 lg:col-span-4 xxl:col-span-3 flex lg:block flex-col-reverse">
                            <div class="intro-y box mt-5 lg:mt-0">
                                <div class="relative flex items-center p-5">
                                    <div class="w-12 h-12 image-fit">
                                        <img alt="Icewall Tailwind HTML Admin Template" class="rounded-full" src="{{$data->image}}" width="50" height="50">
                                    </div>
                                    <div class="ml-4 mr-auto">
                                        <div class="font-medium text-base">{{$data->name}}</div>
                                        
                                    </div>
                                     
                                </div>
                                <div class="p-5 border-t border-gray-200 dark:border-dark-5">
                                    <a class="flex items-center {{$type == 1? 'text-theme-17 dark:text-white font-medium' : ''}}" href="/admin/dash/{{$data->id}}"> <i data-feather="activity" class="w-4 h-4 mr-2"></i> Personal Information </a>
                                    
                                    <a class="flex items-center mt-5 {{$type == 3? 'text-theme-17 dark:text-white font-medium' : ''}}"  href="#"> <i data-feather="bell" class="w-4 h-4 mr-2"></i> Transactions </a>
                                             <!--<a class="flex items-center mt-5" href=""> <i data-feather="bell" class="w-4 h-4 mr-2"></i> Transactions </a>-->
                                </div>
                               
                                <div class="p-5 border-t border-gray-200 dark:border-dark-5 flex">
                                    <a href="javascript:;" class="btn btn-danger py-1 px-2" data-toggle="modal" data-target="#basic-modal-preview">DisApprove</a>
                                    <a type="button" class="btn btn-outline-secondary py-1 px-2 ml-auto" data-toggle="modal" data-target="#delete-modal-preview">Approve</a>
                                </div>
                            </div>
                           @if($data->reason_for_disapprove != null &&  $data->status == 2)
                           
                             <div class="intro-y box p-5 bg-theme-17 text-white mt-5">
                                <div class="flex items-center">
                                    <div class="font-medium text-lg">Reason For Disapproval</div>
                                    <div class="text-xs bg-white dark:bg-theme-17 dark:text-white text-gray-800 px-1 rounded-md ml-auto">New</div>
                                </div>
                                <div class="mt-4">{{$data->reason_for_disapprove}}</div>
                                 
                            </div>
                            
                            @elseif($data->status == 1)
                            
                             <div class="intro-y box p-5 bg-theme-17 text-white mt-5">
                                <div class="flex items-center">
                                    <div class="font-medium text-lg">Verified Account</div>
                                    <div class="text-xs bg-white dark:bg-theme-17 dark:text-white text-gray-800 px-1 rounded-md ml-auto">New</div>
                                </div>
                               
                                 
                            </div>
                            
                            @endif
                        </div>