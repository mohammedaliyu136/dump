
@include("admin.logistic.sidehead")
                        <!-- END: Profile Menu -->
                        <div class="col-span-12 lg:col-span-8 xxl:col-span-9">
                            
                            <div class="grid grid-cols-12 gap-6">
                                <!-- BEGIN: Daily Sales -->
                                <div class="intro-y box col-span-12 xxl:col-span-6">
                                    <div class="flex items-center px-5 py-5 sm:py-3 border-b border-gray-200 dark:border-dark-5">
                                        <h2 class="font-medium text-base mr-auto">
                                           Profile Information
                                        </h2>
                                        <div class="dropdown ml-auto sm:hidden">
                                            <a class="dropdown-toggle w-5 h-5 block" href="javascript:;" aria-expanded="false"> <i data-feather="more-horizontal" class="w-5 h-5 text-gray-600 dark:text-gray-300"></i> </a>
                                            <div class="dropdown-menu w-40">
                                                <div class="dropdown-menu__content box dark:bg-dark-1 p-2">
                                                    <a href="javascript:;" class="flex items-center p-2 transition duration-300 ease-in-out bg-white dark:bg-dark-1 hover:bg-gray-200 dark:hover:bg-dark-2 rounded-md"> <i data-feather="file" class="w-4 h-4 mr-2"></i> Download Excel </a>
                                                </div>
                                            </div>
                                        </div>
                                        <button class="btn btn-outline-secondary hidden sm:flex"> <i data-feather="file" class="w-4 h-4 mr-2"></i> Download Excel </button>
                                    </div>
                                    <div class="p-5">
                                        <div class="relative flex items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">FullName</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500">{{$data->name}}</div>
                                        </div>               
                                        
                                        <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li class="font-medium">Phone Number</li> 

                                            </div>
                                            <div class="  text-gray-700 dark:text-gray-500">{{$data->phone}}</div>
                                        </div>
                                        
                                        <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li class="font-medium">Email</li> 

                                            </div>
                                            <div class="  text-gray-700 dark:text-gray-500">{{$data->email}}</div>
                                        </div>
                                        
                                        <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li class="font-medium">DOB</li> 

                                            </div>
                                            <div class="  text-gray-700 dark:text-gray-500">{{$data->dob}}</div>
                                        </div>
                                        
                                        <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li class="font-medium">Wallet</li> 

                                            </div>
                                            <div class="  text-gray-700 dark:text-gray-500">NGN{{$data->wallet}}</div>
                                        </div>
                                        
                                     

                                        <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">Account Status</li> 

                                            </div>
                                            <div class="  text-gray-700 dark:text-gray-500">{{$data->active == 0 ? "Not Verified" : "Verified"}}</div>
                                        </div>
                                        
                                                           <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">Verification Status</li> 

                                            </div>
                                            <div class="  text-gray-700 dark:text-gray-500">
                                                
                                                @if($data->status == 0)
                                                
                                                Not Verified
                                                
                                                @elseif($data->status == 2)
                                                
                                                Disapproved
                                                
                                                @else
                                                
                                                Approved
                                                
                                                @endif
                                            </div>
                                        </div>
                                        
                                        <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">State</li> 

                                            </div>
                                            <div class="  text-gray-700 dark:text-gray-500">{{$state == null ? "--" : $state->title}}</div>
                                        </div>

                                        <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">LGA</li> 

                                            </div>
                                            <div class="  text-gray-700 dark:text-gray-500">{{$lga == null ? "--" : $lga->title}}</div>
                                        </div>
                                        
                                        
                                          

                                    </div>
                                </div>
 
                                <!-- END: General Statistics -->
                            </div>
                        </div>
                                 
@include("admin.logistic.sidefoot")