
@include("admin.pharmacy.sidehead")
                        <!-- END: Profile Menu -->
                        <div class="col-span-12 lg:col-span-8 xxl:col-span-9">
                            
                            <div class="grid grid-cols-12 gap-6">
                                <!-- BEGIN: Daily Sales -->
                                <div class="intro-y box col-span-12 xxl:col-span-6">
                                    <div class="flex items-center px-5 py-5 sm:py-3 border-b border-gray-200 dark:border-dark-5">
                                        <h2 class="font-medium text-base mr-auto">
                                           Profile Information
                                        </h2>
                                        <div class="dropdown ml-auto sm:hidden">
                                            <a class="dropdown-toggle w-5 h-5 block" href="javascript:;" aria-expanded="false"> <i data-feather="more-horizontal" class="w-5 h-5 text-gray-600 dark:text-gray-300"></i> </a>
                                            <div class="dropdown-menu w-40">
                                                <div class="dropdown-menu__content box dark:bg-dark-1 p-2">
                                                    <a href="javascript:;" class="flex items-center p-2 transition duration-300 ease-in-out bg-white dark:bg-dark-1 hover:bg-gray-200 dark:hover:bg-dark-2 rounded-md"> <i data-feather="file" class="w-4 h-4 mr-2"></i> Download Excel </a>
                                                </div>
                                            </div>
                                        </div>
                                        <button class="btn btn-outline-secondary hidden sm:flex"> <i data-feather="file" class="w-4 h-4 mr-2"></i> Download Excel </button>
                                    </div>
                                    <div class="p-5">
                                        <div class="relative flex items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">FullName</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500">{{$data->name}}</div>
                                        </div>

                                       

                                      
                                        
                                        
                                        <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li class="font-medium">Phone Number</li> 

                                            </div>
                                            <div class="  text-gray-700 dark:text-gray-500">{{$data->phone}}</div>
                                        </div>
                                        
                                        <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li class="font-medium">Email</li> 

                                            </div>
                                            <div class="  text-gray-700 dark:text-gray-500">{{$data->email}}</div>
                                        </div>
                                        
                                        
                                        
                                        <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li class="font-medium">Wallet</li> 

                                            </div>
                                            <div class="  text-gray-700 dark:text-gray-500">NGN{{$data->wallet}}</div>
                                        </div>
                                        
                                       {{-- <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">Gender</li> 

                                            </div>
                                            <div class="  text-gray-700 dark:text-gray-500">{{$data->gender}}</div>
                                        </div> --}}
                                        
                                      {{--      <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">Language</li> 

                                            </div>
                                            <div class="  text-gray-700 dark:text-gray-500">{{$data->language}}</div>
                                        </div> --}}

                                        <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">Account Status</li> 

                                            </div>
                                            <div class="  text-gray-700 dark:text-gray-500">{{$data->active == 0 ? "Not Verified" : "Verified"}}</div>
                                        </div>
                                        
                                                           <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">Verification Status</li> 

                                            </div>
                                            <div class="  text-gray-700 dark:text-gray-500">
                                                
                                                @if($data->status == 0)
                                                
                                                Not Verified
                                                
                                                @elseif($data->status == 2)
                                                
                                                Disapproved
                                                
                                                @else
                                                
                                                Approved
                                                
                                                @endif
                                            </div>
                                        </div>
                                        
                                        <div class="relative flex mt-2 items-center">

                                            

                                        
                                        
                                        
                                         <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">Service PreFerences</li> 

                                            </div>
                                            <div class="  text-gray-700 dark:text-gray-500">{{$sp == null ? "--" : $sp->type}}</div>
                                        </div>
                                        
                                   

                                    </div>
                                </div>
 <div class="intro-y box col-span-12 xxl:col-span-6">
                                              <div class="flex items-center px-5 py-5 sm:py-3 border-b border-gray-200 dark:border-dark-5">
                                        <h2 class="font-medium text-base mr-auto">
                                           Verification Information
                                        </h2>
                                        <div class="dropdown ml-auto sm:hidden">
                                            <a class="dropdown-toggle w-5 h-5 block" href="javascript:;" aria-expanded="false"> <i data-feather="more-horizontal" class="w-5 h-5 text-gray-600 dark:text-gray-300"></i> </a>
                                            <div class="dropdown-menu w-40">
                                                <div class="dropdown-menu__content box dark:bg-dark-1 p-2">
                                                    <a href="javascript:;" class="flex items-center p-2 transition duration-300 ease-in-out bg-white dark:bg-dark-1 hover:bg-gray-200 dark:hover:bg-dark-2 rounded-md"> <i data-feather="file" class="w-4 h-4 mr-2"></i> Download Excel </a>
                                                </div>
                                            </div>
                                        </div>
                                        <!--<button class="btn btn-outline-secondary hidden sm:flex"> <i data-feather="file" class="w-4 h-4 mr-2"></i> Download Excel </button>-->
                                    </div>
                                    <div class="p-5">
                                        <h3>Step1 / Verification </h3>
                                        @if($step1 == null)
                                        <center><img src="/empty.svg" width="100"></center>
                                        @else
                                        <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">Pharmacy Name</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500">{{$step1->name}}</div>
                                        </div>
                                    
                                        
                                        <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">Pharmacy Code</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500">{{$step1->p_code}}</div>
                                        </div>
                                        
                                       
                                        <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">Reg Number</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500">{{$step1->reg_num}}</div>
                                        </div>
                                        
                                       
                                        
                                               
                                      
 @endif                                    
 

                                    </div>
                                 
                                    <div class="p-5">
                                        <h3>Step2 / Verification </h3>
                                        @if($step2 == null)
                                        <center><img src="/empty.svg" width="100"></center>
                                        @else
                                        <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">Country</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500">{{$step2->country}}</div>
                                        </div>
                                        
                                        <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">State</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500">{{$step2->state}}</div>
                                        </div>
                                        
                                        <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">Refferral</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500">{{$step2->refer}}</div>
                                        </div>
                                        
                                        
                                               <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">Account Name</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500">{{$step2->account_name}}</div>
                                        </div>
                                        
                                        
                                               <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">Account Number</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500">{{$step2->account_number}}</div>
                                        </div>
                                        
                                        
                                               <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">Bank Code</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500">{{$step2->account_bank}}</div>
                                        </div>
                                        
                                            
                                        
                                               
                                        <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">ID card</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500"><img src="{{$step2->identity_card}}" width="100"></div>
                                        </div>

 @endif                                    
 

                                    </div>
                                    
                                    <div class="p-5">
                                        <h3>Step3 / Verification </h3>
                                        @if($step3 == null)
                                        <center><img src="/empty.svg" width="100"></center>
                                        @else
                                        
                                        
                                            
                                        
                                               
                                        <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">Pharmacy Certificate</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500"><img src="{{$step3->p_cert}}" width="100"></div>
                                        </div>
                                        
                                        
                                          <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">Pharmacy License</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500"><img src="{{$step3->p_license}}" width="100"></div>
                                        </div>
                                        
                                          <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">Pharmacy Supporting Document</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500"><img src="{{$step3->backing_info}}" width="100"></div>
                                        </div>
                                        
                                          <div class="relative flex mt-2 items-center">

                                            <div class="ml-4 mr-auto">
                                                <li  class="font-medium">About</li> 

                                            </div>
                                            <div class=" text-gray-700 dark:text-gray-500">{{$step3->about}}</div>
                                        </div>

 @endif                                    
 

                                    </div>
                                   
                                </div>
                                <!-- END: General Statistics -->
                            </div>
                        </div>
                                 
@include("admin.pharmacy.sidefoot")