
                           
                    </div>
                </div>
@include("admin.layout.footer")

<script>
   $('#disapprove').submit( function (event) {
	// prevent the usual form submission behaviour; the "action" attribute of the form
	event.preventDefault();
	// validation goes below...

	// now for the big event
	$.ajax({
	  // the server script you want to send your data to
		'url': '/admin/pharmacy/disapprove',
		// all of your POST/GET variables
		'data': {
			// 'dataname': $('input').val(), ...
			id: "{{$data->id}}",
			"_token":"{{csrf_token()}}",
			reason: $("#reason").val()
		},
		// you may change this to GET, if you like...
		'type': 'post',
	 
		'beforeSend': function () {
			// anything you want to have happen before sending the data to the server...
			// useful for "loading" animations
			$("button").attr("disabled",true)
		}
	})
	.done( function (response) {
		// what you want to happen when an ajax call to the server is successfully completed
		// 'response' is what you get back from the script/server
		// usually you want to format your response and spit it out to the page
		document.getElementById("showsuccess").click()
		$("#message").html(response.message)
		location.reload()
		
	})
	.fail( function (code, status) {
		// what you want to happen if the ajax request fails (404 error, timeout, etc.)
		// 'code' is the numeric code, and 'status' is the text explanation for the error
		// I usually just output some fancy error messages
		$("#message2").html(code.responseJSON.message)
		document.getElementById("showerror").click()
	})
	.always( function (xhr, status) {
		// what you want to have happen no matter if the response is success or error
		// here, you would "stop" your loading animations, and maybe output a footer at the end of your content, reading "done"
		$("button").attr("disabled",false)
	    
	});
});


function approve(){
    	$.ajax({
	  // the server script you want to send your data to
		'url': '/admin/pharmacy/approve',
		// all of your POST/GET variables
		'data': {
			// 'dataname': $('input').val(), ...
			id: "{{$data->id}}",
			"_token":"{{csrf_token()}}"
		 
		},
		// you may change this to GET, if you like...
		'type': 'post',
	 
		'beforeSend': function () {
			// anything you want to have happen before sending the data to the server...
			// useful for "loading" animations
			$("button").attr("disabled",true)
		}
	})
	.done( function (response) {
		// what you want to happen when an ajax call to the server is successfully completed
		// 'response' is what you get back from the script/server
		// usually you want to format your response and spit it out to the page
		document.getElementById("showsuccess").click()
		$("#message").html(response.message)
		location.reload()
		
	})
	.fail( function (code, status) {
		// what you want to happen if the ajax request fails (404 error, timeout, etc.)
		// 'code' is the numeric code, and 'status' is the text explanation for the error
		// I usually just output some fancy error messages
		$("#message2").html(code.responseJSON.message)
		document.getElementById("showerror").click()
	})
	.always( function (xhr, status) {
		// what you want to have happen no matter if the response is success or error
		// here, you would "stop" your loading animations, and maybe output a footer at the end of your content, reading "done"
		$("button").attr("disabled",false)
	    
	});
}
    
</script>
