 <!DOCTYPE html
     PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
 <html xmlns="http://www.w3.org/1999/xhtml" lang="en-GB">

 <head>
     <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
     <title>Demystifying Email Design</title>
     <meta name="viewport" content="width=device-width, initial-scale=1.0" />

     <style type="text/css">
         a[x-apple-data-detectors] {
             color: inherit !important;
         }
     </style>

 </head>

 <body style="margin: 0; padding: 0;">
     <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%">
         <tr>
             <td style="padding: 20px 0 30px 0;">

                 <table align="center" border="0" cellpadding="0" cellspacing="0" width="600"
                     style="border-collapse: collapse; border: 1px solid #cccccc;">
                     <tr>
                         <td align="center" bgcolor="#E5E5E5" style="padding: 40px 0 30px 0;">
                             <img src="https://sonocare.com.ng/wp-content/uploads/2021/04/Sonocare_light_mode-1.png"
                                 alt="SonoCare Logo." width="150" style="display: block;" />
                         </td>
                     </tr>
                     <tr>
                         <td bgcolor="#ffffff" style="padding: 40px 30px 40px 30px;">
                             <table border="0" cellpadding="0" cellspacing="0" width="100%"
                                 style="border-collapse: collapse;">
                                 <tr>
                                     <td style="color: #153643; font-family: Arial, sans-serif;">
                                         <h1 style="font-size: 24px; margin: 0;">Hello {{ $user->first_name }}!</h1>
                                         <!--  user->last_name -->
                                         <h3>Welcome to SonoCare </h3>
                                     </td>
                                 </tr>
                                 <tr>
                                     <td
                                         style="color: #153643; font-family: Arial, sans-serif; font-size: 16px; line-height: 24px; padding: 20px 0 30px 0;">
                                         <p>

                                         <p>I would like to personally thank you for signing up to use our services.
                                         </p>
                                         <p>The SonoCare service is one that is very close to my heart, born out of my
                                             own personal experience which I realized was not unique to me but to a
                                             large number of the populace in Nigeria, across Africa and the world at
                                             large.</p>
                                         <p>Our motivation at SonoCare thus is to not just provide health care for
                                             under-served populations but to in a holistically save and improve the
                                             lives of people with a focus on three key areas: Health, Convenience and
                                             Happiness.</p>
                                         <p>SonoCare was developed as a multi-model service for individual and corporate
                                             patients with the most comprehensive and personalized health insurance
                                             plans that covers all your healthcare costs and entitles you to instant
                                             doctor consultations on-demand, doctor house calls, doorstep lab testing
                                             and drug deliveries, private nursing care, referral appointment scheduling
                                             and emergency ambulance response to not only ensure any threats to their
                                             health is discovered early and taken care of, but to also ensure that care
                                             is always as easy and as close as your phone.</p>
                                         <p>The bonus is that you receive regular detailed updates on your health status
                                             so you can be rest assured that you are in good hands.</p>
                                         <p>As you subscribe to our service for yourself, your family and your loved
                                             ones including elderly parents, we at SonoCare oblige to be committed to
                                             the best interest of your health and wellbeing with the highest level of
                                             passion and compassion to help you heal and stay in good health.</p>
                                         <p>Together lets ensure all of us will not only have an improved quality of
                                             life but never have to worry about our health again.</p>
                                         <p>Once again, thank you for coming on board SonoCare. We hope you’ll have the
                                             best experience ever. </p>






                                         </p>
                                         <p>Moses Enokela, MD<br>
                                             Founder/CEO </p>
                                     </td>
                                 </tr>
                                 <tr>
                                     <td>

                                     </td>
                                 </tr>
                                 <tr>
                                     <td bgcolor="#fd7e14" style="padding: 30px 30px;">
                                         <table border="0" cellpadding="0" cellspacing="0" width="100%"
                                             style="border-collapse: collapse;">
                                             <td
                                                 style="color: #ffffff; font-family: Arial, sans-serif; font-size: 14px;">
                                                 <p style="margin: 0;">©2021 SonoCare</p>
                                             </td>
                                             <tr>

                                         </table>
                                     </td>
                                 </tr>
                             </table>
                         </td>
                     </tr>
                 </table>

             </td>
         </tr>
     </table>
 </body>

 </html>
